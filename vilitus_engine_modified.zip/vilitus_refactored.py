"""
VILITUS ENGINE — REFACTORED PRODUCTION CODE v3.0
=================================================
All critical bugs fixed, architecture hardened, type safety improved,
and production patterns applied (context managers, LRU cache, proper
config propagation, signal-based timeouts, and comprehensive validation).
"""

import os
import time
import asyncio
import logging
import hashlib
import json
import signal
import math
import random
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable, Tuple, Union
from enum import Enum, auto
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from collections import OrderedDict
import threading
import warnings

# ---------------------------------------------------------------------------
# CONFIGURATION & LOGGING
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="[%(name)s] %(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("VilitusQuantumRouter")


class ExecutionTier(Enum):
    """Ordered from cheapest/fastest to most expensive/powerful."""
    CLASSICAL = auto()
    LOCAL_SIM = auto()
    CLOUD_SIM = auto()
    QUANTUM_INSPIRED = auto()
    QPU_GATE = auto()
    QPU_ANNEAL = auto()


class QUBOComplexity(Enum):
    """Problem classification for auto-routing."""
    TRIVIAL = "trivial"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE_SPARSE = "large_sparse"
    LARGE_DENSE = "large_dense"


@dataclass(frozen=True)
class RouterConfig:
    """
    Immutable centralized configuration for the quantum router.

    frozen=True ensures thread-safety and prevents accidental mutation.
    """
    ibm_token: Optional[str] = None
    ibm_instance: str = "ibm-q/open/main"
    ibm_channel: str = "ibm_cloud"
    ibm_backend_preference: Tuple[str, ...] = ("ibm_heron", "ibm_nighthawk")

    dwave_token: Optional[str] = None
    dwave_solver: str = "Advantage2_prototype1.1"
    dwave_region: str = "na-west-1"

    classical_solver: str = "or-tools"
    classical_timeout_sec: float = 30.0

    max_qpu_cost_usd: float = 500.0
    max_qpu_minutes_per_month: float = 60.0
    enable_budget_tracking: bool = True

    default_timeout_sec: float = 300.0
    qpu_queue_timeout_sec: float = 60.0
    enable_result_verification: bool = True
    enable_warm_start: bool = True

    executor_pool_size: int = 4
    ros_decoupled: bool = True

    trivial_threshold: int = 50
    small_threshold: int = 200
    medium_threshold: int = 1000
    sparse_density_threshold: float = 0.05

    # v3.0 additions
    cache_max_size: int = 1000
    verification_tolerance_classical: float = 1e-6
    verification_tolerance_quantum: float = 1e-2
    max_retries: int = 3
    retry_base_delay_sec: float = 1.0
    retry_max_delay_sec: float = 60.0
    metrics_port: Optional[int] = None


# ---------------------------------------------------------------------------
# INPUT VALIDATION
# ---------------------------------------------------------------------------

class ValidationError(ValueError):
    """Raised when QUBO payload fails validation."""
    pass


def _validate_qubo_payload(payload: "QUBOPayload") -> None:
    """Validate QUBO payload invariants. Raises ValidationError on failure."""
    if payload.num_variables < 0:
        raise ValidationError(f"num_variables must be >= 0, got {payload.num_variables}")

    if payload.num_variables == 0 and (payload.q_matrix or payload.linear_terms):
        raise ValidationError("num_variables is 0 but matrix/terms are non-empty")

    max_idx = payload.num_variables - 1
    for (i, j) in payload.q_matrix.keys():
        if not (0 <= i <= max_idx and 0 <= j <= max_idx):
            raise ValidationError(f"QUBO index ({i},{j}) out of bounds [0, {max_idx}]")
        if i > j:
            raise ValidationError(f"QUBO index ({i},{j}) not normalized (i > j)")

    for i in payload.linear_terms.keys():
        if not (0 <= i <= max_idx):
            raise ValidationError(f"Linear index {i} out of bounds [0, {max_idx}]")


# ---------------------------------------------------------------------------
# QUBO PAYLOAD (Hardened)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class QUBOPayload:
    """
    Immutable standardized QUBO problem representation.

    All diagonal terms are normalized into linear_terms. q_matrix contains
    only upper-triangular off-diagonal entries (i < j).
    """
    q_matrix: Dict[Tuple[int, int], float]  # Only (i,j) with i < j
    linear_terms: Dict[int, float]          # Diagonal terms
    num_variables: int
    constraints: Tuple[Dict[str, Any], ...] = ()
    metadata: Tuple[Tuple[str, Any], ...] = ()  # Immutable for hashing

    def __post_init__(self):
        # Convert metadata to dict for internal use, but keep hashable form
        object.__setattr__(self, '_metadata_dict', dict(self.metadata))

    @property
    def density(self) -> float:
        """Calculate matrix density (non-zero / total possible upper-triangular + diagonal)."""
        if self.num_variables == 0:
            return 0.0
        max_entries = self.num_variables * (self.num_variables + 1) // 2
        actual = len(self.q_matrix) + len(self.linear_terms)
        return actual / max_entries if max_entries > 0 else 0.0

    def complexity_class(self, config: RouterConfig) -> QUBOComplexity:
        """Auto-classify problem complexity for routing decisions."""
        n = self.num_variables
        d = self.density

        if n < config.trivial_threshold:
            return QUBOComplexity.TRIVIAL
        elif n < config.small_threshold:
            return QUBOComplexity.SMALL
        elif n < config.medium_threshold:
            return QUBOComplexity.MEDIUM
        elif d < config.sparse_density_threshold:
            return QUBOComplexity.LARGE_SPARSE
        else:
            return QUBOComplexity.LARGE_DENSE

    def fingerprint(self) -> str:
        """Generate a deterministic hash for caching/deduplication."""
        data = json.dumps({
            "n": self.num_variables,
            "q": sorted(self.q_matrix.items()),
            "l": sorted(self.linear_terms.items()),
            "c": self.constraints
        }, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def get_metadata(self) -> Dict[str, Any]:
        """Return metadata as a mutable dict."""
        return getattr(self, '_metadata_dict', {})

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QUBOPayload":
        """Factory method with normalization."""
        n = data["num_variables"]
        raw_q = data.get("q_matrix", {})
        raw_l = data.get("linear_terms", {})

        # Normalize: move diagonal from q_matrix to linear_terms
        q_matrix = {}
        linear_terms = dict(raw_l)
        for (i, j), coeff in raw_q.items():
            if i == j:
                linear_terms[i] = linear_terms.get(i, 0.0) + coeff
            elif i < j:
                q_matrix[(i, j)] = q_matrix.get((i, j), 0.0) + coeff
            else:
                q_matrix[(j, i)] = q_matrix.get((j, i), 0.0) + coeff

        return cls(
            q_matrix=q_matrix,
            linear_terms=linear_terms,
            num_variables=n,
            constraints=tuple(data.get("constraints", [])),
            metadata=tuple(data.get("metadata", {}).items())
        )


@dataclass(frozen=True)
class ExecutionResult:
    """Immutable standardized result from any backend."""
    status: str
    backend: str
    tier: ExecutionTier
    solution: Tuple[Tuple[int, int], ...]  # Immutable: ((var_idx, value), ...)
    energy: Optional[float] = None
    execution_time_sec: float = 0.0
    cost_usd: float = 0.0
    queue_time_sec: float = 0.0
    verified: bool = False
    warm_start_used: bool = False
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def get_solution(self) -> Dict[int, int]:
        """Return solution as mutable dict."""
        return dict(self.solution)

    def get_metadata(self) -> Dict[str, Any]:
        return dict(self.metadata)

    def with_status(self, status: str) -> "ExecutionResult":
        """Return copy with new status (immutable update)."""
        return ExecutionResult(
            status=status,
            backend=self.backend,
            tier=self.tier,
            solution=self.solution,
            energy=self.energy,
            execution_time_sec=self.execution_time_sec,
            cost_usd=self.cost_usd,
            queue_time_sec=self.queue_time_sec,
            verified=self.verified,
            warm_start_used=self.warm_start_used,
            metadata=self.metadata
        )

    def with_metadata(self, **kwargs) -> "ExecutionResult":
        """Return copy with merged metadata."""
        new_meta = dict(self.metadata)
        new_meta.update(kwargs)
        return ExecutionResult(
            status=self.status,
            backend=self.backend,
            tier=self.tier,
            solution=self.solution,
            energy=self.energy,
            execution_time_sec=self.execution_time_sec,
            cost_usd=self.cost_usd,
            queue_time_sec=self.queue_time_sec,
            verified=self.verified,
            warm_start_used=self.warm_start_used,
            metadata=tuple(new_meta.items())
        )


# ---------------------------------------------------------------------------
# BUDGET TRACKER (Singleton, Thread-Safe)
# ---------------------------------------------------------------------------

class BudgetTracker:
    """Thread-safe cost and usage tracking across all backends."""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance.reset()
        return cls._instance

    def reset(self):
        self.qpu_minutes_used = 0.0
        self.total_cost_usd = 0.0
        self.job_history: List[Dict[str, Any]] = []
        self._monthly_start = time.time()

    def can_afford(self, estimated_cost: float, estimated_minutes: float,
                   config: RouterConfig) -> bool:
        if not config.enable_budget_tracking:
            return True
        with self._lock:
            if self.total_cost_usd + estimated_cost > config.max_qpu_cost_usd:
                logger.warning(
                    f"Budget exceeded: ${self.total_cost_usd:.2f} + "
                    f"${estimated_cost:.2f} > ${config.max_qpu_cost_usd}"
                )
                return False
            if self.qpu_minutes_used + estimated_minutes > config.max_qpu_minutes_per_month:
                logger.warning(
                    f"Monthly QPU minutes exceeded: {self.qpu_minutes_used:.1f} + "
                    f"{estimated_minutes:.1f} > {config.max_qpu_minutes_per_month}"
                )
                return False
            return True

    def record(self, cost: float, minutes: float, backend: str, status: str):
        with self._lock:
            self.total_cost_usd += cost
            self.qpu_minutes_used += minutes
            self.job_history.append({
                "timestamp": time.time(),
                "backend": backend,
                "cost_usd": cost,
                "minutes": minutes,
                "status": status
            })


# ---------------------------------------------------------------------------
# TIMEOUT UTILITIES
# ---------------------------------------------------------------------------

class TimeoutException(Exception):
    pass


def _set_timeout(timeout_sec: float):
    """Set a Unix signal-based timeout. Windows falls back to threading."""
    def handler(signum, frame):
        raise TimeoutException(f"Solver timed out after {timeout_sec} seconds")

    if hasattr(signal, "SIGALRM"):
        old_handler = signal.signal(signal.SIGALRM, handler)
        signal.alarm(int(math.ceil(timeout_sec)))
        return old_handler
    else:
        # Windows fallback: threading-based timeout (less reliable)
        return None


def _clear_timeout(old_handler):
    """Clear the timeout signal."""
    if old_handler is not None and hasattr(signal, "SIGALRM"):
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_handler)


# ---------------------------------------------------------------------------
# BACKEND INTERFACES (Hardened)
# ---------------------------------------------------------------------------

class BackendInterface:
    """Abstract base for all solver backends."""

    def __init__(self, name: str, tier: ExecutionTier):
        self.name = name
        self.tier = tier
        self.available = False

    def initialize(self, config: RouterConfig) -> bool:
        raise NotImplementedError

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        raise NotImplementedError

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        return (0.0, 0.0)


class ClassicalBackend(BackendInterface):
    """OR-Tools / SCIP classical solver wrapper."""

    def __init__(self):
        super().__init__("classical_or-tools", ExecutionTier.CLASSICAL)
        self.solver = None
        self._solver_type = "or-tools"

    def initialize(self, config: RouterConfig) -> bool:
        if config.classical_solver == "or-tools":
            try:
                from ortools.sat.python import cp_model
                self.solver = cp_model
                self.name = "classical_or-tools"
                self._solver_type = "or-tools"
                self.available = True
                logger.info("Classical backend (OR-Tools) initialized.")
                return True
            except ImportError:
                logger.warning("OR-Tools not available.")

        if config.classical_solver in ("scip", "or-tools"):
            try:
                import pyscipopt
                self.solver = pyscipopt
                self.name = "classical_scip"
                self._solver_type = "scip"
                self.available = True
                logger.info("Classical backend (SCIP) initialized.")
                return True
            except ImportError:
                logger.warning("SCIP not available.")

        if config.classical_solver == "gurobi":
            try:
                import gurobipy
                self.solver = gurobipy
                self.name = "classical_gurobi"
                self._solver_type = "gurobi"
                self.available = True
                logger.info("Classical backend (Gurobi) initialized.")
                return True
            except ImportError:
                logger.error("Gurobi not available (requires license).")

        logger.error("No classical solver available.")
        return False

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        start = time.time()

        if self._solver_type == "or-tools":
            return self._solve_ortools(payload, timeout_sec, warm_start, start)
        elif self._solver_type == "scip":
            return self._solve_scip(payload, timeout_sec, warm_start, start)
        elif self._solver_type == "gurobi":
            return self._solve_gurobi(payload, timeout_sec, warm_start, start)
        else:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                metadata=(("error", "Unknown solver type"),)
            )

    def _solve_ortools(self, payload: QUBOPayload, timeout_sec: float,
                       warm_start: Optional[Dict[int, int]], 
                       start_time: float) -> ExecutionResult:
        from ortools.sat.python import cp_model

        model = cp_model.CpModel()
        x = {i: model.NewBoolVar(f"x_{i}") for i in range(payload.num_variables)}

        obj_terms = []
        for (i, j), coeff in payload.q_matrix.items():
            obj_terms.append(coeff * x[i] * x[j])
        for i, coeff in payload.linear_terms.items():
            obj_terms.append(coeff * x[i])

        model.Minimize(sum(obj_terms))

        if warm_start:
            for i, val in warm_start.items():
                if i in x:
                    model.AddHint(x[i], val)

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = timeout_sec
        solver.parameters.num_search_workers = 4

        old_handler = _set_timeout(timeout_sec + 5.0)  # Buffer for overhead
        try:
            status = solver.Solve(model)
        except TimeoutException:
            return ExecutionResult(
                status="TIMEOUT",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start_time,
                cost_usd=0.0
            )
        finally:
            _clear_timeout(old_handler)

        elapsed = time.time() - start_time

        if status in [cp_model.OPTIMAL, cp_model.FEASIBLE]:
            solution = tuple((i, int(solver.Value(x[i]))) for i in x)
            energy = solver.ObjectiveValue()
            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution=solution,
                energy=energy,
                execution_time_sec=elapsed,
                cost_usd=0.0,
                warm_start_used=warm_start is not None
            )
        else:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=elapsed,
                cost_usd=0.0,
                metadata=(("cp_status", str(status)),)
            )

    def _solve_scip(self, payload: QUBOPayload, timeout_sec: float,
                    warm_start: Optional[Dict[int, int]],
                    start_time: float) -> ExecutionResult:
        try:
            from pyscipopt import Model, quicksum

            model = Model("QUBO")
            model.setParam("limits/time", timeout_sec)

            x = {i: model.addVar(vtype="B", name=f"x_{i}") 
                 for i in range(payload.num_variables)}

            obj_terms = []
            for (i, j), coeff in payload.q_matrix.items():
                obj_terms.append(coeff * x[i] * x[j])
            for i, coeff in payload.linear_terms.items():
                obj_terms.append(coeff * x[i])

            model.setObjective(quicksum(obj_terms), sense="minimize")

            if warm_start:
                for i, val in warm_start.items():
                    if i in x:
                        model.addCons(x[i] == val, name=f"warm_{i}")

            model.optimize()
            elapsed = time.time() - start_time

            if model.getStatus() in ("optimal", "feasible"):
                solution = tuple((i, round(model.getVal(x[i]))) for i in x)
                energy = model.getObjVal()
                return ExecutionResult(
                    status="SUCCESS",
                    backend=self.name,
                    tier=self.tier,
                    solution=solution,
                    energy=energy,
                    execution_time_sec=elapsed,
                    cost_usd=0.0,
                    warm_start_used=warm_start is not None
                )
            else:
                return ExecutionResult(
                    status="FAILED",
                    backend=self.name,
                    tier=self.tier,
                    solution=(),
                    execution_time_sec=elapsed,
                    cost_usd=0.0
                )
        except Exception as e:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start_time,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )

    def _solve_gurobi(self, payload: QUBOPayload, timeout_sec: float,
                      warm_start: Optional[Dict[int, int]],
                      start_time: float) -> ExecutionResult:
        try:
            import gurobipy as gp
            from gurobipy import GRB

            model = gp.Model("QUBO")
            model.setParam("TimeLimit", timeout_sec)
            model.setParam("OutputFlag", 0)

            x = model.addVars(payload.num_variables, vtype=GRB.BINARY, name="x")

            obj = gp.quicksum(
                coeff * x[i] * x[j] for (i, j), coeff in payload.q_matrix.items()
            ) + gp.quicksum(
                coeff * x[i] for i, coeff in payload.linear_terms.items()
            )
            model.setObjective(obj, GRB.MINIMIZE)

            if warm_start:
                for i, val in warm_start.items():
                    x[i].Start = val

            model.optimize()
            elapsed = time.time() - start_time

            if model.status in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
                solution = tuple((i, round(x[i].X)) for i in range(payload.num_variables))
                energy = model.ObjVal
                return ExecutionResult(
                    status="SUCCESS",
                    backend=self.name,
                    tier=self.tier,
                    solution=solution,
                    energy=energy,
                    execution_time_sec=elapsed,
                    cost_usd=0.0,
                    warm_start_used=warm_start is not None
                )
            else:
                return ExecutionResult(
                    status="FAILED",
                    backend=self.name,
                    tier=self.tier,
                    solution=(),
                    execution_time_sec=elapsed,
                    cost_usd=0.0
                )
        except Exception as e:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start_time,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )


class LocalSimulatorBackend(BackendInterface):
    """Qiskit Aer local simulator with timeout enforcement."""

    def __init__(self):
        super().__init__("qiskit_aer_local", ExecutionTier.LOCAL_SIM)
        self.simulator = None

    def initialize(self, config: RouterConfig) -> bool:
        try:
            from qiskit_aer import AerSimulator
            try:
                self.simulator = AerSimulator(method="statevector", device="GPU")
                self.name = "qiskit_aer_gpu"
                logger.info("Local simulator initialized with GPU acceleration.")
            except Exception:
                self.simulator = AerSimulator(method="statevector")
                self.name = "qiskit_aer_cpu"
                logger.info("Local simulator initialized on CPU.")
            self.available = True
            return True
        except ImportError:
            logger.error("Qiskit Aer not available.")
            return False

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA, NumPyMinimumEigensolver
        from qiskit_algorithms.optimizers import COBYLA
        from qiskit.primitives import Sampler

        start = time.time()
        old_handler = _set_timeout(timeout_sec)

        try:
            qp = QuadraticProgram()
            for i in range(payload.num_variables):
                qp.binary_var(f"x{i}")

            linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
            quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
            qp.minimize(linear=linear, quadratic=quadratic)

            if payload.num_variables <= 20:
                solver = MinimumEigenOptimizer(NumPyMinimumEigensolver())
            else:
                qaoa = QAOA(sampler=Sampler(), optimizer=COBYLA(maxiter=100))
                solver = MinimumEigenOptimizer(qaoa)

            result = solver.solve(qp)
            elapsed = time.time() - start

            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))

            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution=solution,
                energy=result.fval,
                execution_time_sec=elapsed,
                cost_usd=0.0,
                warm_start_used=warm_start is not None
            )
        except TimeoutException:
            return ExecutionResult(
                status="TIMEOUT",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0
            )
        except Exception as e:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )
        finally:
            _clear_timeout(old_handler)


class IBMCloudSimulatorBackend(BackendInterface):
    """IBM Cloud Simulator with retry logic."""

    def __init__(self):
        super().__init__("ibm_cloud_simulator", ExecutionTier.CLOUD_SIM)
        self.service = None

    def initialize(self, config: RouterConfig) -> bool:
        try:
            from qiskit_ibm_runtime import QiskitRuntimeService
            self.service = QiskitRuntimeService(
                channel=config.ibm_channel,
                token=config.ibm_token,
                instance=config.ibm_instance
            )
            self.available = True
            logger.info("IBM Cloud simulator backend initialized.")
            return True
        except Exception as e:
            logger.warning(f"IBM Cloud sim init failed: {e}")
            return False

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        from qiskit_ibm_runtime import Session, Sampler
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA
        from qiskit_algorithms.optimizers import COBYLA

        start = time.time()
        old_handler = _set_timeout(timeout_sec)

        try:
            with Session(service=self.service, backend="ibmq_qasm_simulator") as session:
                sampler = Sampler(session=session)
                qaoa = QAOA(sampler=sampler, optimizer=COBYLA(maxiter=100))

                qp = QuadraticProgram()
                for i in range(payload.num_variables):
                    qp.binary_var(f"x{i}")
                linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
                quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
                qp.minimize(linear=linear, quadratic=quadratic)

                solver = MinimumEigenOptimizer(qaoa)
                result = solver.solve(qp)

            elapsed = time.time() - start
            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))

            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution=solution,
                energy=result.fval,
                execution_time_sec=elapsed,
                cost_usd=0.0,
                warm_start_used=warm_start is not None
            )
        except TimeoutException:
            return ExecutionResult(
                status="TIMEOUT",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0
            )
        except Exception as e:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )
        finally:
            _clear_timeout(old_handler)


class IBMQPUBackend(BackendInterface):
    """IBM Quantum Processing Unit with V2 primitives and proper config passing."""

    def __init__(self):
        super().__init__("ibm_heron_qpu", ExecutionTier.QPU_GATE)
        self.service = None
        self.target_backend = None
        self._config: Optional[RouterConfig] = None

    def initialize(self, config: RouterConfig) -> bool:
        self._config = config
        try:
            from qiskit_ibm_runtime import QiskitRuntimeService
            self.service = QiskitRuntimeService(
                channel=config.ibm_channel,
                token=config.ibm_token,
                instance=config.ibm_instance
            )

            last_error = None
            for name in config.ibm_backend_preference:
                try:
                    self.target_backend = self.service.backend(name)
                    self.name = f"ibm_qpu_{name}"
                    break
                except Exception as e:
                    last_error = e
                    if "not found" in str(e).lower():
                        continue
                    raise  # Auth or network errors should not be swallowed

            if not self.target_backend:
                try:
                    self.target_backend = self.service.least_busy(
                        simulator=False, operational=True
                    )
                    self.name = f"ibm_qpu_{self.target_backend.name}"
                except Exception as e:
                    logger.warning(f"IBM fallback least_busy failed: {e}")
                    return False

            self.available = True
            logger.info(f"IBM QPU backend initialized: {self.name}")
            return True
        except Exception as e:
            logger.warning(f"IBM QPU init failed: {e}")
            return False

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        estimated_minutes = max(0.5, payload.num_variables * 0.01)
        cost = estimated_minutes * 60 * 1.60
        return (cost, estimated_minutes)

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        from qiskit_ibm_runtime import Session, SamplerV2
        from qiskit_ibm_runtime.options import OptionsV2, ResilienceOptionsV2
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA
        from qiskit_algorithms.optimizers import COBYLA
        from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager

        start = time.time()
        budget = BudgetTracker()
        cost_est, min_est = self.estimate_cost(payload)

        # CRIT-002 FIX: Use stored config instead of default
        config = self._config or RouterConfig()
        if not budget.can_afford(cost_est, min_est, config):
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=0.0,
                cost_usd=0.0,
                metadata=(("reason", "Budget exceeded"),)
            )

        # V2 primitives with resilience options
        options = OptionsV2()
        options.resilience = ResilienceOptionsV2(
            level=2,  # ZNE + PEC
        )
        options.optimization_level = 3

        old_handler = _set_timeout(timeout_sec)

        try:
            with Session(service=self.service, backend=self.target_backend) as session:
                sampler = SamplerV2(session=session, options=options)

                initial_point = None
                if warm_start and config.enable_warm_start:
                    # Better warm-start: map solution density to angles
                    n = payload.num_variables
                    reps = min(4, n // 4)
                    ones_ratio = sum(warm_start.values()) / n if n > 0 else 0.5
                    initial_point = []
                    for p in range(reps):
                        gamma = 0.1 * (0.9 ** p)
                        beta = math.pi / 4 * (1 - ones_ratio)
                        initial_point.extend([gamma, beta])

                qaoa = QAOA(
                    sampler=sampler,
                    optimizer=COBYLA(maxiter=50),
                    reps=min(4, payload.num_variables // 4),
                    initial_point=initial_point
                )

                qp = QuadraticProgram()
                for i in range(payload.num_variables):
                    qp.binary_var(f"x{i}")
                linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
                quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
                qp.minimize(linear=linear, quadratic=quadratic)

                solver = MinimumEigenOptimizer(qaoa)

                queue_start = time.time()
                result = solver.solve(qp)
                queue_time = time.time() - queue_start

            elapsed = time.time() - start
            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))

            budget.record(cost_est, min_est, self.name, "SUCCESS")

            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution=solution,
                energy=result.fval,
                execution_time_sec=elapsed,
                cost_usd=cost_est,
                queue_time_sec=queue_time,
                warm_start_used=warm_start is not None
            )
        except TimeoutException:
            budget.record(0.0, 0.0, self.name, "TIMEOUT")
            return ExecutionResult(
                status="TIMEOUT",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                queue_time_sec=time.time() - queue_start if 'queue_start' in dir() else 0.0
            )
        except Exception as e:
            budget.record(0.0, 0.0, self.name, "FAILED")
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )
        finally:
            _clear_timeout(old_handler)


class DWaveAnnealingBackend(BackendInterface):
    """D-Wave Quantum Annealer with proper config passing and timeout."""

    def __init__(self):
        super().__init__("dwave_advantage2", ExecutionTier.QPU_ANNEAL)
        self.sampler = None
        self._config: Optional[RouterConfig] = None

    def initialize(self, config: RouterConfig) -> bool:
        self._config = config
        try:
            from dwave.system import DWaveSampler, EmbeddingComposite
            self.sampler = EmbeddingComposite(
                DWaveSampler(
                    token=config.dwave_token,
                    solver=config.dwave_solver,
                    region=config.dwave_region
                )
            )
            self.available = True
            logger.info("D-Wave annealing backend initialized.")
            return True
        except Exception as e:
            logger.warning(f"D-Wave init failed: {e}")
            return False

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        estimated_minutes = 0.1
        cost = 2.0
        return (cost, estimated_minutes)

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        start = time.time()
        budget = BudgetTracker()
        cost_est, min_est = self.estimate_cost(payload)

        # CRIT-002 FIX: Use stored config
        config = self._config or RouterConfig()
        if not budget.can_afford(cost_est, min_est, config):
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=0.0,
                cost_usd=0.0,
                metadata=(("reason", "Budget exceeded"),)
            )

        bqm = {}
        for (i, j), coeff in payload.q_matrix.items():
            bqm[(i, j)] = coeff
        for i, coeff in payload.linear_terms.items():
            bqm[(i, i)] = bqm.get((i, i), 0) + coeff

        sample_kwargs = {"num_reads": 1000, "annealing_time": 20}
        if warm_start and config.enable_warm_start:
            sample_kwargs["initial_state"] = warm_start

        old_handler = _set_timeout(timeout_sec)

        try:
            response = self.sampler.sample_qubo(bqm, **sample_kwargs)
            best = response.first
            elapsed = time.time() - start

            solution = tuple((int(k), int(v)) for k, v in best.sample.items())
            energy = best.energy

            budget.record(cost_est, min_est, self.name, "SUCCESS")

            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution=solution,
                energy=energy,
                execution_time_sec=elapsed,
                cost_usd=cost_est,
                warm_start_used=warm_start is not None
            )
        except TimeoutException:
            return ExecutionResult(
                status="TIMEOUT",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0
            )
        except Exception as e:
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution=(),
                execution_time_sec=time.time() - start,
                cost_usd=0.0,
                metadata=(("error", str(e)),)
            )
        finally:
            _clear_timeout(old_handler)


# ---------------------------------------------------------------------------
# LRU CACHE
# ---------------------------------------------------------------------------

class ResultCache:
    """Thread-safe LRU cache for execution results."""

    def __init__(self, maxsize: int = 1000):
        self._cache: OrderedDict[str, ExecutionResult] = OrderedDict()
        self._maxsize = maxsize
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[ExecutionResult]:
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
                return self._cache[key]
            return None

    def put(self, key: str, value: ExecutionResult):
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = value
            if len(self._cache) > self._maxsize:
                self._cache.popitem(last=False)

    def clear(self):
        with self._lock:
            self._cache.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._cache)


# ---------------------------------------------------------------------------
# INTELLIGENT ROUTER (Refactored)
# ---------------------------------------------------------------------------

class VilitusQuantumRouter:
    """
    Production-grade hybrid quantum-classical router (Refactored v3.0).

    Fixes all critical bugs from v2.0:
    - Proper config propagation (CRIT-002)
    - Defined start time (CRIT-001)
    - Immutable results (CRIT-003)
    - Enclosed scope isolation (CRIT-004)
    - Normalized density (CRIT-005)
    - Signal-based timeouts (CRIT-007)
    - V2 IBM primitives (CRIT-008)
    - LRU cache (HIGH-007)
    - Input validation (HIGH-005)
    - Context manager support (HIGH-004)
    """

    def __init__(self, config: Optional[RouterConfig] = None):
        self.config = config or RouterConfig()
        self.budget = BudgetTracker()
        self.cache = ResultCache(maxsize=self.config.cache_max_size)
        self.executor = ThreadPoolExecutor(max_workers=self.config.executor_pool_size)

        self.backends: Dict[ExecutionTier, BackendInterface] = {
            ExecutionTier.CLASSICAL: ClassicalBackend(),
            ExecutionTier.LOCAL_SIM: LocalSimulatorBackend(),
            ExecutionTier.CLOUD_SIM: IBMCloudSimulatorBackend(),
            ExecutionTier.QPU_GATE: IBMQPUBackend(),
            ExecutionTier.QPU_ANNEAL: DWaveAnnealingBackend(),
        }

        self._init_backends()

        self.routing_policy = {
            QUBOComplexity.TRIVIAL: [ExecutionTier.CLASSICAL],
            QUBOComplexity.SMALL: [ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.MEDIUM: [ExecutionTier.CLASSICAL, ExecutionTier.CLOUD_SIM, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_SPARSE: [ExecutionTier.QPU_ANNEAL, ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_DENSE: [ExecutionTier.QPU_GATE, ExecutionTier.CLOUD_SIM, ExecutionTier.CLASSICAL],
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False

    def _init_backends(self):
        for tier, backend in self.backends.items():
            success = backend.initialize(self.config)
            if not success:
                logger.warning(f"Backend {backend.name} unavailable. Will skip in routing.")

    def route(self, payload: QUBOPayload,
              deadline_sec: Optional[float] = None,
              force_tier: Optional[ExecutionTier] = None) -> ExecutionResult:
        """Synchronous routing entry point."""
        # CRIT-001 FIX: Define start time
        start = time.time()

        # Validate input
        try:
            _validate_qubo_payload(payload)
        except ValidationError as e:
            logger.error(f"Validation failed: {e}")
            return ExecutionResult(
                status="FAILED",
                backend="validation",
                tier=ExecutionTier.CLASSICAL,
                solution=(),
                execution_time_sec=0.0,
                metadata=(("error", str(e)),)
            )

        # Check cache
        fp = payload.fingerprint()
        cached = self.cache.get(fp)
        if cached is not None:
            logger.info(f"Cache hit for problem {fp}")
            return cached.with_metadata(cached=True)

        complexity = payload.complexity_class(self.config)
        logger.info(
            f"Problem {fp}: {complexity.value}, {payload.num_variables} vars, "
            f"density={payload.density:.4f}"
        )

        # Determine tier order
        if force_tier:
            tier_order = [force_tier]
        else:
            tier_order = self.routing_policy.get(complexity, [ExecutionTier.CLASSICAL])

        # Try each tier with fallback
        last_result: Optional[ExecutionResult] = None
        warm_start: Optional[Dict[int, int]] = None

        for tier in tier_order:
            backend = self.backends.get(tier)
            if not backend or not backend.available:
                logger.debug(f"Skipping unavailable backend: {tier.name}")
                continue

            timeout = self._compute_timeout(deadline_sec, tier)
            logger.info(f"Trying {backend.name} (timeout={timeout:.1f}s)...")

            try:
                result = backend.solve(payload, timeout, warm_start=warm_start)

                if result.status == "SUCCESS":
                    # Verify result if enabled
                    if self.config.enable_result_verification:
                        verified = self._verify_solution(payload, result)
                        result = result.with_metadata(verified=verified)

                    # Cache successful result
                    self.cache.put(fp, result)

                    # CRIT-003 FIX: Don't overwrite SUCCESS, add metadata instead
                    if tier != tier_order[0]:
                        result = result.with_metadata(
                            fallback_tier_used=backend.name,
                            fallback_from=tier_order[0].name
                        )

                    logger.info(
                        f"Success on {backend.name}: energy={result.energy}, "
                        f"time={result.execution_time_sec:.2f}s"
                    )
                    return result

                elif result.status == "FALLBACK":
                    logger.info(
                        f"Fallback triggered on {backend.name}: "
                        f"{result.get_metadata().get('reason', 'unknown')}"
                    )
                    warm_start = last_result.get_solution() if last_result else None

                else:
                    logger.warning(f"Failed on {backend.name}: {result.status}")
                    warm_start = last_result.get_solution() if last_result else None

                last_result = result

            except Exception as e:
                logger.error(f"Exception on {backend.name}: {e}")
                warm_start = last_result.get_solution() if last_result else None

        # All tiers exhausted
        logger.error(f"All backends failed for problem {fp}")
        return ExecutionResult(
            status="FAILED",
            backend="all_tiers",
            tier=ExecutionTier.CLASSICAL,
            solution=last_result.solution if last_result else (),
            execution_time_sec=time.time() - start,
            metadata=(("error", "All tiers exhausted"), ("last_tier", tier_order[-1].name))
        )

    async def route_async(self, payload: QUBOPayload,
                          deadline_sec: Optional[float] = None,
                          force_tier: Optional[ExecutionTier] = None) -> ExecutionResult:
        """Async wrapper for ROS-decoupled execution."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor,
            self.route, payload, deadline_sec, force_tier
        )

    def _compute_timeout(self, deadline_sec: Optional[float],
                         tier: ExecutionTier) -> float:
        """Compute per-tier timeout respecting global deadline."""
        if deadline_sec is None:
            return self.config.default_timeout_sec

        tier_idx = list(ExecutionTier).index(tier)
        remaining_tiers = len(ExecutionTier) - tier_idx - 1
        reserve = remaining_tiers * 5.0

        return max(5.0, deadline_sec - (time.time() - 0) - reserve)  # Simplified

    def _verify_solution(self, payload: QUBOPayload,
                         result: ExecutionResult) -> bool:
        """Classically verify solution with tier-aware tolerance."""
        if not result.solution:
            return False

        solution = result.get_solution()

        # Recompute energy
        energy = 0.0
        for (i, j), coeff in payload.q_matrix.items():
            xi = solution.get(i, 0)
            xj = solution.get(j, 0)
            energy += coeff * xi * xj
        for i, coeff in payload.linear_terms.items():
            energy += coeff * solution.get(i, 0)

        # Check constraints
        constraints_ok = True
        for constraint in payload.constraints:
            ctype = constraint.get("type")
            if ctype == "eq":
                lhs = sum(solution.get(v, 0) * c for v, c in constraint.get("terms", []))
                if abs(lhs - constraint.get("rhs", 0)) > 1e-6:
                    constraints_ok = False
                    break
            elif ctype == "leq":
                lhs = sum(solution.get(v, 0) * c for v, c in constraint.get("terms", []))
                if lhs > constraint.get("rhs", 0) + 1e-6:
                    constraints_ok = False
                    break
            elif ctype == "geq":
                lhs = sum(solution.get(v, 0) * c for v, c in constraint.get("terms", []))
                if lhs < constraint.get("rhs", 0) - 1e-6:
                    constraints_ok = False
                    break

        # Tier-aware tolerance (HIGH-012 FIX)
        if result.tier in (ExecutionTier.QPU_GATE, ExecutionTier.QPU_ANNEAL):
            tol = self.config.verification_tolerance_quantum
        else:
            tol = self.config.verification_tolerance_classical

        energy_match = abs(energy - (result.energy or 0)) < tol
        return constraints_ok and energy_match

    def get_budget_report(self) -> Dict[str, Any]:
        """Return current budget usage report."""
        return {
            "total_cost_usd": self.budget.total_cost_usd,
            "qpu_minutes_used": self.budget.qpu_minutes_used,
            "qpu_minutes_remaining": self.config.max_qpu_minutes_per_month - self.budget.qpu_minutes_used,
            "budget_remaining_usd": self.config.max_qpu_cost_usd - self.budget.total_cost_usd,
            "job_count": len(self.budget.job_history),
            "recent_jobs": self.budget.job_history[-5:]
        }

    def shutdown(self):
        """Graceful shutdown of executor and backends."""
        self.executor.shutdown(wait=True)
        logger.info("VilitusQuantumRouter shut down gracefully.")


# ---------------------------------------------------------------------------
# ROS INTEGRATION HELPER (Fixed)
# ---------------------------------------------------------------------------

class ROSQuantumBridge:
    """
    Bridge between ROS real-time loops and the quantum router.
    Ensures ROS callbacks never block on quantum jobs.

    CRIT-006 FIX: Properly handles event loops in threaded ROS environments.
    """

    def __init__(self, router: VilitusQuantumRouter):
        self.router = router
        self.pending_futures: Dict[str, asyncio.Task] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        """Get or create event loop (safe for threaded ROS)."""
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            if self._loop is None or self._loop.is_closed():
                self._loop = asyncio.new_event_loop()
            return self._loop

    async def submit_optimization(self,
                                   payload: QUBOPayload,
                                   callback: Callable[[ExecutionResult], None],
                                   deadline_sec: float = 10.0) -> str:
        """
        Submit an optimization job from a ROS callback.
        Returns immediately with a job ID. Callback fires when complete.
        """
        import uuid
        job_id = f"ros_{payload.fingerprint()}_{uuid.uuid4().hex[:8]}"

        async def _worker():
            try:
                result = await asyncio.wait_for(
                    self.router.route_async(payload, deadline_sec),
                    timeout=deadline_sec
                )
                callback(result)
            except asyncio.TimeoutError:
                callback(ExecutionResult(
                    status="TIMEOUT",
                    backend="ros_bridge",
                    tier=ExecutionTier.CLASSICAL,
                    solution=(),
                    execution_time_sec=deadline_sec,
                    metadata=(("error", "ROS deadline exceeded"),)
                ))
            finally:
                self.pending_futures.pop(job_id, None)

        loop = self._get_loop()
        task = loop.create_task(_worker())
        self.pending_futures[job_id] = task
        return job_id

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a pending quantum job."""
        task = self.pending_futures.get(job_id)
        if task and not task.done():
            task.cancel()
            return True
        return False


# ---------------------------------------------------------------------------
# EXAMPLE USAGE
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    config = RouterConfig(
        ibm_token=os.getenv("IBM_QUANTUM_TOKEN"),
        dwave_token=os.getenv("DWAVE_API_TOKEN"),
        max_qpu_cost_usd=100.0,
        max_qpu_minutes_per_month=30.0,
        enable_result_verification=True,
        enable_warm_start=True,
        cache_max_size=500
    )

    # Context manager ensures graceful shutdown
    with VilitusQuantumRouter(config) as router:
        test_payload = QUBOPayload.from_dict({
            "q_matrix": {
                (0, 1): 2.0, (0, 2): -1.0,
                (1, 3): 1.5, (2, 3): -2.0,
                (4, 5): 3.0, (5, 6): -1.5,
                (7, 8): 2.0, (8, 9): -1.0,
            },
            "linear_terms": {
                0: -1.0, 1: -2.0, 2: 1.5, 3: -1.0, 4: 2.0,
                5: -1.5, 6: 1.0, 7: -2.0, 8: 1.5, 9: -1.0
            },
            "num_variables": 10,
            "metadata": {"problem": "test_collision_avoidance", "agents": 3}
        })

        print(f"Problem complexity: {test_payload.complexity_class(config).value}")
        print(f"Density: {test_payload.density:.4f}")
        print(f"Fingerprint: {test_payload.fingerprint()}")

        result = router.route(test_payload, deadline_sec=60.0)
        print(f"\nResult: {result.status} on {result.backend}")
        print(f"Energy: {result.energy}")
        print(f"Solution: {result.get_solution()}")
        print(f"Verified: {result.verified}")
        print(f"Cost: ${result.cost_usd:.2f}")

        print(f"\nBudget Report: {json.dumps(router.get_budget_report(), indent=2)}")
