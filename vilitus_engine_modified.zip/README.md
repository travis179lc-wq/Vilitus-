# VILITUS ENGINE v3.0

**Hybrid Quantum-Classical Robotics Optimization Platform**

[![CI](https://github.com/vilitus/vilitus-engine/actions/workflows/ci.yml/badge.svg)](https://github.com/vilitus/vilitus-engine/actions)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

---

## Overview

VILITUS is a production-grade hybrid quantum-classical optimization platform for robotics and autonomous systems. It integrates:

- **Mission Management** — Goal tracking, constraint enforcement, priority handling
- **Cognitive Engine** — Perception fusion, world understanding, planning, optimization, reasoning
- **Quantum Router** — Intelligent routing of QUBO problems across 6 execution tiers (Classical → QPU)
- **Safety Arbitration** — Real-time collision avoidance and velocity clamping
- **Isaac Sim Integration** — NVIDIA Omniverse-based simulation and control
- **Observability** — Prometheus metrics, Grafana dashboards, structured logging

---

## Quick Start

### Installation

```bash
# Clone repository
git clone https://github.com/vilitus/vilitus-engine.git
cd vilitus-engine

# Install with pip (classical + quantum)
pip install -e ".[quantum]"

# Or install everything
pip install -e ".[all,dev]"
```

### Docker (Recommended for Production)

```bash
# Copy environment template
cp .env.example .env
# Edit .env with your quantum API tokens

# Start quantum router + observability stack
docker-compose up -d

# View metrics: http://localhost:3000 (Grafana, admin/admin)
# View Prometheus: http://localhost:9091
```

### Basic Usage

```python
from vilitus import VilitusQuantumRouter, QUBOPayload, RouterConfig

config = RouterConfig(ibm_token="YOUR_TOKEN")
router = VilitusQuantumRouter(config)

payload = QUBOPayload(
    q_matrix={(0, 1): 2.0, (1, 2): -1.0},
    linear_terms={0: -1.0, 1: -2.0, 2: 1.5},
    num_variables=3
)

result = router.route(payload, deadline_sec=60.0)
print(f"Solved by {result.backend}: energy={result.energy}")
```

### Isaac Sim Simulation

```bash
# Requires NVIDIA Omniverse Isaac Sim installed
python -m vilitus.main
```

---

## Project Structure

```
vilitus-engine/
├── vilitus/
│   ├── __init__.py
│   ├── main.py                        # Isaac Sim entry point
│   ├── mission_schema.py              # Mission dataclasses
│   ├── mission_manager.py             # Mission lifecycle
│   ├── operational_context.py         # Context representation
│   ├── objective_tracker.py           # Progress tracking
│   ├── constraint_engine.py           # Constraint validation
│   ├── intent_representation.py       # Action tensor creation
│   ├── safety_arbitration.py          # Safety limits
│   ├── isaac_controller.py           # Isaac Sim robot control
│   ├── visualization.py              # Matplotlib dashboards
│   ├── quantum_router.py              # Quantum-classical router (v3.0)
│   ├── quantum_router_v2.py          # Original v2.0 router
│   ├── refactored.py                 # Hardened v3.0 router
│   ├── extended.py                   # Extended features v3.0
│   └── cognitive_engine/
│       ├── __init__.py
│       ├── cognitive_engine.py       # Main cognitive loop
│       ├── perception_fusion.py      # Sensor fusion
│       ├── world_understanding.py    # Scene interpretation
│       ├── planner.py                # Path planning
│       ├── optimizer.py              # Plan optimization
│       └── reasoning_engine.py       # Decision reasoning
├── tests/
│   ├── test_vilitus_quantum_router.py
│   └── test_mission_manager.py
├── deploy/
│   ├── prometheus.yml
│   └── grafana/
│       ├── datasources/
│       └── dashboards/
├── .github/
│   └── workflows/
│       └── ci.yml
├── pyproject.toml
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── README.md
```

---

## Architecture

### Quantum Router

The quantum router is the core optimization engine. It automatically routes QUBO problems to the most appropriate backend based on problem complexity, budget constraints, and backend availability.

**Execution Tiers:**
1. `CLASSICAL` — OR-Tools, SCIP, Gurobi (CPU)
2. `LOCAL_SIM` — Qiskit Aer (GPU/CPU)
3. `CLOUD_SIM` — IBM Cloud Simulator (free)
4. `QUANTUM_INSPIRED` — D-Wave Hybrid
5. `QPU_GATE` — IBM Heron, IonQ Aria (gate-based)
6. `QPU_ANNEAL` — D-Wave Advantage2 (annealing)

**Key Features:**
- Auto problem sizing and complexity classification
- Budget guardrails with thread-safe tracking
- Fallback chaining with warm-start propagation
- Result verification with tier-aware tolerance
- Async execution with ROS decoupling
- Prometheus metrics and Grafana dashboards

### Cognitive Engine

The cognitive engine processes operational context through a 5-stage pipeline:

```
Perception Fusion → World Understanding → Planner → Optimizer → Reasoning Engine
```

Each stage produces a tensor representation that feeds into the next, culminating in a 48×6 action tensor (velocity, heading, acceleration, behavior).

### Mission Manager

Handles mission lifecycle:
- Load → Track → Validate → Complete/Abort
- Constraint enforcement in real-time
- Progress history and rollback capability

---

## Configuration

All configuration is centralized in `RouterConfig` and environment variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `IBM_QUANTUM_TOKEN` | For IBM QPU | IBM Quantum API key |
| `DWAVE_API_TOKEN` | For D-Wave | D-Wave Leap token |
| `IONQ_API_KEY` | For IonQ | IonQ cloud API key |
| `VILITUS_MAX_QPU_COST` | No | Monthly budget (default: $500) |
| `VILITUS_LOG_LEVEL` | No | DEBUG, INFO, WARNING, ERROR |
| `VILITUS_METRICS_PORT` | No | Prometheus port (default: 9090) |

See `.env.example` for full configuration options.

---

## Testing

```bash
# Run all tests
pytest tests/ -v

# Run only classical tests (no quantum credentials needed)
pytest tests/ -m "not quantum and not isaac" -v

# Run with coverage
pytest tests/ --cov=vilitus --cov-report=html

# Run quantum tests (requires credentials)
pytest tests/ -m "quantum" -v
```

---

## Monitoring

When running via Docker Compose:

- **Grafana:** http://localhost:3000 (default login: admin/admin)
- **Prometheus:** http://localhost:9091
- **Router Metrics:** http://localhost:9090/metrics

Key metrics:
- `vilitus_jobs_completed_total` — Job completion rate
- `vilitus_fallbacks_total` — Fallback frequency
- `vilitus_budget_remaining_usd` — Budget burn-down
- `vilitus_execution_duration_seconds` — Solve latency

---

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Install pre-commit hooks
pre-commit install

# Format code
black vilitus/ tests/
ruff check --fix vilitus/ tests/

# Type check
mypy vilitus/

# Run tests
pytest tests/ -v
```

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

## Citation

If you use VILITUS in your research, please cite:

```bibtex
@software{vilitus2026,
  title = {VILITUS Engine: Hybrid Quantum-Classical Robotics Optimization},
  author = {Vilitus Engineering Team},
  year = {2026},
  url = {https://github.com/vilitus/vilitus-engine}
}
```

---

## Support

- **Issues:** [GitHub Issues](https://github.com/vilitus/vilitus-engine/issues)
- **Documentation:** [ReadTheDocs](https://vilitus-engine.readthedocs.io)
- **Discussions:** [GitHub Discussions](https://github.com/vilitus/vilitus-engine/discussions)
