# VILITUS QUANTUM ROUTER v2.0 — Code Review & Bug Report
**Reviewer:** Automated Architecture Review  
**Date:** 2026-07-09  
**Scope:** Full static analysis, logic verification, and production-readiness assessment

---

## Executive Summary
The Vilitus Engine v2.0 demonstrates solid architectural foundations with its tiered routing strategy, budget guardrails, and ROS decoupling. However, **8 critical bugs**, **12 high-severity issues**, and **15 medium-severity concerns** were identified that prevent production deployment without remediation.

---

## 🔴 CRITICAL (Deployment Blockers)

### CRIT-001: Undefined Variable `start` in `route()` Fallback Path
**Location:** `VilitusQuantumRouter.route()` — line ~500  
**Issue:** When all tiers exhaust, the code references `start = time.time()` which was **never defined** in the method scope.
```python
execution_time_sec=time.time() - start,  # NameError: name 'start' is not defined
```
**Impact:** Complete crash on any fallback exhaustion path.  
**Fix:** Add `start = time.time()` at the top of `route()`.

### CRIT-002: Budget Tracker Uses Wrong Config Object
**Location:** `IBMQPUBackend.solve()`, `DWaveAnnealingBackend.solve()`  
**Issue:** Both backends instantiate `RouterConfig()` (default config) instead of using the router's actual config:
```python
if not budget.can_afford(cost_est, min_est, RouterConfig()):  # BUG: ignores user config!
```
**Impact:** Budget guardrails use default thresholds ($500, 60min) regardless of user settings. A user setting `max_qpu_cost_usd=10` would still be evaluated against $500.  
**Fix:** Pass `config` through the `solve()` signature or store it as instance state.

### CRIT-003: Fallback Success Overwrites Status to "FALLBACK"
**Location:** `VilitusQuantumRouter.route()`  
**Issue:** When a later tier succeeds after earlier tiers fail, the code mutates the result:
```python
if tier != tier_order[0]:
    result.status = "FALLBACK"  # BUG: Overwrites SUCCESS!
```
**Impact:** Calling code cannot distinguish between "solved successfully via fallback" and "actually failed". The `ExecutionResult` should remain `"SUCCESS"` with a metadata flag `{"fallback_from": "ibm_heron_qpu"}`.  
**Fix:** Add `metadata["fallback_tier_used"] = backend.name` instead of mutating status.

### CRIT-004: ClassicalBackend `_solve_ortools` Relies on Enclosing Scope
**Location:** `ClassicalBackend._solve_ortools()`  
**Issue:** The method references `start` defined in the enclosing `solve()` method. While Python closures allow this, it breaks if the method is ever called directly (e.g., in testing, subclassing, or refactoring).
**Impact:** Fragile code that breaks under any structural change.  
**Fix:** Pass `start_time` as an explicit parameter.

### CRIT-005: Density Calculation Double-Counts Diagonal Terms
**Location:** `QUBOPayload.density`  
**Issue:** If diagonal terms exist in both `q_matrix[(i,i)]` and `linear_terms[i]`, they are counted twice:
```python
actual = len(self.q_matrix) + len(self.linear_terms)  # Potential double-count
```
**Impact:** Problem complexity misclassification. A dense 100-var problem might be routed to D-Wave annealer incorrectly.  
**Fix:** Normalize diagonal terms into a single representation before counting.

### CRIT-006: ROS Bridge `asyncio.create_task` Without Event Loop
**Location:** `ROSQuantumBridge.submit_optimization()`  
**Issue:** `asyncio.create_task()` requires a running event loop. In ROS 1 (Python), callbacks run on separate threads without an event loop by default.  
**Impact:** `RuntimeError: no running event loop` when submitting from ROS callbacks.  
**Fix:** Use `asyncio.run_coroutine_threadsafe()` or ensure loop attachment per thread.

### CRIT-007: Missing Timeout Handling in Quantum Solvers
**Location:** `LocalSimulatorBackend.solve()`, `IBMCloudSimulatorBackend.solve()`  
**Issue:** The `timeout_sec` parameter is accepted but never enforced. QAOA with `COBYLA(maxiter=100)` can run indefinitely on ill-conditioned problems.  
**Impact:** ROS deadline violations and hung processes.  
**Fix:** Wrap solver execution in `signal.alarm()` (Unix) or `multiprocessing` with timeout.

### CRIT-008: Qiskit IBM Runtime API Drift (2026 Compatibility)
**Location:** `IBMQPUBackend.solve()`  
**Issue:** Uses `Options` class with `resilience_level = 2`. IBM deprecated `Options` in favor of `OptionsV2` and `EstimatorV2`/`SamplerV2` primitives in 2025-2026.  
**Impact:** Code will fail on current IBM Quantum Runtime.  
**Fix:** Migrate to `qiskit-ibm-runtime` >= 0.25 primitives with `EstimatorV2` and `ResilienceOptionsV2`.

---

## 🟠 HIGH (Stability / Correctness)

### HIGH-001: SCIP Solver is a Stub
**Location:** `ClassicalBackend._solve_scip()`  
**Issue:** Returns `FAILED` immediately with a placeholder message.  
**Fix:** Implement full SCIP wrapper or remove the stub and fail initialization cleanly.

### HIGH-002: No Circuit Depth Analysis for QPU Gate Backend
**Location:** `IBMQPUBackend`  
**Issue:** The backend does not check if the transpiled QAOA circuit fits within the target backend's `max_experiments` or qubit connectivity.  
**Impact:** Transpilation failure at runtime on restricted backends.

### HIGH-003: Warm-Start Initial Point is Heuristic Garbage
**Location:** `IBMQPUBackend.solve()`  
**Issue:** `initial_point = [0.1] * (2 * min(4, payload.num_variables // 2))` ignores the actual warm-start solution structure.  
**Fix:** Map warm-start hamming distance to mixer angle offsets using a proper QAOA warm-start formulation (Egger et al. 2021).

### HIGH-004: ThreadPoolExecutor Never Shuts Down on Exception
**Location:** `VilitusQuantumRouter.__init__` / `shutdown()`  
**Issue:** If the router crashes before `shutdown()` is called, the executor leaks threads.  
**Fix:** Implement `__enter__`/`__exit__` context manager protocol.

### HIGH-005: No Input Validation on QUBO Matrix
**Location:** `QUBOPayload.__init__`  
**Issue:** Accepts negative `num_variables`, non-symmetric matrices, or out-of-bound indices without validation.  
**Impact:** Cryptic downstream errors from solver libraries.

### HIGH-006: Constraint Verification Only Checks Equality
**Location:** `VilitusQuantumRouter._verify_solution()`  
**Issue:** Only `"eq"` constraints are verified. Inequality (`leq`, `geq`) and quadratic constraints are ignored.  
**Fix:** Expand verifier to handle all constraint types.

### HIGH-007: Cache Has No Eviction Policy
**Location:** `VilitusQuantumRouter.cache`  
**Issue:** Unbounded `Dict` growth. Long-running ROS nodes will OOM.  
**Fix:** Use `functools.lru_cache` or TTLCache with configurable limits.

### HIGH-008: D-Wave `sample_qubo` Ignores `timeout_sec`
**Location:** `DWaveAnnealingBackend.solve()`  
**Issue:** The `timeout_sec` parameter is not passed to D-Wave's solver.  
**Fix:** Use `dwave.cloud.Client` with `sampling_timeout` or post-processing timeout.

### HIGH-009: IBM Backend Preference Loop Swallows All Exceptions
**Location:** `IBMQPUBackend.initialize()`  
**Issue:** `except Exception: continue` masks authentication errors, network failures, and API deprecation.  
**Fix:** Distinguish between "backend not found" (skip) and "auth failed" (fatal).

### HIGH-010: `q_matrix` Keys Not Normalized
**Location:** `QUBOPayload`  
**Issue:** If `q_matrix` contains both `(i,j)` and `(j,i)`, they are treated as separate entries.  
**Fix:** Normalize to `i <= j` in constructor.

### HIGH-011: Missing Gurobi Backend
**Location:** `RouterConfig.classical_solver`  
**Issue:** Config accepts `"gurobi"` but no `GurobiBackend` class exists.  
**Fix:** Implement `GurobiBackend` or remove from config enum.

### HIGH-012: Energy Verification Fails for Floating-Point Noise
**Location:** `VilitusQuantumRouter._verify_solution()`  
**Issue:** `abs(energy - result.energy) < 1e-3` is too tight for quantum results with shot noise.  
**Fix:** Use relative tolerance or tier-aware tolerance (classical: 1e-6, quantum: 1e-2).

---

## 🟡 MEDIUM (Performance / Maintainability)

1. **No Metrics / Observability:** No Prometheus, OpenTelemetry, or structured logging hooks.
2. **Hard-Coded Routing Policy:** `routing_policy` dict is fixed; no user-defined policy injection.
3. **No Retry Logic:** Network blips to IBM Cloud cause immediate fallback instead of retry.
4. **Missing Type Hints:** Several `Dict[str, Any]` could be narrowed (e.g., `constraints` structure).
5. **No Problem Decomposition:** Large QUBOs (>1000 vars) are sent whole to QPU instead of being decomposed (e.g., QBSolv, D-Wave Hybrid).
6. **Logging Format Inconsistent:** Some logs use f-strings, others don't. No structured JSON logging option.
7. **No Dry-Run Mode:** Cannot estimate cost without actually submitting.
8. **Fingerprint Not Salted:** Cache collisions possible if two problems have identical structure but different semantics.
9. **No Circuit Optimization Pre-Pass:** QAOA circuits are not analyzed for CX-depth reduction.
10. **Missing `__all__` Export:** Module pollutes namespace with internal classes.
11. **No Graceful Degradation for Missing Optional Deps:** `ortools` ImportError is handled, but no fallback message to user.
12. **ROS Bridge Job ID Collision:** `time.time_ns()` can collide at high frequency; add UUID.
13. **No Benchmark Baselines:** No way to compare quantum result against classical upper bound.
14. **Config Mutable Default Arguments:** `ibm_backend_preference` uses `field(default_factory=...)` correctly, but `constraints` in `QUBOPayload` uses mutable default.
15. **No Version Pinning:** No `requirements.txt` or `pyproject.toml` for dependency management.

---

## 📊 Severity Distribution

| Severity | Count | Fix Before Production |
|----------|-------|----------------------|
| Critical | 8 | **Yes** |
| High | 12 | **Yes** |
| Medium | 15 | Recommended |

---

## Recommended Fix Priority

```
Week 1: CRIT-001, CRIT-002, CRIT-003, CRIT-004, CRIT-006, CRIT-007, CRIT-008
Week 2: HIGH-001, HIGH-005, HIGH-007, HIGH-009, HIGH-010, HIGH-012
Week 3: MEDIUM-01 (Metrics), MEDIUM-03 (Retry), MEDIUM-05 (Decomposition)
```
