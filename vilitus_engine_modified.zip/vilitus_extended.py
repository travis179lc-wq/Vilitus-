"""
VILITUS ENGINE v3.0 — EXTENDED FEATURES MODULE
===============================================
Adds: IonQ backend, custom routing policies, retry logic with exponential backoff,
      circuit depth analyzer, Prometheus metrics, problem decomposition,
      dry-run mode, and advanced warm-start strategies.

This module extends v2.0 without breaking the existing API.
"""

import os
import time
import asyncio
import logging
import hashlib
import json
import math
import random
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable, Tuple, Set
from enum import Enum, auto
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import deque
import threading
from functools import lru_cache
import warnings

# Prometheus metrics (optional dependency)
try:
    from prometheus_client import Counter, Histogram, Gauge, Info, start_http_server
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    # Stub classes for when prometheus is not installed
    class _StubMetric:
        def inc(self, *args, **kwargs): pass
        def observe(self, *args, **kwargs): pass
        def set(self, *args, **kwargs): pass
    Counter = Histogram = Gauge = Info = _StubMetric
    start_http_server = lambda *args, **kwargs: None

# Import base module
from vilitus_quantum_router_v2 import (
    ExecutionTier, QUBOComplexity, RouterConfig, QUBOPayload,
    ExecutionResult, BudgetTracker, BackendInterface, ClassicalBackend,
    LocalSimulatorBackend, IBMCloudSimulatorBackend, IBMQPUBackend,
    DWaveAnnealingBackend, VilitusQuantumRouter, ROSQuantumBridge
)

logger = logging.getLogger("VilitusQuantumRouter.v3")


# ============================================================================
# PROMETHEUS METRICS
# ============================================================================

class RouterMetrics:
    """Production observability hooks for the quantum router."""

    def __init__(self, port: Optional[int] = None):
        self._initialized = False
        if PROMETHEUS_AVAILABLE and port:
            start_http_server(port)
            self._initialized = True
            logger.info(f"Prometheus metrics exposed on port {port}")

        # Counters
        self.jobs_submitted = Counter(
            'vilitus_jobs_submitted_total',
            'Total optimization jobs submitted',
            ['complexity', 'tier']
        )
        self.jobs_completed = Counter(
            'vilitus_jobs_completed_total',
            'Total optimization jobs completed',
            ['status', 'backend']
        )
        self.fallbacks_triggered = Counter(
            'vilitus_fallbacks_total',
            'Number of tier fallbacks',
            ['from_tier', 'to_tier']
        )

        # Histograms
        self.execution_time = Histogram(
            'vilitus_execution_duration_seconds',
            'Time spent solving',
            ['backend'],
            buckets=[0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 10.0, 30.0, 60.0, 300.0]
        )
        self.queue_time = Histogram(
            'vilitus_queue_duration_seconds',
            'Time spent in QPU queue',
            ['backend'],
            buckets=[0.1, 1.0, 5.0, 10.0, 30.0, 60.0, 300.0, 600.0]
        )
        self.energy_distribution = Histogram(
            'vilitus_solution_energy',
            'Energy of returned solutions',
            ['backend'],
            buckets=[-100, -50, -20, -10, -5, -2, -1, 0, 1, 2, 5, 10, 20, 50, 100]
        )

        # Gauges
        self.active_jobs = Gauge(
            'vilitus_active_jobs',
            'Currently active optimization jobs'
        )
        self.budget_remaining = Gauge(
            'vilitus_budget_remaining_usd',
            'Remaining QPU budget in USD'
        )
        self.cache_size = Gauge(
            'vilitus_cache_entries',
            'Number of cached problem results'
        )

        # Info
        self.build_info = Info(
            'vilitus_build_info',
            'Build and version information'
        )
        self.build_info.info({'version': '3.0.0', 'platform': 'hybrid-quantum-classical'})

    def record_job(self, payload: QUBOPayload, result: ExecutionResult, 
                   complexity: QUBOComplexity, tier: ExecutionTier):
        """Record metrics for a completed job."""
        self.jobs_submitted.labels(complexity=complexity.value, tier=tier.name).inc()
        self.jobs_completed.labels(status=result.status, backend=result.backend).inc()
        self.execution_time.labels(backend=result.backend).observe(result.execution_time_sec)
        if result.queue_time_sec > 0:
            self.queue_time.labels(backend=result.backend).observe(result.queue_time_sec)
        if result.energy is not None:
            self.energy_distribution.labels(backend=result.backend).observe(result.energy)

    def record_fallback(self, from_tier: ExecutionTier, to_tier: ExecutionTier):
        self.fallbacks_triggered.labels(from_tier=from_tier.name, to_tier=to_tier.name).inc()


# ============================================================================
# IONQ BACKEND (Gate-based QPU)
# ============================================================================

class IonQBackend(BackendInterface):
    """
    IonQ Harmony / Aria / Forte backend via Qiskit IonQ provider.
    Supports native gates (GPi, GPi2, GZZ) and all-to-all connectivity.
    """

    def __init__(self):
        super().__init__("ionq_aria", ExecutionTier.QPU_GATE)
        self.provider = None
        self.backend = None

    def initialize(self, config: RouterConfig) -> bool:
        try:
            from qiskit_ionq import IonQProvider
            token = os.getenv("IONQ_API_KEY") or getattr(config, 'ionq_token', None)
            if not token:
                logger.warning("IONQ_API_KEY not set")
                return False
            self.provider = IonQProvider(token=token)
            # Prefer Aria, fallback to Harmony
            for name in ["ionq_aria_1", "ionq_harmony"]:
                try:
                    self.backend = self.provider.get_backend(name)
                    self.name = f"ionq_{name}"
                    break
                except Exception:
                    continue
            if not self.backend:
                self.backend = self.provider.backends()[0]
                self.name = f"ionq_{self.backend.name}"
            self.available = True
            logger.info(f"IonQ backend initialized: {self.name}")
            return True
        except Exception as e:
            logger.warning(f"IonQ init failed: {e}")
            return False

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        # IonQ: ~$0.01-0.03 per shot, typical QAOA needs 1024-8192 shots
        estimated_minutes = 0.5
        shots = max(1024, payload.num_variables * 100)
        cost = shots * 0.00001  # $0.00001 per shot (approximate)
        return (cost, estimated_minutes)

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        from qiskit import QuantumCircuit, transpile
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA
        from qiskit_algorithms.optimizers import COBYLA
        from qiskit.primitives import BackendSampler

        start = time.time()
        budget = BudgetTracker()
        cost_est, min_est = self.estimate_cost(payload)

        if not budget.can_afford(cost_est, min_est, RouterConfig()):
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution={},
                execution_time_sec=0.0,
                cost_usd=0.0,
                metadata={"reason": "Budget exceeded"}
            )

        # Build QAOA with IonQ-specific transpilation
        sampler = BackendSampler(backend=self.backend)
        qaoa = QAOA(sampler=sampler, optimizer=COBYLA(maxiter=50), reps=3)

        qp = QuadraticProgram()
        for i in range(payload.num_variables):
            qp.binary_var(f"x{i}")
        linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
        quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items() if i != j}
        qp.minimize(linear=linear, quadratic=quadratic)

        solver = MinimumEigenOptimizer(qaoa)
        result = solver.solve(qp)

        elapsed = time.time() - start
        solution = {i: int(result.x[i]) for i in range(payload.num_variables)}

        budget.record(cost_est, min_est, self.name, "SUCCESS")

        return ExecutionResult(
            status="SUCCESS",
            backend=self.name,
            tier=self.tier,
            solution=solution,
            energy=result.fval,
            execution_time_sec=elapsed,
            cost_usd=cost_est,
            warm_start_used=warm_start is not None
        )


# ============================================================================
# CIRCUIT DEPTH ANALYZER
# ============================================================================

@dataclass
class CircuitProfile:
    """Analysis of a QAOA circuit for backend compatibility."""
    num_qubits: int
    cx_depth: int
    total_gates: int
    two_qubit_count: int
    estimated_runtime_ms: float
    fits_ionq: bool
    fits_ibm_heron: bool
    fits_ibm_nighthawk: bool


class CircuitDepthAnalyzer:
    """
    Pre-flight circuit analysis to avoid submission to incompatible backends.
    """

    BACKEND_LIMITS = {
        "ibm_heron": {"max_qubits": 133, "max_cx_depth": 1000, "max_runtime_ms": 300000},
        "ibm_nighthawk": {"max_qubits": 156, "max_cx_depth": 1500, "max_runtime_ms": 300000},
        "ionq_aria_1": {"max_qubits": 25, "max_cx_depth": 10000, "max_runtime_ms": 60000},
        "ionq_harmony": {"max_qubits": 11, "max_cx_depth": 10000, "max_runtime_ms": 60000},
        "dwave_advantage2": {"max_qubits": 7000, "max_cx_depth": float('inf'), "max_runtime_ms": 20000},
    }

    @classmethod
    def analyze_qaoa_circuit(cls, num_variables: int, reps: int = 3) -> CircuitProfile:
        """
        Estimate QAOA circuit characteristics without full transpilation.

        QAOA on n variables with p reps:
        - Qubits: n (one per variable)
        - Cost layer: O(edges) CX gates per rep
        - Mixer layer: n RX gates per rep
        - Total CX: ~p * edges (assuming dense problem)
        """
        # Assume dense connectivity for worst-case analysis
        edges = num_variables * (num_variables - 1) // 2
        cx_per_rep = edges  # Each edge needs a CX in cost Hamiltonian
        total_cx = cx_per_rep * reps
        total_gates = total_cx + (num_variables * reps)  # CX + RX

        # Runtime estimates (very rough)
        gate_time_us = 0.5  # 500ns per gate average
        estimated_runtime_ms = total_gates * gate_time_us / 1000

        return CircuitProfile(
            num_qubits=num_variables,
            cx_depth=total_cx,
            total_gates=total_gates,
            two_qubit_count=total_cx,
            estimated_runtime_ms=estimated_runtime_ms,
            fits_ionq=num_variables <= 25 and total_cx <= 10000,
            fits_ibm_heron=num_variables <= 133 and total_cx <= 1000,
            fits_ibm_nighthawk=num_variables <= 156 and total_cx <= 1500
        )

    @classmethod
    def recommend_backend(cls, profile: CircuitProfile) -> List[str]:
        """Return list of backends that can execute this circuit."""
        compatible = []
        for name, limits in cls.BACKEND_LIMITS.items():
            if (profile.num_qubits <= limits["max_qubits"] and 
                profile.cx_depth <= limits["max_cx_depth"] and
                profile.estimated_runtime_ms <= limits["max_runtime_ms"]):
                compatible.append(name)
        return compatible


# ============================================================================
# PROBLEM DECOMPOSITION (QBSolv-style)
# ============================================================================

class QUBODecomposer:
    """
    Decompose large QUBOs into sub-problems for hybrid classical-quantum solving.
    Uses a greedy variable partitioning strategy.
    """

    def __init__(self, max_subproblem_size: int = 50):
        self.max_subproblem_size = max_subproblem_size

    def decompose(self, payload: QUBOPayload) -> List[QUBOPayload]:
        """
        Split a large QUBO into smaller sub-QUBOs.

        Strategy: Greedy clustering based on coupling strength.
        Variables with strong interactions are kept in the same subproblem.
        """
        if payload.num_variables <= self.max_subproblem_size:
            return [payload]

        # Build adjacency list with weights
        adj: Dict[int, Dict[int, float]] = {i: {} for i in range(payload.num_variables)}
        for (i, j), coeff in payload.q_matrix.items():
            adj[i][j] = abs(coeff)
            adj[j][i] = abs(coeff)

        # Greedy partitioning
        unassigned = set(range(payload.num_variables))
        clusters: List[Set[int]] = []

        while unassigned:
            seed = min(unassigned)  # deterministic
            cluster = {seed}
            unassigned.remove(seed)

            # Grow cluster by adding strongest connected unassigned variables
            while len(cluster) < self.max_subproblem_size and unassigned:
                # Find unassigned variable with strongest connection to cluster
                best_var = None
                best_strength = -1
                for var in unassigned:
                    strength = sum(adj[var].get(c, 0) for c in cluster)
                    if strength > best_strength:
                        best_strength = strength
                        best_var = var

                if best_var is None or best_strength == 0:
                    break

                cluster.add(best_var)
                unassigned.remove(best_var)

            clusters.append(cluster)

        # Build sub-QUBOs from clusters
        subproblems = []
        for cluster in clusters:
            cluster_list = sorted(cluster)
            idx_map = {old: new for new, old in enumerate(cluster_list)}

            sub_q = {}
            sub_linear = {}
            for (i, j), coeff in payload.q_matrix.items():
                if i in cluster and j in cluster:
                    sub_q[(idx_map[i], idx_map[j])] = coeff
            for i, coeff in payload.linear_terms.items():
                if i in cluster:
                    sub_linear[idx_map[i]] = coeff

            subproblems.append(QUBOPayload(
                q_matrix=sub_q,
                linear_terms=sub_linear,
                num_variables=len(cluster_list),
                metadata={
                    "parent_fingerprint": payload.fingerprint(),
                    "original_vars": cluster_list,
                    "decomposition": True
                }
            ))

        return subproblems

    def merge_solutions(self, sub_results: List[ExecutionResult], 
                       subproblems: List[QUBOPayload]) -> Dict[int, int]:
        """Merge sub-problem solutions back into full problem space."""
        merged = {}
        for sub_res, sub_prob in zip(sub_results, subproblems):
            original_vars = sub_prob.metadata.get("original_vars", [])
            for local_idx, global_var in enumerate(original_vars):
                if local_idx in sub_res.solution:
                    merged[global_var] = sub_res.solution[local_idx]
        return merged


# ============================================================================
# RETRY LOGIC WITH EXPONENTIAL BACKOFF
# ============================================================================

class RetryPolicy:
    """
    Configurable retry policy for transient backend failures.
    """

    def __init__(self, max_retries: int = 3, base_delay_sec: float = 1.0,
                 max_delay_sec: float = 60.0, backoff_factor: float = 2.0,
                 retryable_exceptions: Optional[Tuple[type, ...]] = None):
        self.max_retries = max_retries
        self.base_delay = base_delay_sec
        self.max_delay = max_delay_sec
        self.backoff_factor = backoff_factor
        self.retryable_exceptions = retryable_exceptions or (
            ConnectionError, TimeoutError, OSError
        )

    def should_retry(self, exception: Exception, attempt: int) -> bool:
        if attempt >= self.max_retries:
            return False
        return isinstance(exception, self.retryable_exceptions)

    def delay(self, attempt: int) -> float:
        """Exponential backoff with jitter."""
        delay = self.base_delay * (self.backoff_factor ** attempt)
        jitter = random.uniform(0, delay * 0.1)  # 10% jitter
        return min(delay + jitter, self.max_delay)

    def execute(self, fn: Callable, *args, **kwargs) -> Any:
        """Execute function with retry logic."""
        last_exception = None
        for attempt in range(self.max_retries + 1):
            try:
                return fn(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if not self.should_retry(e, attempt):
                    raise
                delay = self.delay(attempt)
                logger.warning(f"Retry {attempt+1}/{self.max_retries} after {delay:.1f}s: {e}")
                time.sleep(delay)
        raise last_exception


# ============================================================================
# CUSTOM ROUTING POLICY ENGINE
# ============================================================================

@dataclass
class RoutingRule:
    """User-defined routing rule with predicates and actions."""
    name: str
    predicate: Callable[[QUBOPayload, RouterConfig], bool]
    target_tiers: List[ExecutionTier]
    priority: int = 0  # Higher = evaluated first
    description: str = ""


class PolicyEngine:
    """
    Pluggable routing policy engine that overrides default complexity-based routing.
    """

    def __init__(self):
        self.rules: List[RoutingRule] = []
        self.default_policy = self._build_default_policy()

    def _build_default_policy(self) -> Dict[QUBOComplexity, List[ExecutionTier]]:
        return {
            QUBOComplexity.TRIVIAL: [ExecutionTier.CLASSICAL],
            QUBOComplexity.SMALL: [ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.MEDIUM: [ExecutionTier.CLASSICAL, ExecutionTier.CLOUD_SIM, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_SPARSE: [ExecutionTier.QPU_ANNEAL, ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_DENSE: [ExecutionTier.QPU_GATE, ExecutionTier.CLOUD_SIM, ExecutionTier.CLASSICAL],
        }

    def add_rule(self, rule: RoutingRule):
        """Add a custom routing rule."""
        self.rules.append(rule)
        self.rules.sort(key=lambda r: r.priority, reverse=True)

    def resolve(self, payload: QUBOPayload, config: RouterConfig) -> List[ExecutionTier]:
        """
        Evaluate rules in priority order. First matching rule wins.
        Falls back to default complexity-based policy.
        """
        for rule in self.rules:
            try:
                if rule.predicate(payload, config):
                    logger.info(f"Policy rule '{rule.name}' matched for {payload.fingerprint()}")
                    return rule.target_tiers
            except Exception as e:
                logger.warning(f"Policy rule '{rule.name}' predicate error: {e}")
                continue

        complexity = payload.complexity_class(config)
        return self.default_policy.get(complexity, [ExecutionTier.CLASSICAL])


# Example custom rules

def rule_always_classical_for_test(payload: QUBOPayload, config: RouterConfig) -> bool:
    """Route test problems to classical only."""
    return payload.metadata.get("environment") == "test"

def rule_budget_restrictive(payload: QUBOPayload, config: RouterConfig) -> bool:
    """When budget is low, prefer free backends."""
    bt = BudgetTracker()
    remaining = config.max_qpu_cost_usd - bt.total_cost_usd
    return remaining < 10.0

def rule_ionq_for_small_exact(payload: QUBOPayload, config: RouterConfig) -> bool:
    """Small problems that need exact results on IonQ."""
    return (payload.num_variables <= 20 and 
            payload.metadata.get("preferred_backend") == "ionq")


# ============================================================================
# DRY-RUN MODE
# ============================================================================

class DryRunSimulator:
    """
    Simulate routing decisions and cost estimates without executing on real hardware.
    """

    def __init__(self, router: VilitusQuantumRouter):
        self.router = router

    def simulate(self, payload: QUBOPayload, 
                 force_tier: Optional[ExecutionTier] = None) -> Dict[str, Any]:
        """
        Return a detailed simulation report without executing.
        """
        complexity = payload.complexity_class(self.router.config)

        if force_tier:
            tier_order = [force_tier]
        else:
            tier_order = self.router.routing_policy.get(
                complexity, [ExecutionTier.CLASSICAL]
            )

        report = {
            "problem_fingerprint": payload.fingerprint(),
            "complexity": complexity.value,
            "num_variables": payload.num_variables,
            "density": payload.density,
            "tier_order": [t.name for t in tier_order],
            "tier_simulations": []
        }

        for tier in tier_order:
            backend = self.router.backends.get(tier)
            if not backend:
                continue

            sim = {
                "tier": tier.name,
                "backend_name": backend.name,
                "available": backend.available,
                "estimated_cost_usd": 0.0,
                "estimated_minutes": 0.0,
                "circuit_profile": None
            }

            if hasattr(backend, 'estimate_cost'):
                cost, minutes = backend.estimate_cost(payload)
                sim["estimated_cost_usd"] = cost
                sim["estimated_minutes"] = minutes

            if tier == ExecutionTier.QPU_GATE:
                profile = CircuitDepthAnalyzer.analyze_qaoa_circuit(payload.num_variables)
                sim["circuit_profile"] = {
                    "num_qubits": profile.num_qubits,
                    "cx_depth": profile.cx_depth,
                    "estimated_runtime_ms": profile.estimated_runtime_ms,
                    "compatible_backends": CircuitDepthAnalyzer.recommend_backend(profile)
                }

            report["tier_simulations"].append(sim)

        # Determine predicted outcome
        first_available = next(
            (s for s in report["tier_simulations"] if s["available"]), 
            None
        )
        report["predicted_backend"] = first_available["backend_name"] if first_available else None
        report["predicted_cost_usd"] = first_available["estimated_cost_usd"] if first_available else 0.0

        return report


# ============================================================================
# ADVANCED WARM-START: QAOA ANGLE INITIALIZATION
# ============================================================================

class WarmStartStrategy:
    """
    Advanced warm-start strategies for QAOA based on classical pre-solvers.
    Implements the "Warm-Start QAOA" from Egger et al. (2021).
    """

    @staticmethod
    def from_classical_solution(solution: Dict[int, int], 
                                 num_variables: int,
                                 reps: int = 3) -> List[float]:
        """
        Convert a classical bitstring solution to approximate QAOA angles.

        Strategy: For each layer p, set gamma_p near 0 (small cost evolution)
        and beta_p proportional to the solution quality gradient.
        """
        # Simple heuristic: bias mixer angles based on how many variables are 1
        num_ones = sum(solution.values())
        ratio = num_ones / num_variables if num_variables > 0 else 0.5

        angles = []
        for p in range(reps):
            # Gamma: small positive value, decaying with layer
            gamma = 0.1 * (0.9 ** p)
            # Beta: biased by solution density
            beta = math.pi / 4 * (1 - ratio)  # More 1s -> smaller beta
            angles.extend([gamma, beta])

        return angles

    @staticmethod
    def from_relaxed_lp(relaxed_solution: Dict[int, float], 
                        reps: int = 3) -> List[float]:
        """
        Use LP-relaxed fractional solutions to initialize QAOA.
        More sophisticated than bitstring warm-start.
        """
        # Average fractional value
        avg_val = sum(relaxed_solution.values()) / len(relaxed_solution) if relaxed_solution else 0.5

        angles = []
        for p in range(reps):
            gamma = 0.05 + 0.05 * p  # Increasing cost angle
            beta = math.pi / 8 + (math.pi / 8) * avg_val
            angles.extend([gamma, beta])

        return angles


# ============================================================================
# ENHANCED ROUTER (v3.0)
# ============================================================================

class VilitusQuantumRouterV3(VilitusQuantumRouter):
    """
    Extended router with all v3.0 features:
    - Metrics & observability
    - IonQ backend
    - Circuit depth analysis
    - Problem decomposition
    - Retry logic
    - Custom policies
    - Dry-run mode
    - Advanced warm-start
    """

    def __init__(self, config: Optional[RouterConfig] = None, 
                 metrics_port: Optional[int] = None):
        super().__init__(config)
        self.metrics = RouterMetrics(port=metrics_port)
        self.policy_engine = PolicyEngine()
        self.retry_policy = RetryPolicy()
        self.decomposer = QUBODecomposer(max_subproblem_size=50)
        self.dry_run = DryRunSimulator(self)

        # Add IonQ backend
        self.backends[ExecutionTier.QPU_GATE] = IonQBackend()
        self.backends[ExecutionTier.QPU_GATE].initialize(self.config)

        # Add default custom rules
        self.policy_engine.add_rule(RoutingRule(
            name="budget_conservative",
            predicate=rule_budget_restrictive,
            target_tiers=[ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM, ExecutionTier.CLOUD_SIM],
            priority=100,
            description="Prefer free backends when budget is low"
        ))

    def route(self, payload: QUBOPayload, 
              deadline_sec: Optional[float] = None,
              force_tier: Optional[ExecutionTier] = None,
              enable_decomposition: bool = True) -> ExecutionResult:
        """
        Enhanced routing with decomposition, metrics, and policy engine.
        """
        start = time.time()  # CRIT-001 FIX

        # Check cache
        fp = payload.fingerprint()
        if fp in self.cache:
            cached = self.cache[fp]
            cached.metadata["cached"] = True
            self.metrics.cache_size.set(len(self.cache))
            return cached

        complexity = payload.complexity_class(self.config)

        # Decomposition for very large problems
        if enable_decomposition and payload.num_variables > self.config.medium_threshold * 2:
            logger.info(f"Problem {fp} exceeds decomposition threshold. Decomposing...")
            subproblems = self.decomposer.decompose(payload)
            if len(subproblems) > 1:
                return self._solve_decomposed(subproblems, payload, start, deadline_sec)

        # Determine tier order via policy engine
        if force_tier:
            tier_order = [force_tier]
        else:
            tier_order = self.policy_engine.resolve(payload, self.config)

        self.metrics.active_jobs.inc()

        try:
            last_result = None
            warm_start = None

            for tier in tier_order:
                backend = self.backends.get(tier)
                if not backend or not backend.available:
                    continue

                timeout = self._compute_timeout(deadline_sec, tier)

                try:
                    # Apply retry policy for network backends
                    if tier in [ExecutionTier.CLOUD_SIM, ExecutionTier.QPU_GATE, ExecutionTier.QPU_ANNEAL]:
                        result = self.retry_policy.execute(
                            backend.solve, payload, timeout, warm_start
                        )
                    else:
                        result = backend.solve(payload, timeout, warm_start)

                    self.metrics.record_job(payload, result, complexity, tier)

                    if result.status == "SUCCESS":
                        if self.config.enable_result_verification:
                            result.verified = self._verify_solution(payload, result)

                        self.cache[fp] = result
                        self.metrics.cache_size.set(len(self.cache))

                        # CRIT-003 FIX: Don't overwrite SUCCESS status
                        if tier != tier_order[0]:
                            result.metadata["fallback_tier_used"] = backend.name
                            result.metadata["fallback_from"] = tier_order[0].name
                            self.metrics.record_fallback(tier_order[0], tier)

                        logger.info(f"Success on {backend.name}: energy={result.energy}")
                        return result

                    elif result.status == "FALLBACK":
                        logger.info(f"Fallback on {backend.name}: {result.metadata.get('reason')}")
                        warm_start = last_result.solution if last_result else None
                        self.metrics.record_fallback(tier, tier_order[tier_order.index(tier) + 1] 
                                                    if tier_order.index(tier) + 1 < len(tier_order) 
                                                    else ExecutionTier.CLASSICAL)
                    else:
                        warm_start = last_result.solution if last_result else None

                    last_result = result

                except Exception as e:
                    logger.error(f"Exception on {backend.name}: {e}")
                    warm_start = last_result.solution if last_result else None

            # All tiers exhausted
            logger.error(f"All backends failed for problem {fp}")
            return ExecutionResult(
                status="FAILED",
                backend="all_tiers",
                tier=ExecutionTier.CLASSICAL,
                solution=last_result.solution if last_result else {},
                execution_time_sec=time.time() - start,  # CRIT-001 FIX
                metadata={"error": "All tiers exhausted", "last_tier": tier_order[-1].name}
            )

        finally:
            self.metrics.active_jobs.dec()
            self.metrics.budget_remaining.set(
                self.config.max_qpu_cost_usd - self.budget.total_cost_usd
            )

    def _solve_decomposed(self, subproblems: List[QUBOPayload], 
                          original: QUBOPayload,
                          start_time: float,
                          deadline_sec: Optional[float]) -> ExecutionResult:
        """Solve decomposed subproblems and merge results."""
        sub_results = []
        for sub in subproblems:
            result = self.route(sub, deadline_sec=deadline_sec, enable_decomposition=False)
            sub_results.append(result)

        merged_solution = self.decomposer.merge_solutions(sub_results, subproblems)

        # Compute energy on merged solution
        energy = 0.0
        for (i, j), coeff in original.q_matrix.items():
            energy += coeff * merged_solution.get(i, 0) * merged_solution.get(j, 0)
        for i, coeff in original.linear_terms.items():
            energy += coeff * merged_solution.get(i, 0)

        return ExecutionResult(
            status="SUCCESS",
            backend="decomposed_hybrid",
            tier=ExecutionTier.CLASSICAL,
            solution=merged_solution,
            energy=energy,
            execution_time_sec=time.time() - start_time,
            metadata={
                "decomposed": True,
                "num_subproblems": len(subproblems),
                "sub_results": [r.status for r in sub_results]
            }
        )

    def get_dry_run_report(self, payload: QUBOPayload) -> Dict[str, Any]:
        """Get cost and compatibility estimate without executing."""
        return self.dry_run.simulate(payload)

    def analyze_circuit(self, payload: QUBOPayload, reps: int = 3) -> CircuitProfile:
        """Analyze circuit requirements for this problem."""
        return CircuitDepthAnalyzer.analyze_qaoa_circuit(payload.num_variables, reps)


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    config = RouterConfig(
        max_qpu_cost_usd=100.0,
        max_qpu_minutes_per_month=30.0,
        enable_result_verification=True
    )

    router = VilitusQuantumRouterV3(config, metrics_port=9090)

    # Dry run first
    test_payload = QUBOPayload(
        q_matrix={(0, 1): 2.0, (1, 2): -1.0, (2, 3): 1.5},
        linear_terms={0: -1.0, 1: -2.0, 2: 1.5, 3: -1.0},
        num_variables=4,
        metadata={"problem": "tsp_fragment", "cities": 4}
    )

    print("=== DRY RUN REPORT ===")
    report = router.get_dry_run_report(test_payload)
    print(json.dumps(report, indent=2))

    print("\n=== CIRCUIT ANALYSIS ===")
    profile = router.analyze_circuit(test_payload, reps=3)
    print(f"Qubits: {profile.num_qubits}, CX depth: {profile.cx_depth}")
    print(f"Compatible backends: {CircuitDepthAnalyzer.recommend_backend(profile)}")

    print("\n=== ACTUAL EXECUTION ===")
    result = router.route(test_payload, deadline_sec=60.0)
    print(f"Status: {result.status}, Backend: {result.backend}")
    print(f"Energy: {result.energy}, Verified: {result.verified}")

    print("\n=== BUDGET REPORT ===")
    print(json.dumps(router.get_budget_report(), indent=2))

    router.shutdown()
