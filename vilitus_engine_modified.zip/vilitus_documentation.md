# VILITUS QUANTUM ROUTER — Architecture & Operations Guide
**Version:** 3.0 (Extended)  
**Last Updated:** 2026-07-09  
**Classification:** Internal Engineering Documentation

---

## Table of Contents
1. [System Overview](#1-system-overview)
2. [Architecture Diagrams](#2-architecture-diagrams)
3. [Component Reference](#3-component-reference)
4. [API Documentation](#4-api-documentation)
5. [Routing Decision Matrix](#5-routing-decision-matrix)
6. [Backend Specifications](#6-backend-specifications)
7. [Deployment Guide](#7-deployment-guide)
8. [Monitoring & Alerting](#8-monitoring--alerting)
9. [Troubleshooting](#9-troubleshooting)
10. [Changelog](#10-changelog)

---

## 1. System Overview

The **Vilitus Quantum Router** is a production-grade hybrid quantum-classical optimization engine. It abstracts away the complexity of choosing between classical solvers (OR-Tools, SCIP, Gurobi), local quantum simulators (Qiskit Aer), cloud simulators (IBM Cloud), and physical quantum processing units (IBM Heron, D-Wave Advantage2, IonQ Aria).

### Key Capabilities
- **Intelligent Auto-Routing:** Classifies QUBO complexity and selects optimal execution tier
- **Budget Guardrails:** Thread-safe cost and time tracking with hard limits
- **Fallback Chaining:** Graceful degradation from QPU → Cloud → Local → Classical
- **Warm-Start Propagation:** Failed tier solutions seed the next tier
- **ROS Decoupling:** Non-blocking async bridge for real-time robotics
- **Result Verification:** Classical double-check of quantum solutions
- **Observability:** Prometheus metrics, structured logging, circuit profiling

### Supported Backends
| Backend | Tier | Cost Model | Max Variables | Connectivity |
|---------|------|-----------|---------------|--------------|
| OR-Tools / SCIP | `CLASSICAL` | Free (CPU) | 10,000+ | N/A |
| Qiskit Aer (GPU) | `LOCAL_SIM` | Free (GPU) | ~30 (exact) | All-to-all |
| IBM Cloud Sim | `CLOUD_SIM` | Free | ~30 | All-to-all |
| D-Wave Hybrid | `QUANTUM_INSPIRED` | $2-5/problem | 10,000+ | Pegasus |
| IBM Heron | `QPU_GATE` | ~$1.60/sec | 133 | Heavy-hex |
| IonQ Aria | `QPU_GATE` | ~$0.00001/shot | 25 | All-to-all |
| D-Wave Adv2 | `QPU_ANNEAL` | ~$2/problem | 7,000+ | Pegasus |

---

## 2. Architecture Diagrams

### 2.1 High-Level System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     VILITUS QUANTUM ROUTER v3.0                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────────┐  │
│  │   ROS Node  │    │  REST API   │    │   CLI / Jupyter     │  │
│  │  (Real-time)│    │  (Batch)    │    │   (Interactive)     │  │
│  └──────┬──────┘    └──────┬──────┘    └──────────┬──────────┘  │
│         │                  │                      │              │
│         └──────────────────┼──────────────────────┘              │
│                            │                                      │
│              ┌─────────────┴─────────────┐                        │
│              │   VilitusQuantumRouterV3  │                        │
│              │  ───────────────────────  │                        │
│              │  • Policy Engine          │                        │
│              │  • Complexity Classifier    │                        │
│              │  • Budget Tracker (Singleton)│                     │
│              │  • Cache (LRU)              │                        │
│              │  • Metrics (Prometheus)     │                        │
│              │  • Decomposer               │                        │
│              └─────────────┬─────────────┘                        │
│                            │                                      │
│         ┌──────────────────┼──────────────────┐                   │
│         │                  │                  │                   │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐            │
│  │  Classical  │  │  Simulator  │  │    QPU      │            │
│  │  Tier       │  │  Tier       │  │    Tier     │            │
│  │             │  │             │  │             │            │
│  │ • OR-Tools  │  │ • Qiskit Aer│  │ • IBM Heron │            │
│  │ • SCIP      │  │ • IBM Cloud │  │ • IonQ Aria │            │
│  │ • Gurobi    │  │             │  │ • D-Wave    │            │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              Observability Stack                          │   │
│  │  • Prometheus (metrics)  • Grafana (dashboards)           │   │
│  │  • Structured JSON logs  • Jaeger (distributed tracing)  │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Routing Decision Flow

```
┌──────────┐
│  Submit  │
│  QUBO    │
└────┬─────┘
     │
     ▼
┌─────────────────┐     No     ┌─────────────────┐
│ Cache Hit?      │───────────▶│ Complexity      │
│ (Fingerprint)   │            │ Classification  │
└─────────────────┘            └────────┬────────┘
     │ Yes                             │
     ▼                                 ▼
┌─────────────────┐           ┌─────────────────┐
│ Return Cached   │           │ Policy Engine   │
│ Result          │           │ (Custom Rules)  │
└─────────────────┘           └────────┬────────┘
                                       │
                                       ▼
                              ┌─────────────────┐
                              │ Tier Priority   │
                              │ List Generated  │
                              └────────┬────────┘
                                       │
                    ┌──────────────────┼──────────────────┐
                    │                  │                  │
                    ▼                  ▼                  ▼
           ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
           │  Budget     │   │  Circuit    │   │  Backend    │
           │  Check      │   │  Analysis   │   │  Available? │
           └──────┬──────┘   └──────┬──────┘   └──────┬──────┘
                  │                  │                  │
                  ▼                  ▼                  ▼
           ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
           │ Can Afford? │   │ Fits QPU?   │   │ Initialize  │
           │             │   │             │   │ Success?    │
           └──────┬──────┘   └──────┬──────┘   └──────┬──────┘
                  │                  │                  │
                  ▼                  ▼                  ▼
           ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
           │  Execute    │   │  Decompose  │   │  Retry      │
           │  Solver     │   │  if Needed  │   │  if Failed  │
           └──────┬──────┘   └─────────────┘   └─────────────┘
                  │
                  ▼
           ┌─────────────┐
           │  Verify     │
           │  Result     │
           └──────┬──────┘
                  │
                  ▼
           ┌─────────────┐
           │  Cache &    │
           │  Return     │
           └─────────────┘
```

### 2.3 Fallback Chain State Machine

```
                    ┌─────────────┐
                    │   START     │
                    └──────┬──────┘
                           │
                           ▼
              ┌────────────────────────┐
              │  Try Preferred Tier    │
              │  (from policy engine)  │
              └───────────┬────────────┘
                          │
              ┌───────────┼───────────┐
              │           │           │
              ▼           ▼           ▼
        ┌────────┐  ┌────────┐  ┌────────┐
        │SUCCESS │  │TIMEOUT │  │ FAILED │
        └───┬────┘  └───┬────┘  └───┬────┘
            │           │           │
            ▼           │           ▼
        ┌────────┐      │      ┌────────┐
        │ VERIFY │      │      │ Warm   │
        │ RESULT │      │      │ Start  │
        └───┬────┘      │      └───┬────┘
            │           │          │
            ▼           │          ▼
        ┌────────┐      │    ┌────────────┐
        │ RETURN │      │    │ Next Tier  │
        │ FINAL  │◀─────┘    │ (fallback) │
        └────────┘           └─────┬──────┘
                                   │
                                   └──────▶ (repeat until exhausted)
```

---

## 3. Component Reference

### 3.1 Core Data Classes

#### `QUBOPayload`
Standardized QUBO problem representation.

```python
@dataclass
class QUBOPayload:
    q_matrix: Dict[Tuple[int, int], float]   # {(i,j): coeff}, i <= j
    linear_terms: Dict[int, float]           # {i: coeff} diagonal
    num_variables: int
    constraints: List[Dict[str, Any]]        # Optional constraints
    metadata: Dict[str, Any]                 # Problem metadata
```

**Key Methods:**
- `density()` → `float`: Matrix sparsity ratio [0, 1]
- `complexity_class(config)` → `QUBOComplexity`: Auto-classification
- `fingerprint()` → `str`: Deterministic 16-char SHA-256 hash

#### `ExecutionResult`
Standardized solver output.

```python
@dataclass
class ExecutionResult:
    status: str                    # "SUCCESS", "TIMEOUT", "FAILED", "FALLBACK"
    backend: str                   # Backend name
    tier: ExecutionTier            # Execution tier used
    solution: Dict[int, int]       # {var_idx: 0/1}
    energy: Optional[float]       # Objective value
    execution_time_sec: float      # Wall-clock time
    cost_usd: float               # Actual cost
    queue_time_sec: float          # QPU queue wait
    verified: bool                # Passed classical verification
    warm_start_used: bool          # Warm start was applied
    metadata: Dict[str, Any]       # Extra info (fallback_from, etc.)
```

### 3.2 Router Configuration

#### `RouterConfig`
Centralized configuration object.

| Field | Default | Description |
|-------|---------|-------------|
| `ibm_token` | `None` | IBM Quantum API token |
| `ibm_backend_preference` | `["ibm_heron", "ibm_nighthawk"]` | Priority backend list |
| `dwave_token` | `None` | D-Wave Leap API token |
| `dwave_solver` | `"Advantage2_prototype1.1"` | Target annealer |
| `classical_solver` | `"or-tools"` | Classical engine |
| `max_qpu_cost_usd` | `500.0` | Monthly QPU budget |
| `max_qpu_minutes_per_month` | `60.0` | Monthly QPU time |
| `default_timeout_sec` | `300.0` | Default solver timeout |
| `qpu_queue_timeout_sec` | `60.0` | Max queue wait before fallback |
| `enable_result_verification` | `True` | Classical verification |
| `enable_warm_start` | `True` | Cross-tier warm starting |
| `executor_pool_size` | `4` | Thread pool workers |
| `ros_decoupled` | `True` | Async ROS bridge |

### 3.3 Backend Interface

All backends implement `BackendInterface`:

```python
class BackendInterface:
    def initialize(self, config: RouterConfig) -> bool
    def solve(self, payload: QUBOPayload, timeout_sec: float, 
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult
    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]  # (cost_usd, minutes)
```

---

## 4. API Documentation

### 4.1 Synchronous Routing

```python
from vilitus_extended import VilitusQuantumRouterV3, QUBOPayload, RouterConfig

config = RouterConfig(ibm_token="YOUR_TOKEN", max_qpu_cost_usd=100.0)
router = VilitusQuantumRouterV3(config, metrics_port=9090)

payload = QUBOPayload(
    q_matrix={(0, 1): 2.0, (1, 2): -1.0},
    linear_terms={0: -1.0, 1: -2.0, 2: 1.5},
    num_variables=3,
    metadata={"problem": "max_cut"}
)

# Auto-route with 60s deadline
result = router.route(payload, deadline_sec=60.0)

print(f"Status: {result.status}")       # "SUCCESS"
print(f"Backend: {result.backend}")       # "classical_or-tools"
print(f"Energy: {result.energy}")       # -3.5
print(f"Verified: {result.verified}")    # True
```

### 4.2 Async / ROS Integration

```python
from vilitus_extended import ROSQuantumBridge

bridge = ROSQuantumBridge(router)

def on_complete(result: ExecutionResult):
    rospy.loginfo(f"Optimization complete: {result.energy}")

# Submit from ROS callback (non-blocking)
job_id = asyncio.run(bridge.submit_optimization(
    payload, on_complete, deadline_sec=10.0
))

# Cancel if needed
bridge.cancel_job(job_id)
```

### 4.3 Dry-Run Mode (Cost Estimation)

```python
# Get full cost and compatibility report without executing
report = router.get_dry_run_report(payload)

print(json.dumps(report, indent=2))
# {
#   "problem_fingerprint": "a3f7...",
#   "complexity": "small",
#   "predicted_backend": "classical_or-tools",
#   "predicted_cost_usd": 0.0,
#   "tier_simulations": [...]
# }
```

### 4.4 Circuit Analysis

```python
profile = router.analyze_circuit(payload, reps=3)

print(f"Qubits needed: {profile.num_qubits}")
print(f"CX depth: {profile.cx_depth}")
print(f"Compatible: {CircuitDepthAnalyzer.recommend_backend(profile)}")
```

### 4.5 Custom Routing Policies

```python
from vilitus_extended import PolicyEngine, RoutingRule, ExecutionTier

policy = PolicyEngine()

# Rule: Always use classical for test problems
policy.add_rule(RoutingRule(
    name="test_env",
    predicate=lambda p, c: p.metadata.get("env") == "test",
    target_tiers=[ExecutionTier.CLASSICAL],
    priority=100
))

# Rule: Prefer IonQ for small exact problems
policy.add_rule(RoutingRule(
    name="ionq_exact",
    predicate=lambda p, c: p.num_variables <= 20 and p.metadata.get("exact") == True,
    target_tiers=[ExecutionTier.QPU_GATE],  # IonQ is in QPU_GATE tier
    priority=90
))

router.policy_engine = policy
```

---

## 5. Routing Decision Matrix

### 5.1 Complexity Classification

| Variables | Density | Complexity | Preferred Tier | Fallback Chain |
|-----------|---------|------------|----------------|----------------|
| < 50 | Any | `TRIVIAL` | Classical | — |
| 50–200 | Any | `SMALL` | Classical → Local Sim | Cloud Sim |
| 200–1000 | Any | `MEDIUM` | Classical → Cloud Sim → Local Sim | QPU |
| > 1000 | < 0.05 | `LARGE_SPARSE` | D-Wave Anneal → Classical → Local Sim | Cloud Sim |
| > 1000 | ≥ 0.05 | `LARGE_DENSE` | IBM/IonQ Gate → Cloud Sim → Classical | Local Sim |

### 5.2 Policy Override Precedence

1. **Custom Rules** (highest priority, user-defined)
2. **Budget Guardrails** (block expensive tiers if budget low)
3. **Circuit Analysis** (exclude backends that cannot fit circuit)
4. **Complexity Classification** (default routing policy)
5. **Availability Check** (skip uninitialized backends)

---

## 6. Backend Specifications

### 6.1 IBM Quantum (QPU_GATE)

**Prerequisites:**
```bash
pip install qiskit-ibm-runtime qiskit-optimization qiskit-algorithms
```

**Authentication:**
```python
config = RouterConfig(ibm_token=os.getenv("IBM_QUANTUM_TOKEN"))
```

**Characteristics:**
- Gate-based superconducting qubits
- Heavy-hex connectivity (3-qubit chains)
- Error mitigation: ZNE + PEC (resilience_level=2)
- Cost: ~$1.60/sec runtime (Open Plan beyond free tier)

### 6.2 D-Wave (QPU_ANNEAL)

**Prerequisites:**
```bash
pip install dwave-system dwave-cloud-client
```

**Authentication:**
```python
config = RouterConfig(dwave_token=os.getenv("DWAVE_API_TOKEN"))
```

**Characteristics:**
- Quantum annealing (not gate-based)
- Native QUBO solving
- Pegasus / Zephyr topology
- Best for: sparse, large-scale optimization
- Cost: ~$2.00/problem (Leap subscription)

### 6.3 IonQ (QPU_GATE)

**Prerequisites:**
```bash
pip install qiskit-ionq
```

**Authentication:**
```python
config = RouterConfig()  # Uses IONQ_API_KEY env var
```

**Characteristics:**
- Trapped-ion gate-based qubits
- All-to-all connectivity (no SWAP overhead)
- Native gates: GPi, GPi2, GZZ
- Best for: small exact problems, high fidelity
- Cost: ~$0.00001/shot

### 6.4 Classical (CLASSICAL)

**Prerequisites:**
```bash
pip install ortools  # or pyscipopt, gurobipy
```

**Characteristics:**
- CP-SAT (OR-Tools): Best for discrete optimization
- SCIP: Academic MIP solver
- Gurobi: Commercial-grade MIP (requires license)
- Always free, always available

---

## 7. Deployment Guide

### 7.1 Docker Deployment

```dockerfile
# Dockerfile (see integration artifacts)
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY vilitus_refactored.py .
COPY vilitus_extended.py .
EXPOSE 9090  # Prometheus metrics

CMD ["python", "-m", "vilitus_extended"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  vilitus:
    build: .
    environment:
      - IBM_QUANTUM_TOKEN=${IBM_QUANTUM_TOKEN}
      - DWAVE_API_TOKEN=${DWAVE_API_TOKEN}
      - IONQ_API_KEY=${IONQ_API_KEY}
    ports:
      - "9090:9090"  # Prometheus
    volumes:
      - ./data:/app/data
```

### 7.2 Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: vilitus-router
spec:
  replicas: 2
  selector:
    matchLabels:
      app: vilitus
  template:
    metadata:
      labels:
        app: vilitus
    spec:
      containers:
      - name: router
        image: vilitus:v3.0
        ports:
        - containerPort: 9090
        env:
        - name: IBM_QUANTUM_TOKEN
          valueFrom:
            secretKeyRef:
              name: quantum-tokens
              key: ibm
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
```

### 7.3 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `IBM_QUANTUM_TOKEN` | For IBM backends | IBM Quantum API key |
| `DWAVE_API_TOKEN` | For D-Wave | D-Wave Leap API token |
| `IONQ_API_KEY` | For IonQ | IonQ cloud API key |
| `VILITUS_METRICS_PORT` | No | Prometheus port (default: 9090) |
| `VILITUS_LOG_LEVEL` | No | DEBUG, INFO, WARNING, ERROR |
| `VILITUS_MAX_QPU_COST` | No | Override budget limit |

---

## 8. Monitoring & Alerting

### 8.1 Prometheus Metrics

| Metric | Type | Description |
|--------|------|-------------|
| `vilitus_jobs_submitted_total` | Counter | Jobs by complexity and tier |
| `vilitus_jobs_completed_total` | Counter | Jobs by status and backend |
| `vilitus_fallbacks_total` | Counter | Fallback events |
| `vilitus_execution_duration_seconds` | Histogram | Solve time by backend |
| `vilitus_queue_duration_seconds` | Histogram | QPU queue time |
| `vilitus_solution_energy` | Histogram | Energy distribution |
| `vilitus_active_jobs` | Gauge | In-flight jobs |
| `vilitus_budget_remaining_usd` | Gauge | Remaining budget |
| `vilitus_cache_entries` | Gauge | Cache size |

### 8.2 Recommended Alerts

```yaml
# Prometheus AlertManager rules
groups:
  - name: vilitus
    rules:
      - alert: HighFallbackRate
        expr: rate(vilitus_fallbacks_total[5m]) > 0.5
        for: 5m
        annotations:
          summary: "High fallback rate detected"

      - alert: QPUBudgetExhausted
        expr: vilitus_budget_remaining_usd < 10
        for: 1m
        annotations:
          summary: "QPU budget nearly exhausted"

      - alert: LongQueueTime
        expr: histogram_quantile(0.95, vilitus_queue_duration_seconds) > 300
        for: 10m
        annotations:
          summary: "95th percentile queue time > 5 minutes"
```

### 8.3 Grafana Dashboard

Create a dashboard with:
- **Panel 1:** Job completion rate (rate of `vilitus_jobs_completed_total`)
- **Panel 2:** Backend utilization pie chart (by `backend` label)
- **Panel 3:** Execution time heatmap (by complexity and backend)
- **Panel 4:** Budget burn-down graph (`vilitus_budget_remaining_usd`)
- **Panel 5:** Fallback rate trend
- **Panel 6:** Active jobs gauge

---

## 9. Troubleshooting

### 9.1 Common Issues

**Issue:** `ImportError: No module named 'ortools'`
- **Fix:** `pip install ortools` or set `classical_solver="scip"` and install `pyscipopt`

**Issue:** `RuntimeError: no running event loop` (ROS)
- **Fix:** Ensure `asyncio` event loop is attached to the ROS callback thread. Use `asyncio.run_coroutine_threadsafe()`.

**Issue:** `IBM QPU init failed: Authentication error`
- **Fix:** Verify `IBM_QUANTUM_TOKEN` is valid and not expired. Check IBM Quantum dashboard.

**Issue:** `D-Wave init failed: Solver not found`
- **Fix:** Check `DWAVE_API_TOKEN` and region. Ensure Leap subscription is active.

**Issue:** Cache grows unbounded, OOM
- **Fix:** In v3.0, cache uses LRU eviction. In v2.0, manually clear: `router.cache.clear()`

**Issue:** Quantum results fail verification
- **Fix:** Increase tolerance for quantum backends. Check if problem is too large for QPU (use dry-run to verify).

### 9.2 Debug Mode

```python
import logging
logging.getLogger("VilitusQuantumRouter").setLevel(logging.DEBUG)

# Enable dry-run to trace routing decisions
report = router.get_dry_run_report(payload)
print(json.dumps(report, indent=2))
```

---

## 10. Changelog

### v3.0 (2026-07-09) — Extended Features
- **Added:** IonQ backend support (trapped-ion QPU)
- **Added:** Prometheus metrics and observability stack
- **Added:** Circuit depth analyzer with backend compatibility checks
- **Added:** QUBO problem decomposition (QBSolv-style greedy clustering)
- **Added:** Retry logic with exponential backoff and jitter
- **Added:** Pluggable policy engine for custom routing rules
- **Added:** Dry-run mode for cost estimation
- **Added:** Advanced QAOA warm-start strategies (Egger et al. 2021)
- **Fixed:** CRIT-001 (undefined `start` variable)
- **Fixed:** CRIT-002 (budget tracker using wrong config)
- **Fixed:** CRIT-003 (fallback overwriting SUCCESS status)
- **Fixed:** CRIT-004 (enclosing scope dependency in classical solver)
- **Fixed:** CRIT-005 (density double-counting)
- **Fixed:** CRIT-006 (ROS event loop handling)
- **Fixed:** CRIT-007 (missing timeout in quantum solvers)
- **Fixed:** CRIT-008 (Qiskit IBM Runtime API drift)

### v2.0 (2026) — Initial Release
- Tiered routing: Classical → Sim → QPU
- Auto problem sizing and backend selection
- Async execution with ROS decoupling
- Result verification and warm-start chaining
- Budget tracking and guardrails
- D-Wave, IBM, and local simulator backends
