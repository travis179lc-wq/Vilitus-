"""
VILITUS QUANTUM ROUTER — COMPREHENSIVE TEST SUITE
==================================================
Covers: Unit tests, integration tests, mock backends, 
        property-based tests, and benchmark harnesses.
"""

import unittest
import asyncio
import time
import json
import hashlib
from unittest.mock import Mock, patch, MagicMock, AsyncMock
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum, auto
import threading
import sys
import os

# Add parent to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vilitus_quantum_router_v2 import (
    ExecutionTier, QUBOComplexity, RouterConfig, QUBOPayload,
    ExecutionResult, BudgetTracker, BackendInterface, ClassicalBackend,
    LocalSimulatorBackend, IBMCloudSimulatorBackend, IBMQPUBackend,
    DWaveAnnealingBackend, VilitusQuantumRouter, ROSQuantumBridge
)


# ============================================================================
# FIXTURES & MOCK BACKENDS
# ============================================================================

class MockBackend(BackendInterface):
    """Controllable mock backend for testing routing logic."""

    def __init__(self, name: str, tier: ExecutionTier, 
                 return_status: str = "SUCCESS", 
                 delay_sec: float = 0.0,
                 available: bool = True):
        super().__init__(name, tier)
        self.return_status = return_status
        self.delay_sec = delay_sec
        self._available = available
        self.call_count = 0
        self.last_warm_start = None
        self.last_timeout = None

    def initialize(self, config: RouterConfig) -> bool:
        self.available = self._available
        return self._available

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        self.call_count += 1
        self.last_warm_start = warm_start
        self.last_timeout = timeout_sec
        time.sleep(self.delay_sec)

        if self.return_status == "SUCCESS":
            return ExecutionResult(
                status="SUCCESS",
                backend=self.name,
                tier=self.tier,
                solution={i: 0 for i in range(payload.num_variables)},
                energy=0.0,
                execution_time_sec=self.delay_sec,
                cost_usd=1.0 if self.tier in [ExecutionTier.QPU_GATE, ExecutionTier.QPU_ANNEAL] else 0.0
            )
        elif self.return_status == "FALLBACK":
            return ExecutionResult(
                status="FALLBACK",
                backend=self.name,
                tier=self.tier,
                solution={},
                execution_time_sec=self.delay_sec,
                cost_usd=0.0,
                metadata={"reason": "Budget exceeded"}
            )
        else:
            return ExecutionResult(
                status="FAILED",
                backend=self.name,
                tier=self.tier,
                solution={},
                execution_time_sec=self.delay_sec,
                cost_usd=0.0
            )

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        return (1.0, 0.5)


def make_test_payload(n: int = 10, density: float = 0.3) -> QUBOPayload:
    """Generate a reproducible test QUBO."""
    import random
    random.seed(42)
    q_matrix = {}
    linear_terms = {}
    for i in range(n):
        linear_terms[i] = random.uniform(-2, 2)
        for j in range(i + 1, n):
            if random.random() < density:
                q_matrix[(i, j)] = random.uniform(-1, 1)
    return QUBOPayload(
        q_matrix=q_matrix,
        linear_terms=linear_terms,
        num_variables=n,
        constraints=[{"type": "eq", "terms": [(0, 1), (1, 1)], "rhs": 1}],
        metadata={"test": True}
    )


# ============================================================================
# UNIT TESTS: DATA CLASSES & UTILITIES
# ============================================================================

class TestQUBOPayload(unittest.TestCase):
    """Tests for QUBO problem representation."""

    def test_density_calculation(self):
        """Density should be between 0 and 1."""
        payload = make_test_payload(n=10, density=0.5)
        self.assertGreater(payload.density, 0.0)
        self.assertLessEqual(payload.density, 1.0)

    def test_density_empty(self):
        """Empty QUBO should have density 0."""
        payload = QUBOPayload(q_matrix={}, linear_terms={}, num_variables=0)
        self.assertEqual(payload.density, 0.0)

    def test_complexity_trivial(self):
        """Small problems should classify as TRIVIAL."""
        config = RouterConfig()
        payload = make_test_payload(n=10)
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.TRIVIAL)

    def test_complexity_small(self):
        """Medium-small problems should classify as SMALL."""
        config = RouterConfig()
        payload = make_test_payload(n=100)
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.SMALL)

    def test_complexity_large_sparse(self):
        """Large sparse problems should route to annealer."""
        config = RouterConfig()
        payload = make_test_payload(n=2000, density=0.01)
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.LARGE_SPARSE)

    def test_complexity_large_dense(self):
        """Large dense problems should route to gate QPU."""
        config = RouterConfig()
        payload = make_test_payload(n=2000, density=0.2)
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.LARGE_DENSE)

    def test_fingerprint_determinism(self):
        """Same problem must produce same fingerprint."""
        p1 = make_test_payload(n=20)
        p2 = make_test_payload(n=20)
        self.assertEqual(p1.fingerprint(), p2.fingerprint())

    def test_fingerprint_uniqueness(self):
        """Different problems should have different fingerprints."""
        p1 = make_test_payload(n=10)
        p2 = make_test_payload(n=11)
        self.assertNotEqual(p1.fingerprint(), p2.fingerprint())

    def test_fingerprint_length(self):
        """Fingerprint should be 16 hex chars."""
        payload = make_test_payload()
        fp = payload.fingerprint()
        self.assertEqual(len(fp), 16)
        self.assertTrue(all(c in '0123456789abcdef' for c in fp))


class TestBudgetTracker(unittest.TestCase):
    """Tests for singleton budget tracker."""

    def setUp(self):
        self.bt = BudgetTracker()
        self.bt.reset()

    def test_singleton(self):
        """BudgetTracker must be singleton."""
        bt2 = BudgetTracker()
        self.assertIs(self.bt, bt2)

    def test_can_afford_within_budget(self):
        """Should allow spending within limits."""
        config = RouterConfig(max_qpu_cost_usd=100.0, max_qpu_minutes_per_month=60.0)
        self.assertTrue(self.bt.can_afford(50.0, 30.0, config))

    def test_can_afford_exceeds_cost(self):
        """Should deny when cost exceeds budget."""
        config = RouterConfig(max_qpu_cost_usd=10.0)
        self.assertFalse(self.bt.can_afford(20.0, 1.0, config))

    def test_can_afford_exceeds_time(self):
        """Should deny when minutes exceed monthly limit."""
        config = RouterConfig(max_qpu_minutes_per_month=10.0)
        self.assertFalse(self.bt.can_afford(1.0, 20.0, config))

    def test_can_afford_disabled_tracking(self):
        """Should always allow when tracking is disabled."""
        config = RouterConfig(enable_budget_tracking=False)
        self.assertTrue(self.bt.can_afford(9999.0, 9999.0, config))

    def test_record_accumulation(self):
        """Recording should accumulate costs."""
        self.bt.record(10.0, 5.0, "ibm", "SUCCESS")
        self.bt.record(20.0, 10.0, "dwave", "SUCCESS")
        self.assertEqual(self.bt.total_cost_usd, 30.0)
        self.assertEqual(self.bt.qpu_minutes_used, 15.0)
        self.assertEqual(len(self.bt.job_history), 2)

    def test_thread_safety(self):
        """Budget tracker must be thread-safe."""
        errors = []
        def worker():
            try:
                for _ in range(100):
                    self.bt.record(0.01, 0.01, "test", "SUCCESS")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=worker) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        self.assertEqual(len(errors), 0)
        self.assertEqual(self.bt.total_cost_usd, 10.0)  # 10 threads * 100 * 0.01
        self.assertEqual(self.bt.qpu_minutes_used, 10.0)


class TestRouterConfig(unittest.TestCase):
    """Tests for configuration dataclass."""

    def test_default_values(self):
        """Defaults should be sensible."""
        config = RouterConfig()
        self.assertEqual(config.classical_solver, "or-tools")
        self.assertEqual(config.max_qpu_cost_usd, 500.0)
        self.assertTrue(config.enable_result_verification)

    def test_ibm_backend_list(self):
        """IBM backend preference should be a list."""
        config = RouterConfig()
        self.assertIsInstance(config.ibm_backend_preference, list)
        self.assertIn("ibm_heron", config.ibm_backend_preference)


# ============================================================================
# UNIT TESTS: BACKEND INTERFACES
# ============================================================================

class TestMockBackend(unittest.TestCase):
    """Tests using mock backends to verify routing logic."""

    def test_mock_success(self):
        backend = MockBackend("mock", ExecutionTier.CLASSICAL, "SUCCESS")
        payload = make_test_payload(n=5)
        result = backend.solve(payload, 10.0)
        self.assertEqual(result.status, "SUCCESS")
        self.assertEqual(result.backend, "mock")

    def test_mock_fallback(self):
        backend = MockBackend("mock", ExecutionTier.QPU_GATE, "FALLBACK")
        payload = make_test_payload(n=5)
        result = backend.solve(payload, 10.0)
        self.assertEqual(result.status, "FALLBACK")

    def test_mock_warm_start_propagation(self):
        backend = MockBackend("mock", ExecutionTier.CLASSICAL, "SUCCESS")
        payload = make_test_payload(n=5)
        warm = {0: 1, 1: 0}
        backend.solve(payload, 10.0, warm_start=warm)
        self.assertEqual(backend.last_warm_start, warm)


class TestClassicalBackend(unittest.TestCase):
    """Tests for OR-Tools classical solver wrapper."""

    def test_initialization(self):
        backend = ClassicalBackend()
        config = RouterConfig()
        # May or may not succeed depending on environment
        result = backend.initialize(config)
        # Just verify it doesn't crash
        self.assertIsInstance(result, bool)

    def test_solve_small_problem(self):
        backend = ClassicalBackend()
        backend.initialize(RouterConfig())
        if not backend.available:
            self.skipTest("OR-Tools not installed")

        payload = QUBOPayload(
            q_matrix={(0, 1): 2.0},
            linear_terms={0: -1.0, 1: -2.0},
            num_variables=2
        )
        result = backend.solve(payload, 10.0)
        # Should find a solution (may be SUCCESS or FAILED depending on ortools)
        self.assertIn(result.status, ["SUCCESS", "FAILED"])

    def test_solve_with_warm_start(self):
        backend = ClassicalBackend()
        backend.initialize(RouterConfig())
        if not backend.available:
            self.skipTest("OR-Tools not installed")

        payload = QUBOPayload(
            q_matrix={(0, 1): 1.0},
            linear_terms={0: -1.0, 1: -1.0},
            num_variables=2
        )
        warm = {0: 1, 1: 0}
        result = backend.solve(payload, 10.0, warm_start=warm)
        self.assertTrue(result.warm_start_used)


# ============================================================================
# INTEGRATION TESTS: ROUTER LOGIC
# ============================================================================

class TestVilitusQuantumRouter(unittest.TestCase):
    """Integration tests for the full routing pipeline."""

    def setUp(self):
        self.config = RouterConfig(
            max_qpu_cost_usd=1000.0,
            max_qpu_minutes_per_month=1000.0,
            enable_result_verification=True
        )
        self.router = VilitusQuantumRouter(self.config)
        # Replace with mocks for deterministic testing
        self.router.backends = {
            ExecutionTier.CLASSICAL: MockBackend("classical", ExecutionTier.CLASSICAL, "SUCCESS"),
            ExecutionTier.LOCAL_SIM: MockBackend("local_sim", ExecutionTier.LOCAL_SIM, "SUCCESS"),
            ExecutionTier.CLOUD_SIM: MockBackend("cloud_sim", ExecutionTier.CLOUD_SIM, "SUCCESS"),
            ExecutionTier.QPU_GATE: MockBackend("qpu_gate", ExecutionTier.QPU_GATE, "SUCCESS"),
            ExecutionTier.QPU_ANNEAL: MockBackend("qpu_anneal", ExecutionTier.QPU_ANNEAL, "SUCCESS"),
        }
        for b in self.router.backends.values():
            b.available = True
        self.router.cache.clear()

    def test_trivial_routes_to_classical(self):
        """TRIVIAL problems should use classical only."""
        payload = make_test_payload(n=10)
        result = self.router.route(payload)
        self.assertEqual(result.backend, "classical")
        self.assertEqual(result.status, "SUCCESS")

    def test_small_routes_to_classical_first(self):
        """SMALL problems should try classical first."""
        payload = make_test_payload(n=100)
        result = self.router.route(payload)
        self.assertEqual(result.backend, "classical")

    def test_large_sparse_routes_to_annealer(self):
        """LARGE_SPARSE should prefer annealer."""
        # Make classical fail so we see the preferred tier
        self.router.backends[ExecutionTier.CLASSICAL].return_status = "FAILED"
        payload = make_test_payload(n=2000, density=0.01)
        result = self.router.route(payload)
        self.assertEqual(result.backend, "qpu_anneal")

    def test_large_dense_routes_to_gate_qpu(self):
        """LARGE_DENSE should prefer gate QPU."""
        self.router.backends[ExecutionTier.CLASSICAL].return_status = "FAILED"
        self.router.backends[ExecutionTier.CLOUD_SIM].return_status = "FAILED"
        payload = make_test_payload(n=2000, density=0.2)
        result = self.router.route(payload)
        self.assertEqual(result.backend, "qpu_gate")

    def test_fallback_chain(self):
        """Should try next tier when first fails."""
        self.router.backends[ExecutionTier.CLASSICAL].return_status = "FAILED"
        self.router.backends[ExecutionTier.LOCAL_SIM].return_status = "FAILED"
        payload = make_test_payload(n=100)
        result = self.router.route(payload)
        self.assertEqual(result.backend, "cloud_sim")
        self.assertEqual(result.status, "SUCCESS")

    def test_warm_start_propagation(self):
        """Failed tier solutions should pass as warm start to next tier."""
        self.router.backends[ExecutionTier.CLASSICAL].return_status = "FAILED"
        payload = make_test_payload(n=100)
        self.router.route(payload)
        # Local sim should have received warm start from classical
        self.assertIsNotNone(self.router.backends[ExecutionTier.LOCAL_SIM].last_warm_start)

    def test_caching(self):
        """Same problem should hit cache on second call."""
        payload = make_test_payload(n=10)
        r1 = self.router.route(payload)
        r2 = self.router.route(payload)
        self.assertTrue(r2.metadata.get("cached", False))
        self.assertEqual(r1.solution, r2.solution)

    def test_force_tier_override(self):
        """force_tier should bypass auto-routing."""
        payload = make_test_payload(n=10)
        result = self.router.route(payload, force_tier=ExecutionTier.QPU_GATE)
        self.assertEqual(result.backend, "qpu_gate")

    def test_budget_guardrail_blocks_expensive(self):
        """Budget exceeded should trigger fallback before QPU."""
        self.router.backends[ExecutionTier.QPU_GATE].return_status = "FALLBACK"
        self.config.max_qpu_cost_usd = 0.0
        # Re-init with restrictive budget
        self.router = VilitusQuantumRouter(self.config)
        self.router.backends = {
            ExecutionTier.CLASSICAL: MockBackend("classical", ExecutionTier.CLASSICAL, "SUCCESS"),
            ExecutionTier.QPU_GATE: MockBackend("qpu_gate", ExecutionTier.QPU_GATE, "FALLBACK"),
        }
        self.router.backends[ExecutionTier.CLASSICAL].available = True
        self.router.backends[ExecutionTier.QPU_GATE].available = True

        payload = make_test_payload(n=10)
        result = self.router.route(payload, force_tier=ExecutionTier.QPU_GATE)
        self.assertEqual(result.status, "FALLBACK")

    def test_verification_success(self):
        """Verification should pass for consistent results."""
        payload = QUBOPayload(
            q_matrix={(0, 1): 1.0},
            linear_terms={0: -1.0, 1: -1.0},
            num_variables=2
        )
        # Mock a perfect result
        self.router.backends[ExecutionTier.CLASSICAL].return_status = "SUCCESS"
        result = self.router.route(payload)
        # With mock, verification depends on mock solution structure
        # Just verify it doesn't crash
        self.assertIn(result.status, ["SUCCESS", "FALLBACK", "FAILED"])

    def test_all_tiers_exhausted(self):
        """When all tiers fail, should return FAILED."""
        for b in self.router.backends.values():
            b.return_status = "FAILED"
        payload = make_test_payload(n=10)
        result = self.router.route(payload)
        self.assertEqual(result.status, "FAILED")

    def test_budget_report(self):
        """Budget report should reflect usage."""
        report = self.router.get_budget_report()
        self.assertIn("total_cost_usd", report)
        self.assertIn("qpu_minutes_used", report)
        self.assertIn("job_count", report)

    def test_timeout_computation(self):
        """Timeout should respect deadline and reserve time for fallbacks."""
        timeout = self.router._compute_timeout(deadline_sec=30.0, tier=ExecutionTier.CLASSICAL)
        self.assertLessEqual(timeout, 30.0)
        self.assertGreaterEqual(timeout, 5.0)

        # Later tiers should get less time (more reserve needed)
        timeout_late = self.router._compute_timeout(deadline_sec=30.0, tier=ExecutionTier.QPU_GATE)
        self.assertLess(timeout_late, timeout)


class TestAsyncRouting(unittest.TestCase):
    """Tests for async/ROS decoupled execution."""

    def setUp(self):
        self.config = RouterConfig()
        self.router = VilitusQuantumRouter(self.config)
        self.router.backends = {
            ExecutionTier.CLASSICAL: MockBackend("classical", ExecutionTier.CLASSICAL, "SUCCESS", delay_sec=0.1),
        }
        self.router.backends[ExecutionTier.CLASSICAL].available = True

    def test_route_async(self):
        """Async route should return same result as sync."""
        payload = make_test_payload(n=10)

        async def run():
            return await self.router.route_async(payload)

        result = asyncio.get_event_loop().run_until_complete(run())
        self.assertEqual(result.status, "SUCCESS")
        self.assertEqual(result.backend, "classical")

    def test_async_concurrent(self):
        """Multiple async calls should run concurrently."""
        payload = make_test_payload(n=10)

        async def run_many():
            tasks = [self.router.route_async(payload) for _ in range(5)]
            results = await asyncio.gather(*tasks)
            return results

        start = time.time()
        results = asyncio.get_event_loop().run_until_complete(run_many())
        elapsed = time.time() - start

        # 5 sequential calls would take ~0.5s, concurrent should be ~0.1s + overhead
        self.assertLess(elapsed, 0.4)
        self.assertEqual(len(results), 5)
        for r in results:
            self.assertEqual(r.status, "SUCCESS")


class TestROSBridge(unittest.TestCase):
    """Tests for ROS integration bridge."""

    def setUp(self):
        self.config = RouterConfig()
        self.router = VilitusQuantumRouter(self.config)
        self.router.backends = {
            ExecutionTier.CLASSICAL: MockBackend("classical", ExecutionTier.CLASSICAL, "SUCCESS", delay_sec=0.05),
        }
        self.router.backends[ExecutionTier.CLASSICAL].available = True
        self.bridge = ROSQuantumBridge(self.router)

    def test_submit_and_callback(self):
        """Job submission should trigger callback on completion."""
        payload = make_test_payload(n=10)
        callback_results = []

        def callback(result):
            callback_results.append(result)

        async def run():
            job_id = await self.bridge.submit_optimization(payload, callback, deadline_sec=5.0)
            # Wait for completion
            await asyncio.sleep(0.2)
            return job_id

        asyncio.get_event_loop().run_until_complete(run())
        self.assertEqual(len(callback_results), 1)
        self.assertEqual(callback_results[0].status, "SUCCESS")

    def test_cancel_job(self):
        """Cancel should stop pending job."""
        payload = make_test_payload(n=10)

        def callback(result):
            pass

        async def run():
            job_id = await self.bridge.submit_optimization(
                payload, callback, deadline_sec=10.0
            )
            cancelled = self.bridge.cancel_job(job_id)
            return cancelled

        result = asyncio.get_event_loop().run_until_complete(run())
        self.assertTrue(result)

    def test_deadline_timeout(self):
        """Exceeded deadline should return TIMEOUT."""
        # Use slow backend
        self.router.backends[ExecutionTier.CLASSICAL].delay_sec = 2.0
        payload = make_test_payload(n=10)
        callback_results = []

        def callback(result):
            callback_results.append(result)

        async def run():
            await self.bridge.submit_optimization(payload, callback, deadline_sec=0.1)
            await asyncio.sleep(0.3)

        asyncio.get_event_loop().run_until_complete(run())
        self.assertEqual(len(callback_results), 1)
        self.assertEqual(callback_results[0].status, "TIMEOUT")


# ============================================================================
# PROPERTY-BASED & EDGE CASE TESTS
# ============================================================================

class TestEdgeCases(unittest.TestCase):
    """Edge case and robustness tests."""

    def test_zero_variables(self):
        """Empty QUBO should not crash."""
        payload = QUBOPayload(q_matrix={}, linear_terms={}, num_variables=0)
        config = RouterConfig()
        self.assertEqual(payload.density, 0.0)
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.TRIVIAL)

    def test_single_variable(self):
        """Single-variable QUBO should solve correctly."""
        payload = QUBOPayload(
            q_matrix={},
            linear_terms={0: -5.0},
            num_variables=1
        )
        self.assertEqual(payload.density, 1.0)  # 1 non-zero / 1 possible

    def test_symmetric_q_matrix(self):
        """QUBO matrix should handle symmetric entries."""
        payload = QUBOPayload(
            q_matrix={(0, 1): 2.0, (1, 0): 2.0},  # Duplicate symmetric entry
            linear_terms={},
            num_variables=2
        )
        # Should not crash; ideally should normalize
        self.assertEqual(payload.num_variables, 2)

    def test_large_num_variables_small_matrix(self):
        """High variable count with sparse matrix."""
        payload = QUBOPayload(
            q_matrix={(0, 999): 1.0},
            linear_terms={},
            num_variables=1000
        )
        config = RouterConfig()
        self.assertEqual(payload.complexity_class(config), QUBOComplexity.LARGE_SPARSE)

    def test_constraint_verification(self):
        """Solution verifier should detect constraint violations."""
        router = VilitusQuantumRouter(RouterConfig())
        payload = QUBOPayload(
            q_matrix={},
            linear_terms={0: 1.0, 1: 1.0},
            num_variables=2,
            constraints=[{"type": "eq", "terms": [(0, 1), (1, 1)], "rhs": 1}]
        )
        # Solution x0=1, x1=1 violates constraint (1+1 != 1)
        bad_result = ExecutionResult(
            status="SUCCESS",
            backend="test",
            tier=ExecutionTier.CLASSICAL,
            solution={0: 1, 1: 1},
            energy=2.0
        )
        verified = router._verify_solution(payload, bad_result)
        self.assertFalse(verified)

    def test_constraint_verification_pass(self):
        """Solution verifier should pass valid constraints."""
        router = VilitusQuantumRouter(RouterConfig())
        payload = QUBOPayload(
            q_matrix={},
            linear_terms={0: 1.0, 1: 1.0},
            num_variables=2,
            constraints=[{"type": "eq", "terms": [(0, 1), (1, 1)], "rhs": 1}]
        )
        # Solution x0=1, x1=0 satisfies constraint (1+0 == 1)
        good_result = ExecutionResult(
            status="SUCCESS",
            backend="test",
            tier=ExecutionTier.CLASSICAL,
            solution={0: 1, 1: 0},
            energy=1.0
        )
        verified = router._verify_solution(payload, good_result)
        self.assertTrue(verified)


# ============================================================================
# BENCHMARK HARNESS
# ============================================================================

class BenchmarkHarness:
    """Performance benchmark for routing decisions."""

    @staticmethod
    def benchmark_routing_decision(n_vars: int, iterations: int = 1000):
        """Benchmark routing overhead (no actual solving)."""
        router = VilitusQuantumRouter(RouterConfig())
        # Disable all backends to measure pure routing logic
        for b in router.backends.values():
            b.available = False
        payload = make_test_payload(n=n_vars)

        start = time.time()
        for _ in range(iterations):
            complexity = payload.complexity_class(router.config)
            tier_order = router.routing_policy.get(complexity, [ExecutionTier.CLASSICAL])
        elapsed = time.time() - start

        return {
            "n_vars": n_vars,
            "iterations": iterations,
            "total_sec": elapsed,
            "per_iteration_ms": (elapsed / iterations) * 1000
        }

    @staticmethod
    def benchmark_fingerprint(n_vars: int, iterations: int = 1000):
        """Benchmark fingerprinting speed."""
        payload = make_test_payload(n=n_vars)
        start = time.time()
        for _ in range(iterations):
            payload.fingerprint()
        elapsed = time.time() - start
        return {
            "n_vars": n_vars,
            "iterations": iterations,
            "total_sec": elapsed,
            "per_iteration_ms": (elapsed / iterations) * 1000
        }


class TestBenchmarks(unittest.TestCase):
    """Self-tests for benchmark harness."""

    def test_routing_decision_benchmark(self):
        result = BenchmarkHarness.benchmark_routing_decision(n_vars=100, iterations=1000)
        self.assertLess(result["per_iteration_ms"], 1.0)  # Should be sub-millisecond

    def test_fingerprint_benchmark(self):
        result = BenchmarkHarness.benchmark_fingerprint(n_vars=100, iterations=1000)
        self.assertLess(result["per_iteration_ms"], 5.0)  # Should be under 5ms


# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    # Run with: python -m unittest test_vilitus_quantum_router.py -v
    # Or: python test_vilitus_quantum_router.py
    unittest.main(verbosity=2)
