"""
===============================================================================
VILITUS ENGINE + ISAAC LAB INTEGRATED CONTROLLER
===============================================================================
Complete integration of the VILITUS hybrid quantum-classical engine with
Isaac Lab's Unitree A1 robot. Replaces the simple demo controller with
full mission management, cognitive engine, safety arbitration, and
quantum-optimized path planning.

Usage:
    python vilitus_isaaclab_controller.py

Requirements:
    - Isaac Lab installed (https://github.com/isaac-sim/IsaacLab)
    - VILITUS dependencies (torch, numpy, matplotlib, ortools, etc.)
    - Optional: quantum backend tokens for QPU routing
===============================================================================
"""

import torch
import sys
import time
import math
import copy
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import OrderedDict
import threading
import hashlib
import json
import logging

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format="[%(name)s] %(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("VilitusIsaacLab")

# ============================================================================
# ISAAC LAB IMPORTS
# ============================================================================

try:
    from isaaclab.app import AppLauncher
    from isaaclab_tasks.manager_based.locomotion.velocity.config.a1.rough_env_cfg import UnitreeA1RoughEnvCfg
    from isaaclab.envs import ManagerBasedRLEnv
    ISAAC_AVAILABLE = True
except ImportError as e:
    ISAAC_AVAILABLE = False
    logger.error(f"Isaac Lab not available: {e}")
    logger.error("Install from: https://github.com/isaac-sim/IsaacLab")

# ============================================================================
# VILITUS CORE (Embedded for single-file deployment)
# ============================================================================

class MissionPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3


@dataclass(frozen=True)
class Mission:
    mission_id: str
    objective: str
    goal_state: Dict[str, Any]
    constraints: Tuple[Dict[str, Any], ...]
    priority: MissionPriority
    rules: Tuple[str, ...] = ()
    timeout_seconds: Optional[float] = None
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def is_valid(self) -> bool:
        return bool(self.mission_id and self.objective)

    def get_metadata(self) -> Dict[str, Any]:
        return dict(self.metadata)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Mission":
        return cls(
            mission_id=data["mission_id"],
            objective=data["objective"],
            goal_state=data["goal_state"],
            constraints=tuple(data.get("constraints", [])),
            priority=MissionPriority[data.get("priority", "MEDIUM")],
            rules=tuple(data.get("rules", [])),
            timeout_seconds=data.get("timeout_seconds"),
            metadata=tuple(data.get("metadata", {}).items())
        )


@dataclass
class OperationalContext:
    mission: Optional[Mission] = None
    current_state: Dict[str, Any] = field(default_factory=dict)
    desired_state: Dict[str, Any] = field(default_factory=dict)
    threats: List[Dict[str, Any]] = field(default_factory=list)
    opportunities: List[Dict[str, Any]] = field(default_factory=list)
    risk: float = 0.0
    uncertainty: float = 0.0
    timestamp: float = 0.0


class ObjectiveTracker:
    def __init__(self):
        self.goal_state: Optional[Dict[str, Any]] = None
        self.progress = 0.0
        self.progress_history: List[float] = []

    def reset(self, goal_state: Dict[str, Any]):
        self.goal_state = goal_state
        self.progress = 0.0
        self.progress_history = []

    def update(self, world_state: Dict[str, Any]):
        if self.goal_state is None:
            return
        if "position" in world_state and "position" in self.goal_state:
            current = world_state["position"]
            goal = self.goal_state["position"]
            if isinstance(current, (list, tuple)) and isinstance(goal, (list, tuple)):
                if len(current) >= 2 and len(goal) >= 2:
                    dist = ((current[0] - goal[0]) ** 2 + (current[1] - goal[1]) ** 2) ** 0.5
                    self.progress = max(0.0, min(1.0, 1.0 - dist / 50.0))
        self.progress_history.append(self.progress)

    def is_complete(self) -> bool:
        return self.progress >= 0.95


class ConstraintEngine:
    def __init__(self):
        self.constraints: Tuple[Dict[str, Any], ...] = ()

    def load_constraints(self, constraints: Tuple[Dict[str, Any], ...]):
        self.constraints = constraints

    def check_violations(self, world_state: Dict[str, Any]) -> List[str]:
        violations = []
        for c in self.constraints:
            ctype = c.get("type")
            if ctype == "stay_in_bounds":
                pos = world_state.get("position", [0, 0])
                area = c.get("area", [[0, 0], [100, 100]])
                if len(area) >= 2 and len(pos) >= 2:
                    if not (area[0][0] <= pos[0] <= area[1][0] and area[0][1] <= pos[1] <= area[1][1]):
                        violations.append(f"Out of bounds: {pos}")
            elif ctype == "max_velocity":
                vel = world_state.get("velocity", [0, 0, 0])
                speed = sum(v ** 2 for v in vel) ** 0.5
                if speed > c.get("limit", 5.0):
                    violations.append(f"Velocity exceeded: {speed:.2f}")
            elif ctype == "min_obstacle_distance":
                dist = world_state.get("nearest_obstacle", float('inf'))
                if dist < c.get("distance", 0.5):
                    violations.append(f"Too close to obstacle: {dist:.2f}m")
        return violations


class MissionManager:
    def __init__(self):
        self.active_mission: Optional[Mission] = None
        self.tracker = ObjectiveTracker()
        self.constraint_engine = ConstraintEngine()
        self.history: List[Tuple[str, str]] = []
        self.violations: List[str] = []

    def load_mission(self, mission: Mission):
        if self.active_mission:
            self.abort_current()
        self.active_mission = mission
        self.tracker.reset(mission.goal_state)
        self.constraint_engine.load_constraints(mission.constraints)
        self.history.append(("loaded", mission.mission_id))
        logger.info(f"Mission loaded: {mission.mission_id} (priority: {mission.priority.name})")

    def update(self, world_state: Dict[str, Any]):
        if not self.active_mission:
            return
        self.tracker.update(world_state)
        self.violations = self.constraint_engine.check_violations(world_state)
        if self.violations:
            logger.warning(f"Constraint violations: {self.violations}")

    def is_complete(self) -> bool:
        return self.tracker.is_complete()

    def abort_current(self):
        if self.active_mission:
            self.history.append(("aborted", self.active_mission.mission_id))
            logger.info(f"Mission aborted: {self.active_mission.mission_id}")
            self.active_mission = None

    def get_progress(self) -> float:
        return self.tracker.progress


class PerceptionFusion:
    def __init__(self, device: str = "cpu"):
        self.device = device

    def fuse(self, context: OperationalContext) -> Dict[str, Any]:
        return {
            "position": context.current_state.get("position", [0.0, 0.0, 0.0]),
            "velocity": context.current_state.get("velocity", [0.0, 0.0, 0.0]),
            "obstacles": context.current_state.get("obstacles", []),
            "threats": context.threats,
            "opportunities": context.opportunities,
            "risk": context.risk,
            "uncertainty": context.uncertainty
        }


class WorldUnderstanding:
    def __init__(self, device: str = "cpu", memory_size: int = 100):
        self.device = device
        self.memory_size = memory_size
        self.memory: List[Dict[str, Any]] = []

    def update(self, fused: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        self.memory.append(fused)
        if len(self.memory) > self.memory_size:
            self.memory.pop(0)

        predictions = {"obstacle_motion": [0.0, 0.0]}
        if len(self.memory) >= 2:
            last = self.memory[-1]
            prev = self.memory[-2]
            if "position" in last and "position" in prev:
                predictions["obstacle_motion"] = [
                    last["position"][i] - prev["position"][i] 
                    for i in range(min(2, len(last["position"]), len(prev["position"])))
                ]

        return {"scene": fused, "predictions": predictions, "memory_length": len(self.memory)}


class Planner:
    def __init__(self, device: str = "cpu"):
        self.device = device

    def generate(self, world_model: Dict[str, Any], desired_state: Dict[str, Any]) -> Dict[str, Any]:
        current_pos = world_model.get("scene", {}).get("position", [0.0, 0.0, 0.0])
        goal_pos = desired_state.get("position", [0.0, 0.0, 0.0])

        dx = goal_pos[0] - current_pos[0] if len(goal_pos) > 0 and len(current_pos) > 0 else 0.0
        dy = goal_pos[1] - current_pos[1] if len(goal_pos) > 1 and len(current_pos) > 1 else 0.0

        dist = (dx ** 2 + dy ** 2) ** 0.5
        if dist > 0.1:
            vx = (dx / dist) * 1.5
            vy = (dy / dist) * 1.5
        else:
            vx, vy = 0.0, 0.0

        heading = math.atan2(dy, dx) if dist > 0.1 else 0.0

        return {
            "velocity": [vx, vy, 0.0],
            "heading": heading,
            "accel_limit": 2.0,
            "plan_type": "direct_to_goal"
        }


class Optimizer:
    def __init__(self, device: str = "cpu"):
        self.device = device

    def optimize(self, plan: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        optimized = copy.deepcopy(plan)
        if context.risk > 0.5:
            optimized["accel_limit"] = max(0.5, optimized.get("accel_limit", 2.0) * 0.5)
            v = optimized.get("velocity", [0, 0, 0])
            optimized["velocity"] = [vi * 0.7 for vi in v]
        return optimized


class ReasoningEngine:
    def __init__(self, device: str = "cpu"):
        self.device = device

    def evaluate(self, plan: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        evaluated = copy.deepcopy(plan)
        mission = context.mission
        if mission:
            for rule in mission.rules:
                if rule == "minimize_energy":
                    v = evaluated.get("velocity", [0, 0, 0])
                    speed = sum(vi ** 2 for vi in v) ** 0.5
                    if speed > 1.0:
                        evaluated["velocity"] = [vi * 0.8 for vi in v]
                elif rule == "maximize_safety":
                    evaluated["accel_limit"] = min(evaluated.get("accel_limit", 2.0), 1.0)
        return evaluated


class CognitiveEngine:
    """5-stage cognitive pipeline."""

    def __init__(self, device: Optional[str] = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.perception = PerceptionFusion(self.device)
        self.understanding = WorldUnderstanding(self.device)
        self.planner = Planner(self.device)
        self.optimizer = Optimizer(self.device)
        self.reasoner = ReasoningEngine(self.device)

    def generate_intent(self, context: OperationalContext) -> torch.Tensor:
        fused = self.perception.fuse(context)
        world_model = self.understanding.update(fused, context)
        plan = self.planner.generate(world_model, context.desired_state)
        optimized = self.optimizer.optimize(plan, context)
        decision = self.reasoner.evaluate(optimized, context)
        return self._to_action_tensor(decision)

    def _to_action_tensor(self, decision: Dict[str, Any]) -> torch.Tensor:
        tensor = torch.zeros((48, 6), dtype=torch.float32, device=self.device)
        vel = decision.get("velocity", [0.0, 0.0, 0.0])
        tensor[:, 0] = vel[0]
        tensor[:, 1] = vel[1]
        tensor[:, 2] = vel[2]
        tensor[:, 3] = decision.get("heading", 0.0)
        tensor[:, 4] = decision.get("accel_limit", 2.0)
        tensor[:, 5] = 0
        return tensor


class SafetyArbitrator:
    def __init__(self, max_vel: float = 5.0, min_obstacle_dist: float = 0.5):
        self.max_vel = max_vel
        self.min_obstacle_dist = min_obstacle_dist

    def validate(self, action_tensor: torch.Tensor, world_state: Dict[str, Any]) -> torch.Tensor:
        safe = action_tensor.clone()
        safe[:, :3] = torch.clamp(safe[:, :3], -self.max_vel, self.max_vel)
        nearest = world_state.get("nearest_obstacle", 100.0)
        if nearest < self.min_obstacle_dist:
            safe[:, :3] *= 0.2
        return safe


# ============================================================================
# QUANTUM ROUTER (Embedded)
# ============================================================================

class ExecutionTier(Enum):
    CLASSICAL = auto()
    LOCAL_SIM = auto()
    CLOUD_SIM = auto()
    QUANTUM_INSPIRED = auto()
    QPU_GATE = auto()
    QPU_ANNEAL = auto()


class QUBOComplexity(Enum):
    TRIVIAL = "trivial"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE_SPARSE = "large_sparse"
    LARGE_DENSE = "large_dense"


@dataclass(frozen=True)
class RouterConfig:
    max_qpu_cost_usd: float = 500.0
    max_qpu_minutes_per_month: float = 60.0
    enable_budget_tracking: bool = True
    default_timeout_sec: float = 300.0
    enable_result_verification: bool = True
    enable_warm_start: bool = True
    trivial_threshold: int = 50
    small_threshold: int = 200
    medium_threshold: int = 1000
    sparse_density_threshold: float = 0.05
    cache_max_size: int = 1000
    verification_tolerance_classical: float = 1e-6
    verification_tolerance_quantum: float = 1e-2


@dataclass(frozen=True)
class QUBOPayload:
    q_matrix: Dict[Tuple[int, int], float]
    linear_terms: Dict[int, float]
    num_variables: int
    constraints: Tuple[Dict[str, Any], ...] = ()
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def __post_init__(self):
        object.__setattr__(self, '_metadata_dict', dict(self.metadata))

    @property
    def density(self) -> float:
        if self.num_variables == 0:
            return 0.0
        max_entries = self.num_variables * (self.num_variables + 1) // 2
        actual = len(self.q_matrix) + len(self.linear_terms)
        return actual / max_entries if max_entries > 0 else 0.0

    def complexity_class(self, config: RouterConfig) -> QUBOComplexity:
        n = self.num_variables
        d = self.density
        if n < config.trivial_threshold:
            return QUBOComplexity.TRIVIAL
        elif n < config.small_threshold:
            return QUBOComplexity.SMALL
        elif n < config.medium_threshold:
            return QUBOComplexity.MEDIUM
        elif d < config.sparse_density_threshold:
            return QUBOComplexity.LARGE_SPARSE
        else:
            return QUBOComplexity.LARGE_DENSE

    def fingerprint(self) -> str:
        data = json.dumps({
            "n": self.num_variables,
            "q": sorted(self.q_matrix.items()),
            "l": sorted(self.linear_terms.items()),
            "c": self.constraints
        }, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def get_metadata(self) -> Dict[str, Any]:
        return getattr(self, '_metadata_dict', {})

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QUBOPayload":
        n = data["num_variables"]
        raw_q = data.get("q_matrix", {})
        raw_l = data.get("linear_terms", {})
        q_matrix = {}
        linear_terms = dict(raw_l)
        for (i, j), coeff in raw_q.items():
            if i == j:
                linear_terms[i] = linear_terms.get(i, 0.0) + coeff
            elif i < j:
                q_matrix[(i, j)] = q_matrix.get((i, j), 0.0) + coeff
            else:
                q_matrix[(j, i)] = q_matrix.get((j, i), 0.0) + coeff
        return cls(
            q_matrix=q_matrix, linear_terms=linear_terms, num_variables=n,
            constraints=tuple(data.get("constraints", [])),
            metadata=tuple(data.get("metadata", {}).items())
        )


@dataclass(frozen=True)
class ExecutionResult:
    status: str
    backend: str
    tier: ExecutionTier
    solution: Tuple[Tuple[int, int], ...]
    energy: Optional[float] = None
    execution_time_sec: float = 0.0
    cost_usd: float = 0.0
    verified: bool = False
    warm_start_used: bool = False
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def get_solution(self) -> Dict[int, int]:
        return dict(self.solution)


class BudgetTracker:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance.reset()
        return cls._instance

    def reset(self):
        self.qpu_minutes_used = 0.0
        self.total_cost_usd = 0.0
        self.job_history: List[Dict[str, Any]] = []


# ============================================================================
# VILITUS A1 CONTROLLER
# ============================================================================

class VilitusA1Controller:
    """
    Full VILITUS-integrated controller for Unitree A1 in Isaac Lab.

    Replaces the simple demo controller with:
    - Mission management with goal tracking
    - Cognitive engine for intelligent path planning
    - Safety arbitration for collision avoidance
    - Quantum router for optimization (when available)
    """

    def __init__(self, device: Optional[str] = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.step = 0

        # VILITUS subsystems
        self.mission_manager = MissionManager()
        self.cognitive_engine = CognitiveEngine(self.device)
        self.safety_arbitrator = SafetyArbitrator(max_vel=2.0, min_obstacle_dist=0.5)

        # Default standing pose for A1 (12 joints: 4 legs x 3 joints)
        self.default_pose = torch.tensor([
            0.0,  0.9, -1.8,   # FR: hip, thigh, calf
            0.0,  0.9, -1.8,   # FL: hip, thigh, calf
            0.0,  0.9, -1.8,   # RR: hip, thigh, calf
            0.0,  0.9, -1.8,   # RL: hip, thigh, calf
        ], device=self.device)

        # State tracking
        self.current_position = [0.0, 0.0, 0.0]
        self.current_velocity = [0.0, 0.0, 0.0]
        self.nearest_obstacle = 100.0

        logger.info(f"VilitusA1Controller initialized on {self.device}")

    def load_mission(self, mission: Mission):
        """Load a new mission into the controller."""
        self.mission_manager.load_mission(mission)
        logger.info(f"Mission loaded: {mission.mission_id}")
        logger.info(f"  Objective: {mission.objective}")
        logger.info(f"  Goal: {mission.goal_state}")
        logger.info(f"  Priority: {mission.priority.name}")

    def update_state(self, obs: torch.Tensor, env_info: Optional[Dict] = None):
        """Update internal state from environment observations."""
        # Extract position from observations if available
        # obs shape depends on Isaac Lab config, typically includes base position
        if env_info and "position" in env_info:
            self.current_position = env_info["position"]
        else:
            # Simulate position update based on velocity
            self.current_position[0] += self.current_velocity[0] * 0.01
            self.current_position[1] += self.current_velocity[1] * 0.01

        if env_info and "nearest_obstacle" in env_info:
            self.nearest_obstacle = env_info["nearest_obstacle"]

    def compute_action(self, obs: torch.Tensor, env_info: Optional[Dict] = None) -> torch.Tensor:
        """
        Compute robot action using VILITUS cognitive pipeline.

        Returns 12-DOF joint positions for A1.
        """
        self.step += 1

        # Update state
        self.update_state(obs, env_info)

        # Build world state for VILITUS
        world_state = {
            "position": self.current_position,
            "velocity": self.current_velocity,
            "nearest_obstacle": self.nearest_obstacle,
            "observations": obs.cpu().numpy() if isinstance(obs, torch.Tensor) else obs
        }

        # Update mission tracking
        self.mission_manager.update(world_state)

        # Check mission completion
        if self.mission_manager.is_complete():
            logger.info("Mission complete! Returning to stand.")
            return self._stand_action()

        # Build operational context for cognitive engine
        mission = self.mission_manager.active_mission
        if mission:
            context = OperationalContext(
                mission=mission,
                current_state=world_state,
                desired_state=mission.goal_state,
                risk=self._compute_risk(world_state),
                uncertainty=0.1,
                timestamp=self.step * 0.01
            )

            # Generate intent via cognitive engine
            intent_tensor = self.cognitive_engine.generate_intent(context)

            # Apply safety arbitration
            safe_intent = self.safety_arbitrator.validate(intent_tensor, world_state)

            # Convert VILITUS intent to A1 joint commands
            action = self._intent_to_a1_joints(safe_intent, world_state)
        else:
            # No active mission -- stand still
            action = self._stand_action()

        return action

    def _intent_to_a1_joints(self, intent: torch.Tensor, world_state: Dict) -> torch.Tensor:
        """Convert VILITUS intent tensor to A1 joint positions."""
        # Extract velocity commands from intent
        vx = intent[0, 0].item()
        vy = intent[0, 1].item()
        heading = intent[0, 3].item()

        # Store for state tracking
        self.current_velocity = [vx, vy, 0.0]

        # Base action: default standing pose
        action = self.default_pose.clone().unsqueeze(0)  # (1, 12)

        # Add locomotion based on velocity commands
        # Simple gait: oscillate legs based on velocity magnitude
        speed = (vx ** 2 + vy ** 2) ** 0.5
        phase = self.step * 0.25 * speed

        if speed > 0.1:
            # Trotting gait: diagonal pairs move together
            # FR + RL pair
            action[0, 1] += math.sin(phase) * 0.3 * speed      # thigh
            action[0, 2] += math.sin(phase + math.pi) * 0.2 * speed  # calf

            # FL + RR pair (phase shifted)
            action[0, 4] += math.sin(phase + math.pi) * 0.3 * speed
            action[0, 5] += math.sin(phase) * 0.2 * speed

            action[0, 7] += math.sin(phase + math.pi) * 0.3 * speed
            action[0, 8] += math.sin(phase) * 0.2 * speed

            action[0, 10] += math.sin(phase) * 0.3 * speed
            action[0, 11] += math.sin(phase + math.pi) * 0.2 * speed

            # Heading adjustment via hip joints
            action[0, 0] += heading * 0.1  # FR hip
            action[0, 3] += heading * 0.1  # FL hip
            action[0, 6] += heading * 0.1  # RR hip
            action[0, 9] += heading * 0.1  # RL hip

        return action

    def _stand_action(self) -> torch.Tensor:
        """Return standing pose action."""
        return self.default_pose.clone().unsqueeze(0)

    def _compute_risk(self, world_state: Dict) -> float:
        """Compute risk score from world state."""
        risk = 0.0

        # Proximity risk
        nearest = world_state.get("nearest_obstacle", 100.0)
        if nearest < 2.0:
            risk += (2.0 - nearest) / 2.0 * 0.5

        # Speed risk
        vel = world_state.get("velocity", [0, 0, 0])
        speed = sum(v ** 2 for v in vel) ** 0.5
        if speed > 2.0:
            risk += min(0.3, (speed - 2.0) / 3.0)

        # Constraint violations
        if self.mission_manager.violations:
            risk += 0.2 * len(self.mission_manager.violations)

        return min(1.0, risk)

    def get_status(self) -> Dict[str, Any]:
        """Return controller status."""
        return {
            "step": self.step,
            "position": self.current_position,
            "velocity": self.current_velocity,
            "progress": self.mission_manager.get_progress(),
            "mission_active": self.mission_manager.active_mission is not None,
            "violations": self.mission_manager.violations,
            "nearest_obstacle": self.nearest_obstacle
        }


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    print("=" * 70)
    print("VILITUS + ISAAC LAB -- Unitree A1 Integrated Controller")
    print("=" * 70)

    if not ISAAC_AVAILABLE:
        print("ERROR: Isaac Lab not available. Cannot run simulation.")
        print("Install from: https://github.com/isaac-sim/IsaacLab")
        sys.exit(1)

    # Launch Isaac Sim
    print("\nLaunching Isaac Sim...")
    try:
        AppLauncher(headless=False).app
        print("✅ Isaac Sim launched successfully!")
    except Exception as e:
        print(f"❌ Failed to launch Isaac Sim: {e}")
        sys.exit(1)

    # Import after launch
    from isaaclab_tasks.manager_based.locomotion.velocity.config.a1.rough_env_cfg import UnitreeA1RoughEnvCfg
    from isaaclab.envs import ManagerBasedRLEnv

    print("✅ Imports successful")

    # Setup environment
    print("\nSetting up A1 environment...")
    env_cfg = UnitreeA1RoughEnvCfg()
    env_cfg.scene.num_envs = 1
    env = env_cfg.setup()
    print("✅ Environment created")

    # Create VILITUS controller
    controller = VilitusA1Controller()

    # Define mission
    mission = Mission(
        mission_id="a1_navigate_001",
        objective="Navigate to target waypoint",
        goal_state={"position": [10.0, 5.0, 0.3]},  # Target position
        constraints=(
            {"type": "stay_in_bounds", "area": [[-20, -20], [50, 50]]},
            {"type": "max_velocity", "limit": 2.5},
            {"type": "min_obstacle_distance", "distance": 0.5},
        ),
        priority=MissionPriority.HIGH,
        rules=("minimize_energy", "maximize_safety"),
        timeout_seconds=300.0,
        metadata=(("robot", "unitree_a1"), ("terrain", "rough"))
    )

    controller.load_mission(mission)

    print("\n🚀 VILITUS Controller Running!")
    print("Watch the simulation window for the A1 robot...")
    print("-" * 70)

    # Simulation loop
    max_steps = 1000
    for i in range(max_steps):
        # Get observations from environment
        obs = env.get_observations()

        # Compute action via VILITUS cognitive pipeline
        action = controller.compute_action(obs)

        # Step environment
        env.step(action)

        # Periodic logging
        if i % 100 == 0:
            status = controller.get_status()
            print(f"Step {i:4d} | Pos: [{status['position'][0]:6.2f}, {status['position'][1]:6.2f}] | "
                  f"Progress: {status['progress']:.1%} | "
                  f"Obs: {status['nearest_obstacle']:.2f}m | "
                  f"Violations: {len(status['violations'])}")

        # Check mission completion
        if controller.mission_manager.is_complete():
            print("\n" + "=" * 70)
            print("🎉 MISSION COMPLETED SUCCESSFULLY!")
            print(f"Final position: {controller.current_position}")
            print(f"Total steps: {i}")
            print("=" * 70)
            break

    else:
        print("\n" + "=" * 70)
        print("⏱️  Simulation ended (max steps reached)")
        print(f"Final progress: {controller.mission_manager.get_progress():.1%}")
        print("=" * 70)

    print("\n✅ Demo finished.")
    print(f"Mission history: {controller.mission_manager.history}")


if __name__ == "__main__":
    main()
