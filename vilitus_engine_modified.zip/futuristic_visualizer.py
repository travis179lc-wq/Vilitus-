"""
===============================================================================
VILITUS ENGINE v3.0 -- FUTURISTIC 3D VISUALIZATION SYSTEM
===============================================================================
Production-grade real-time 3D visualization with cyberpunk aesthetics,
GPU acceleration, and immersive HUD overlay.

Author: Vilitus Engineering Team
Version: 3.0.0
Date: 2026-07-13
License: MIT
===============================================================================
"""

import pygame
import numpy as np
import math
import time
from typing import Dict, Any, Optional, Tuple
from dataclasses import dataclass
import threading

try:
    from OpenGL.GL import *
    from OpenGL.GLU import *
    OPENGL_AVAILABLE = True
except ImportError:
    OPENGL_AVAILABLE = False

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


@dataclass
class Color:
    """RGB color with alpha support."""
    r: float
    g: float
    b: float
    a: float = 1.0
    
    def to_tuple(self) -> Tuple[float, float, float, float]:
        return (self.r, self.g, self.b, self.a)
    
    def to_rgb(self) -> Tuple[float, float, float]:
        return (self.r, self.g, self.b)


# Cyberpunk color palette - BRIGHTER and more vibrant
CYBERPUNK_COLORS = {
    'neon_blue': Color(0.6, 1.0, 1.0, 1.0),
    'neon_pink': Color(1.0, 0.7, 0.9, 1.0),
    'neon_green': Color(0.6, 1.0, 0.8, 1.0),
    'neon_orange': Color(1.0, 0.95, 0.6, 1.0),
    'neon_purple': Color(0.95, 0.8, 1.0, 1.0),
    'neon_red': Color(1.0, 0.6, 0.7, 1.0),
    'neon_cyan': Color(0.6, 1.0, 1.0, 1.0),
    'neon_yellow': Color(1.0, 1.0, 0.7, 1.0),
    'dark_bg': Color(0.4, 0.45, 0.55, 1.0),
    'grid_line': Color(0.6, 0.9, 1.0, 0.9),
    'hud_text': Color(0.6, 1.0, 1.0, 1.0),
    'warning': Color(1.0, 0.8, 0.6, 1.0),
    'success': Color(0.7, 1.0, 0.8, 1.0),
}


class ParticleSystem:
    """GPU-accelerated particle system for visual effects."""
    
    def __init__(self, max_particles: int = 1000):
        self.max_particles = max_particles
        self.particles = []
        self.enabled = True
        
    def emit(self, position: Tuple[float, float, float], 
             color: Color, count: int = 10, lifetime: float = 2.0):
        """Emit particles at position."""
        for _ in range(count):
            velocity = np.random.uniform(-0.5, 0.5, 3)
            self.particles.append({
                'position': np.array(position, dtype=np.float32),
                'velocity': velocity,
                'color': color,
                'lifetime': lifetime,
                'age': 0.0,
                'size': np.random.uniform(0.02, 0.05)
            })
            
    def update(self, dt: float):
        """Update particle positions and lifetimes."""
        alive_particles = []
        for p in self.particles:
            p['age'] += dt
            if p['age'] < p['lifetime']:
                p['position'] += p['velocity'] * dt
                p['velocity'] *= 0.98  # Drag
                alive_particles.append(p)
        self.particles = alive_particles
        
    def render(self):
        """Render particles with glow effect."""
        if not self.enabled or not self.particles:
            return
            
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        for p in self.particles:
            alpha = 1.0 - (p['age'] / p['lifetime'])
            color = p['color'].to_tuple()
            color = (color[0], color[1], color[2], color[3] * alpha)
            
            glPushMatrix()
            glTranslatef(*p['position'])
            
            # Draw glowing particle
            glColor4f(*color)
            size = p['size'] * (1.0 + alpha * 0.5)
            
            # Core
            glBegin(GL_TRIANGLE_FAN)
            for angle in range(0, 361, 45):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * size, math.sin(rad) * size, 0)
            glEnd()
            
            # Glow
            glColor4f(color[0], color[1], color[2], color[3] * 0.3)
            glBegin(GL_TRIANGLE_FAN)
            for angle in range(0, 361, 45):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * size * 2, math.sin(rad) * size * 2, 0)
            glEnd()
            
            glPopMatrix()
            
        glDisable(GL_BLEND)


class FuturisticHUD:
    """Cyberpunk-style HUD overlay with real-time metrics."""
    
    def __init__(self, screen_width: int, screen_height: int):
        self.width = screen_width
        self.height = screen_height
        self.font_size = 18
        self.font = None
        self.glow_enabled = True
        
    def init_font(self):
        """Initialize pygame font."""
        try:
            self.font = pygame.font.SysFont("Consolas", self.font_size, bold=True)
            return True
        except:
            return False
            
    def draw_text(self, surface, text: str, x: int, y: int, 
                  color: Color = CYBERPUNK_COLORS['hud_text'], 
                  glow: bool = True, size: int = None):
        """Draw text with optional glow effect."""
        if not self.font:
            return
            
        font_size = size or self.font_size
        font = pygame.font.SysFont("Consolas", font_size, bold=True)
        
        color_rgb = color.to_rgb()
        
        if glow and self.glow_enabled:
            # Glow effect
            glow_surface = font.render(text, True, (color_rgb[0] * 0.5, color_rgb[1] * 0.5, color_rgb[2] * 0.5))
            for dx, dy in [(-2, -2), (-2, 2), (2, -2), (2, 2)]:
                surface.blit(glow_surface, (x + dx, y + dy))
        
        # Main text
        text_surface = font.render(text, True, color_rgb)
        surface.blit(text_surface, (x, y))
        
    def draw_progress_bar(self, surface, x: int, y: int, width: int, height: int,
                         progress: float, color: Color, label: str = ""):
        """Draw futuristic progress bar with glow."""
        # Background
        pygame.draw.rect(surface, (20, 20, 40), (x, y, width, height))
        pygame.draw.rect(surface, color.to_rgb(), (x, y, width * progress, height))
        
        # Border with glow
        pygame.draw.rect(surface, color.to_rgb(), (x, y, width, height), 2)
        
        if label:
            self.draw_text(surface, label, x, y - 25, color)
            
    def draw_panel(self, surface, x: int, y: int, width: int, height: int,
                   title: str, color: Color = CYBERPUNK_COLORS['neon_blue']):
        """Draw futuristic panel with title."""
        # Semi-transparent background
        panel_surface = pygame.Surface((width, height), pygame.SRCALPHA)
        panel_surface.fill((10, 15, 30, 200))
        surface.blit(panel_surface, (x, y))
        
        # Border with corner accents
        pygame.draw.rect(surface, color.to_rgb(), (x, y, width, height), 2)
        
        # Corner accents
        corner_size = 10
        pygame.draw.line(surface, color.to_rgb(), (x, y), (x + corner_size, y), 3)
        pygame.draw.line(surface, color.to_rgb(), (x, y), (x, y + corner_size), 3)
        pygame.draw.line(surface, color.to_rgb(), (x + width - corner_size, y + height), 
                         (x + width, y + height), 3)
        pygame.draw.line(surface, color.to_rgb(), (x + width, y + height - corner_size), 
                         (x + width, y + height), 3)
        
        # Title
        self.draw_text(surface, title, x + 10, y + 10, color, size=20)
        
    def render(self, surface, context: Dict[str, Any]):
        """Render complete HUD overlay."""
        if not self.init_font():
            return
            
        # Top bar - Mission status
        self.draw_panel(surface, 10, 10, 400, 100, "MISSION STATUS", CYBERPUNK_COLORS['neon_blue'])
        mission_id = context.get('mission_id', 'N/A')
        progress = context.get('progress', 0.0)
        self.draw_text(surface, f"ID: {mission_id}", 30, 50)
        self.draw_progress_bar(surface, 30, 70, 350, 20, progress, CYBERPUNK_COLORS['neon_green'], 
                              f"PROGRESS: {progress*100:.1f}%")
        
        # Top right - System status
        self.draw_panel(surface, self.width - 320, 10, 300, 100, "SYSTEM STATUS", CYBERPUNK_COLORS['neon_purple'])
        step = context.get('step', 0)
        fps = context.get('fps', 0)
        self.draw_text(surface, f"STEP: {step}", self.width - 300, 50)
        self.draw_text(surface, f"FPS: {fps:.1f}", self.width - 300, 75)
        
        # GPU info if available
        if TORCH_AVAILABLE and torch.cuda.is_available():
            gpu_name = torch.cuda.get_device_name(0)
            gpu_mem = torch.cuda.memory_allocated(0) / 1024**3
            self.draw_text(surface, f"GPU: {gpu_name[:20]}...", self.width - 300, 100, 
                          CYBERPUNK_COLORS['neon_green'], size=14)
            self.draw_text(surface, f"VRAM: {gpu_mem:.2f}GB", self.width - 300, 120, 
                          CYBERPUNK_COLORS['neon_green'], size=14)
        
        # Bottom left - Position info
        self.draw_panel(surface, 10, self.height - 120, 250, 100, "POSITION", CYBERPUNK_COLORS['neon_orange'])
        pos = context.get('position', [0, 0, 0])
        self.draw_text(surface, f"X: {pos[0]:.2f}m", 30, self.height - 90)
        self.draw_text(surface, f"Y: {pos[1]:.2f}m", 30, self.height - 70)
        self.draw_text(surface, f"Z: {pos[2]:.2f}m", 30, self.height - 50)
        
        # Bottom right - Objective
        self.draw_panel(surface, self.width - 320, self.height - 120, 300, 100, "OBJECTIVE", 
                       CYBERPUNK_COLORS['neon_pink'])
        goal = context.get('goal', [0, 0, 0])
        distance = context.get('distance_to_goal', 0.0)
        self.draw_text(surface, f"GOAL: ({goal[0]:.1f}, {goal[1]:.1f}, {goal[2]:.1f})", 
                      self.width - 300, self.height - 90)
        self.draw_text(surface, f"DISTANCE: {distance:.1f}m", self.width - 300, self.height - 70)
        
        # Warning if close to obstacle
        obstacle_dist = context.get('nearest_obstacle', 100.0)
        if obstacle_dist < 2.0:
            self.draw_text(surface, f"WARNING: OBSTACLE {obstacle_dist:.1f}m", 
                          self.width - 300, self.height - 50, CYBERPUNK_COLORS['warning'])


class FuturisticVisualizer:
    """Production-grade 3D visualization with cyberpunk aesthetics."""
    
    def __init__(self, width: int = 1920, height: int = 1080):
        self.width = width
        self.height = height
        self.running = False
        self.context = None
        
        # Graphics components
        self.particle_system = ParticleSystem(max_particles=5000)  # More particles
        self.hud = FuturisticHUD(width, height)
        
        # Camera
        self.camera_distance = 25.0
        self.camera_angle_x = 35.0
        self.camera_angle_y = 45.0
        self.camera_target = [0, 0, 0]
        
        # Animation
        self.time = 0.0
        self.last_time = 0.0
        
        # Data
        self.trajectory = []
        self.current_position = [0, 0, 0]
        self.goal_position = [25, 15, 5]
        
        # Lighting
        self.lights = []
        self.setup_lights()
        
        # Effects
        self.explosions = []
        self.shockwaves = []
        
    def setup_lights(self):
        """Setup dynamic lighting system."""
        self.lights = [
            {'position': [10, 10, 10], 'color': CYBERPUNK_COLORS['neon_blue'], 'intensity': 1.5},
            {'position': [-10, 5, -10], 'color': CYBERPUNK_COLORS['neon_pink'], 'intensity': 1.2},
            {'position': [0, 20, 0], 'color': CYBERPUNK_COLORS['neon_green'], 'intensity': 1.0},
        ]
        
    def trigger_explosion(self, position: Tuple[float, float, float], color: Color):
        """Trigger dramatic explosion effect."""
        self.explosions.append({
            'position': np.array(position, dtype=np.float32),
            'color': color,
            'radius': 0.1,
            'max_radius': 3.0,
            'age': 0.0,
            'lifetime': 1.5
        })
        # Emit lots of particles
        self.particle_system.emit(position, color, count=100, lifetime=2.0)
        
    def trigger_shockwave(self, position: Tuple[float, float, float]):
        """Trigger shockwave effect."""
        self.shockwaves.append({
            'position': np.array(position, dtype=np.float32),
            'radius': 0.1,
            'max_radius': 10.0,
            'age': 0.0,
            'lifetime': 2.0
        })
        
    def initialize(self) -> bool:
        """Initialize pygame and OpenGL."""
        if not OPENGL_AVAILABLE:
            print("OpenGL not available. Falling back to basic visualization.")
            return False
            
        try:
            pygame.init()
            pygame.display.set_mode((self.width, self.height), pygame.DOUBLEBUF | pygame.OPENGL)
            pygame.display.set_caption("VILITUS ENGINE v3.0 - Futuristic Visualization")
            
            # OpenGL setup
            glEnable(GL_DEPTH_TEST)
            glEnable(GL_BLEND)
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
            
            # Perspective
            glMatrixMode(GL_PROJECTION)
            gluPerspective(60, self.width / self.height, 0.1, 1000.0)
            glMatrixMode(GL_MODELVIEW)
            
            # Background color - MUCH BRIGHTER
            glClearColor(0.5, 0.55, 0.7, 1.0)
            
            self.running = True
            self.last_time = time.time()
            
            print("Futuristic visualization initialized successfully")
            return True
            
        except Exception as e:
            print(f"Failed to initialize futuristic visualization: {e}")
            return False
            
    def draw_grid(self, size: int = 50, spacing: float = 1.0):
        """Draw futuristic grid floor with glow effects."""
        glLineWidth(1)
        glBegin(GL_LINES)
        
        grid_color = CYBERPUNK_COLORS['grid_line'].to_tuple()
        glColor4f(*grid_color)
        
        for i in range(-size, size + 1):
            pos = i * spacing
            glVertex3f(pos, 0, -size * spacing)
            glVertex3f(pos, 0, size * spacing)
            glVertex3f(-size * spacing, 0, pos)
            glVertex3f(size * spacing, 0, pos)
            
        glEnd()
        
        # Glowing center line with pulse effect
        pulse = 0.5 + 0.5 * math.sin(self.time * 3.0)
        glLineWidth(3)
        glBegin(GL_LINES)
        glColor4f(CYBERPUNK_COLORS['neon_cyan'].r, CYBERPUNK_COLORS['neon_cyan'].g,
                 CYBERPUNK_COLORS['neon_cyan'].b, 0.8 * pulse)
        glVertex3f(0, 0, -size * spacing)
        glVertex3f(0, 0, size * spacing)
        glEnd()
        
        # Add glowing grid intersections
        glPointSize(3)
        glBegin(GL_POINTS)
        glColor4f(*CYBERPUNK_COLORS['neon_blue'].to_tuple())
        for i in range(-size, size + 1, 5):
            for j in range(-size, size + 1, 5):
                glVertex3f(i * spacing, 0, j * spacing)
        glEnd()
        
    def draw_terrain(self):
        """Draw 3D terrain with height variation."""
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        # Draw terrain as wireframe mesh
        grid_size = 40
        spacing = 1.0
        
        glLineWidth(1)
        glBegin(GL_LINES)
        
        for i in range(-grid_size, grid_size):
            for j in range(-grid_size, grid_size):
                x1, z1 = i * spacing, j * spacing
                x2, z2 = (i + 1) * spacing, j * spacing
                
                # Height variation using sine waves
                y1 = math.sin(x1 * 0.1 + self.time) * math.cos(z1 * 0.1) * 0.5
                y2 = math.sin(x2 * 0.1 + self.time) * math.cos(z2 * 0.1) * 0.5
                
                # Color based on height
                height_color = (y1 + 0.5) / 1.0  # Normalize to 0-1
                glColor4f(0.0, 0.5 + height_color * 0.5, 1.0 - height_color * 0.5, 0.3)
                
                glVertex3f(x1, y1 - 0.5, z1)
                glVertex3f(x2, y2 - 0.5, z2)
                
        glEnd()
        glDisable(GL_BLEND)
        
    def draw_robot(self, position: Tuple[float, float, float]):
        """Draw futuristic robot representation with enhanced effects."""
        x, y, z = position
        
        glPushMatrix()
        glTranslatef(x, y + 0.5, z)
        
        # Rotate robot based on time
        glRotatef(self.time * 50, 0, 1, 0)
        
        # Robot body - GLOWING cube with multiple layers
        # Inner core - brightest
        glColor4f(*CYBERPUNK_COLORS['neon_cyan'].to_tuple())
        glBegin(GL_QUADS)
        size = 0.25
        for normal, vertices in [
            ((0, 0, 1), [(-size, -size, size), (size, -size, size), (size, size, size), (-size, size, size)]),
            ((0, 0, -1), [(-size, -size, -size), (-size, size, -size), (size, size, -size), (size, -size, -size)]),
            ((0, 1, 0), [(-size, size, -size), (-size, size, size), (size, size, size), (size, size, -size)]),
            ((0, -1, 0), [(-size, -size, -size), (size, -size, -size), (size, -size, size), (-size, -size, size)]),
            ((1, 0, 0), [(size, -size, -size), (size, size, -size), (size, size, size), (size, -size, size)]),
            ((-1, 0, 0), [(-size, -size, -size), (-size, -size, size), (-size, size, size), (-size, size, -size)]),
        ]:
            glVertex3f(*vertices[0])
            glVertex3f(*vertices[1])
            glVertex3f(*vertices[2])
            glVertex3f(*vertices[3])
        glEnd()
        
        # Outer glow layer
        glColor4f(CYBERPUNK_COLORS['neon_blue'].r, CYBERPUNK_COLORS['neon_blue'].g,
                 CYBERPUNK_COLORS['neon_blue'].b, 0.4)
        glBegin(GL_QUADS)
        glow_size = size * 1.5
        for normal, vertices in [
            ((0, 0, 1), [(-glow_size, -glow_size, glow_size), (glow_size, -glow_size, glow_size), 
                        (glow_size, glow_size, glow_size), (-glow_size, glow_size, glow_size)]),
            ((0, 0, -1), [(-glow_size, -glow_size, -glow_size), (-glow_size, glow_size, -glow_size), 
                         (glow_size, glow_size, -glow_size), (glow_size, -glow_size, -glow_size)]),
        ]:
            glVertex3f(*vertices[0])
            glVertex3f(*vertices[1])
            glVertex3f(*vertices[2])
            glVertex3f(*vertices[3])
        glEnd()
        
        # Energy rings around robot
        ring_count = 3
        for i in range(ring_count):
            ring_radius = 0.4 + i * 0.15
            ring_speed = (i + 1) * 2.0
            glPushMatrix()
            glRotatef(self.time * ring_speed * 30, 0, 1, 0)
            glColor4f(CYBERPUNK_COLORS['neon_orange'].r, CYBERPUNK_COLORS['neon_orange'].g,
                     CYBERPUNK_COLORS['neon_orange'].b, 0.6 - i * 0.15)
            glBegin(GL_LINE_LOOP)
            for angle in range(0, 360, 10):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * ring_radius, math.sin(rad) * ring_radius * 0.3, 
                          math.sin(rad) * ring_radius)
            glEnd()
            glPopMatrix()
        
        glPopMatrix()
        
        # Emit continuous particles
        self.particle_system.emit(position, CYBERPUNK_COLORS['neon_cyan'], count=5, lifetime=1.0)
        
        # Trigger occasional explosion for dramatic effect
        if len(self.trajectory) % 50 == 0 and len(self.trajectory) > 0:
            self.trigger_explosion(position, CYBERPUNK_COLORS['neon_pink'])
        
    def draw_goal(self, position: Tuple[float, float, float]):
        """Draw dramatic glowing goal marker with multiple effects."""
        x, y, z = position
        
        glPushMatrix()
        glTranslatef(x, y + 1.0, z)
        
        # Rotating goal marker
        glRotatef(self.time * 80, 0, 1, 0)
        glRotatef(self.time * 40, 1, 0, 0)
        
        # Pulsing effect
        pulse = 1.0 + 0.3 * math.sin(self.time * 4.0)
        
        # Multiple layered diamond shapes
        for layer in range(3):
            layer_size = 0.6 * pulse * (1.0 - layer * 0.2)
            layer_color = CYBERPUNK_COLORS['neon_pink'] if layer == 0 else CYBERPUNK_COLORS['neon_red']
            
            glColor4f(*layer_color.to_tuple())
            glBegin(GL_TRIANGLES)
            size = layer_size
            # Top pyramid
            for i in range(4):
                angle1 = math.radians(i * 90)
                angle2 = math.radians((i + 1) * 90)
                glVertex3f(0, size, 0)
                glVertex3f(math.cos(angle1) * size, 0, math.sin(angle1) * size)
                glVertex3f(math.cos(angle2) * size, 0, math.sin(angle2) * size)
            # Bottom pyramid
            for i in range(4):
                angle1 = math.radians(i * 90)
                angle2 = math.radians((i + 1) * 90)
                glVertex3f(0, -size, 0)
                glVertex3f(math.cos(angle2) * size, 0, math.sin(angle2) * size)
                glVertex3f(math.cos(angle1) * size, 0, math.sin(angle1) * size)
            glEnd()
        
        # Rotating energy rings
        for i in range(2):
            glPushMatrix()
            glRotatef(self.time * (60 if i == 0 else -80), 0, 1, 0)
            glColor4f(CYBERPUNK_COLORS['neon_yellow'].r, CYBERPUNK_COLORS['neon_yellow'].g,
                     CYBERPUNK_COLORS['neon_yellow'].b, 0.8)
            glBegin(GL_LINE_LOOP)
            ring_radius = 0.8 + i * 0.2
            for angle in range(0, 360, 15):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * ring_radius, math.sin(rad) * ring_radius * 0.3, 
                          math.sin(rad) * ring_radius)
            glEnd()
            glPopMatrix()
        
        glPopMatrix()
        
        # Emit particles from goal
        self.particle_system.emit(position, CYBERPUNK_COLORS['neon_yellow'], count=3, lifetime=1.5)
        
    def draw_explosions(self):
        """Render explosion effects."""
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE)  # Additive blending for explosions
        
        for exp in self.explosions:
            progress = exp['age'] / exp['lifetime']
            alpha = 1.0 - progress
            
            glPushMatrix()
            glTranslatef(*exp['position'])
            
            # Core explosion
            glColor4f(exp['color'].r, exp['color'].g, exp['color'].b, alpha)
            glBegin(GL_TRIANGLE_FAN)
            for angle in range(0, 361, 30):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * exp['radius'], math.sin(rad) * exp['radius'], 0)
            glEnd()
            
            # Outer glow
            glColor4f(exp['color'].r, exp['color'].g, exp['color'].b, alpha * 0.5)
            glBegin(GL_TRIANGLE_FAN)
            for angle in range(0, 361, 30):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * exp['radius'] * 1.5, math.sin(rad) * exp['radius'] * 1.5, 0)
            glEnd()
            
            glPopMatrix()
            
        glDisable(GL_BLEND)
        
    def draw_shockwaves(self):
        """Render shockwave effects."""
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        
        for wave in self.shockwaves:
            progress = wave['age'] / wave['lifetime']
            alpha = 1.0 - progress
            
            glPushMatrix()
            glTranslatef(*wave['position'])
            
            glLineWidth(3)
            glColor4f(CYBERPUNK_COLORS['neon_cyan'].r, CYBERPUNK_COLORS['neon_cyan'].g,
                     CYBERPUNK_COLORS['neon_cyan'].b, alpha * 0.8)
            
            glBegin(GL_LINE_LOOP)
            for angle in range(0, 360, 10):
                rad = math.radians(angle)
                glVertex3f(math.cos(rad) * wave['radius'], 0, math.sin(rad) * wave['radius'])
            glEnd()
            
            glPopMatrix()
            
        glDisable(GL_BLEND)
        
    def draw_trajectory(self):
        """Draw glowing trajectory line."""
        if len(self.trajectory) < 2:
            return
            
        glLineWidth(3)
        glBegin(GL_LINE_STRIP)
        
        for i, pos in enumerate(self.trajectory):
            # Gradient color along trajectory
            t = i / len(self.trajectory)
            color = CYBERPUNK_COLORS['neon_green']
            glColor4f(color.r, color.g, color.b, 0.3 + t * 0.7)
            glVertex3f(*pos)
            
        glEnd()
        
        # Glow effect
        glLineWidth(6)
        glBegin(GL_LINE_STRIP)
        for pos in self.trajectory:
            glColor4f(CYBERPUNK_COLORS['neon_green'].r, CYBERPUNK_COLORS['neon_green'].g,
                     CYBERPUNK_COLORS['neon_green'].b, 0.1)
            glVertex3f(*pos)
        glEnd()
        
    def setup_camera(self):
        """Setup camera position."""
        glLoadIdentity()
        
        # Calculate camera position from spherical coordinates
        rad_x = math.radians(self.camera_angle_x)
        rad_y = math.radians(self.camera_angle_y)
        
        cam_x = self.camera_distance * math.cos(rad_x) * math.sin(rad_y)
        cam_y = self.camera_distance * math.sin(rad_x)
        cam_z = self.camera_distance * math.cos(rad_x) * math.cos(rad_y)
        
        # Look at robot position
        gluLookAt(cam_x, cam_y, cam_z,  # Camera position
                 self.current_position[0], self.current_position[1], self.current_position[2],  # Look at
                 0, 1, 0)  # Up vector
                 
    def render_3d(self):
        """Render 3D scene with all effects."""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        
        self.setup_camera()
        
        # Draw terrain first (background)
        self.draw_terrain()
        
        # Draw grid
        self.draw_grid()
        
        # Draw trajectory
        self.draw_trajectory()
        
        # Draw robot
        self.draw_robot(tuple(self.current_position))
        
        # Draw goal
        self.draw_goal(tuple(self.goal_position))
        
        # Render explosions
        self.draw_explosions()
        
        # Render shockwaves
        self.draw_shockwaves()
        
        # Render particles
        self.particle_system.render()
        
    def render_hud(self):
        """Render 2D HUD overlay."""
        # Switch to 2D rendering
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.width, self.height, 0, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        glDisable(GL_DEPTH_TEST)
        
        # Create pygame surface for HUD
        hud_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        
        # Build context data
        context = {
            'mission_id': 'exploration_mission_002',
            'progress': len(self.trajectory) / 200.0 if self.trajectory else 0.0,
            'step': len(self.trajectory),
            'fps': 1.0 / (time.time() - self.last_time + 0.001),
            'position': self.current_position,
            'goal': self.goal_position,
            'distance_to_goal': math.sqrt(
                (self.current_position[0] - self.goal_position[0])**2 +
                (self.current_position[1] - self.goal_position[1])**2 +
                (self.current_position[2] - self.goal_position[2])**2
            ),
            'nearest_obstacle': 5.0  # Placeholder
        }
        
        # Render HUD
        self.hud.render(hud_surface, context)
        
        # Convert pygame surface to OpenGL texture
        hud_data = pygame.image.tostring(hud_surface, 'RGBA', True)
        glDrawPixels(self.width, self.height, GL_RGBA, GL_UNSIGNED_BYTE, hud_data)
        
        # Restore 3D rendering
        glEnable(GL_DEPTH_TEST)
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        glPopMatrix()
        
    def update(self, dt: float):
        """Update animation state."""
        self.time += dt
        self.particle_system.update(dt)
        
        # Update explosions
        alive_explosions = []
        for exp in self.explosions:
            exp['age'] += dt
            if exp['age'] < exp['lifetime']:
                exp['radius'] = exp['max_radius'] * (exp['age'] / exp['lifetime'])
                alive_explosions.append(exp)
        self.explosions = alive_explosions
        
        # Update shockwaves
        alive_shockwaves = []
        for wave in self.shockwaves:
            wave['age'] += dt
            if wave['age'] < wave['lifetime']:
                wave['radius'] = wave['max_radius'] * (wave['age'] / wave['lifetime'])
                alive_shockwaves.append(wave)
        self.shockwaves = alive_shockwaves
        
        # Dynamic camera movement
        self.camera_angle_y += dt * 5.0  # Slow rotation
        self.camera_angle_x = 35.0 + math.sin(self.time * 0.5) * 10.0  # Bobbing
        
    def update_position(self, position: Tuple[float, float, float]):
        """Update robot position."""
        self.current_position = list(position)
        self.trajectory.append(position)
        
        # Keep trajectory manageable
        if len(self.trajectory) > 500:
            self.trajectory.pop(0)
            
    def update_goal(self, goal: Tuple[float, float, float]):
        """Update goal position."""
        self.goal_position = list(goal)
        
    def run_frame(self) -> bool:
        """Render single frame."""
        if not self.running:
            return False
            
        current_time = time.time()
        dt = current_time - self.last_time
        self.last_time = current_time
        
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                    return False
                    
        # Update
        self.update(dt)
        
        # Render
        self.render_3d()
        self.render_hud()
        
        pygame.display.flip()
        
        return True
        
    def shutdown(self):
        """Cleanup resources."""
        self.running = False
        pygame.quit()


def demo():
    """Run futuristic visualization demo."""
    viz = FuturisticVisualizer(1280, 720)
    
    if not viz.initialize():
        print("Failed to initialize visualization")
        return
        
    print("Starting futuristic visualization demo...")
    print("Press ESC to exit")
    
    # Simulate movement
    t = 0
    while viz.run_frame():
        t += 0.01
        
        # Simulate robot movement in spiral pattern
        x = 10 * math.cos(t)
        z = 10 * math.sin(t)
        y = 2 + math.sin(t * 2) * 0.5
        
        viz.update_position((x, y, z))
        
        # Small delay to control frame rate
        time.sleep(0.01)
        
    viz.shutdown()
    print("Visualization ended")


if __name__ == "__main__":
    demo()
