"""
===============================================================================
VILITUS ENGINE v3.0 -- COMPLETE PRODUCTION CODEBASE
===============================================================================
Single-file deployment of the entire hybrid quantum-classical robotics
optimization platform.

Author: Vilitus Engineering Team
Version: 3.0.0
Date: 2026-07-09
License: MIT
===============================================================================
"""

import os
import sys
import time
import asyncio
import logging
import hashlib
import json
import math
import random
import signal
import uuid
import warnings
import copy
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable, Tuple, Union, Set
from enum import Enum, auto
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from collections import OrderedDict
import threading

# Third-party imports with graceful degradation
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None

try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    plt = None

try:
    from futuristic_visualizer import FuturisticVisualizer
    FUTURISTIC_VIZ_AVAILABLE = True
except ImportError:
    FUTURISTIC_VIZ_AVAILABLE = False

# Quantum backends (optional)
QISKIT_AVAILABLE = False
DWAVE_AVAILABLE = False
ORTOOLS_AVAILABLE = False
SCIP_AVAILABLE = False
GUROBI_AVAILABLE = False

try:
    from ortools.sat.python import cp_model
    ORTOOLS_AVAILABLE = True
except ImportError:
    pass

try:
    import pyscipopt
    SCIP_AVAILABLE = True
except ImportError:
    pass

try:
    import gurobipy
    GUROBI_AVAILABLE = True
except ImportError:
    pass

try:
    from qiskit_aer import AerSimulator
    QISKIT_AVAILABLE = True
except ImportError:
    pass

try:
    from dwave.system import DWaveSampler, EmbeddingComposite
    DWAVE_AVAILABLE = True
except ImportError:
    pass

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="[%(name)s] %(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("VilitusEngine")


# ============================================================================
# PART 1: MISSION SCHEMA & MANAGEMENT
# ============================================================================

class MissionPriority(Enum):
    CRITICAL = 0
    HIGH = 1
    MEDIUM = 2
    LOW = 3


@dataclass(frozen=True)
class Mission:
    """Immutable mission specification."""
    mission_id: str
    objective: str
    goal_state: Dict[str, Any]
    constraints: Tuple[Dict[str, Any], ...]
    priority: MissionPriority
    rules: Tuple[str, ...] = ()
    timeout_seconds: Optional[float] = None
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def is_valid(self) -> bool:
        return bool(self.mission_id and self.objective)

    def get_metadata(self) -> Dict[str, Any]:
        return dict(self.metadata)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Mission":
        return cls(
            mission_id=data["mission_id"],
            objective=data["objective"],
            goal_state=data["goal_state"],
            constraints=tuple(data.get("constraints", [])),
            priority=MissionPriority[data.get("priority", "MEDIUM")],
            rules=tuple(data.get("rules", [])),
            timeout_seconds=data.get("timeout_seconds"),
            metadata=tuple(data.get("metadata", {}).items())
        )


@dataclass
class OperationalContext:
    """Runtime operational context for the cognitive engine."""
    mission: Optional[Mission] = None
    current_state: Dict[str, Any] = field(default_factory=dict)
    desired_state: Dict[str, Any] = field(default_factory=dict)
    threats: List[Dict[str, Any]] = field(default_factory=list)
    opportunities: List[Dict[str, Any]] = field(default_factory=list)
    risk: float = 0.0
    uncertainty: float = 0.0
    timestamp: float = 0.0


class ObjectiveTracker:
    """Tracks progress toward mission goal state."""

    def __init__(self):
        self.goal_state: Optional[Dict[str, Any]] = None
        self.progress = 0.0
        self.progress_history: List[float] = []

    def reset(self, goal_state: Dict[str, Any]):
        self.goal_state = goal_state
        self.progress = 0.0
        self.progress_history = []

    def update(self, world_state: Dict[str, Any]):
        if self.goal_state is None:
            return
        if "position" in world_state and "position" in self.goal_state:
            current = world_state["position"]
            goal = self.goal_state["position"]
            if isinstance(current, (list, tuple)) and isinstance(goal, (list, tuple)):
                if len(current) >= 2 and len(goal) >= 2:
                    dist = ((current[0] - goal[0]) ** 2 + (current[1] - goal[1]) ** 2) ** 0.5
                    self.progress = max(0.0, min(1.0, 1.0 - dist / 50.0))
        self.progress_history.append(self.progress)

    def is_complete(self) -> bool:
        return self.progress >= 0.95


class ConstraintEngine:
    """Validates world state against mission constraints."""

    def __init__(self):
        self.constraints: Tuple[Dict[str, Any], ...] = ()

    def load_constraints(self, constraints: Tuple[Dict[str, Any], ...]):
        self.constraints = constraints

    def check_violations(self, world_state: Dict[str, Any]) -> List[str]:
        violations = []
        for c in self.constraints:
            ctype = c.get("type")
            if ctype == "stay_in_bounds":
                pos = world_state.get("position", [0, 0])
                area = c.get("area", [[0, 0], [100, 100]])
                if len(area) >= 2 and len(pos) >= 2:
                    if not (area[0][0] <= pos[0] <= area[1][0] and area[0][1] <= pos[1] <= area[1][1]):
                        violations.append(f"Out of bounds: {pos}")
            elif ctype == "max_velocity":
                vel = world_state.get("velocity", [0, 0, 0])
                speed = sum(v ** 2 for v in vel) ** 0.5
                if speed > c.get("limit", 5.0):
                    violations.append(f"Velocity exceeded: {speed:.2f}")
            elif ctype == "min_obstacle_distance":
                dist = world_state.get("nearest_obstacle", float('inf'))
                if dist < c.get("distance", 0.5):
                    violations.append(f"Too close to obstacle: {dist:.2f}m")
        return violations


class MissionManager:
    """Manages mission lifecycle: load, track, validate, complete/abort."""

    def __init__(self):
        self.active_mission: Optional[Mission] = None
        self.tracker = ObjectiveTracker()
        self.constraint_engine = ConstraintEngine()
        self.history: List[Tuple[str, str]] = []
        self.violations: List[str] = []

    def load_mission(self, mission: Mission):
        if self.active_mission:
            self.abort_current()
        self.active_mission = mission
        self.tracker.reset(mission.goal_state)
        self.constraint_engine.load_constraints(mission.constraints)
        self.history.append(("loaded", mission.mission_id))
        logger.info(f"Mission loaded: {mission.mission_id} (priority: {mission.priority.name})")

    def update(self, world_state: Dict[str, Any]):
        if not self.active_mission:
            return
        self.tracker.update(world_state)
        self.violations = self.constraint_engine.check_violations(world_state)
        if self.violations:
            logger.warning(f"Constraint violations: {self.violations}")

    def is_complete(self) -> bool:
        return self.tracker.is_complete()

    def abort_current(self):
        if self.active_mission:
            self.history.append(("aborted", self.active_mission.mission_id))
            logger.info(f"Mission aborted: {self.active_mission.mission_id}")
            self.active_mission = None

    def get_progress(self) -> float:
        return self.tracker.progress


# ============================================================================
# PART 2: COGNITIVE ENGINE
# ============================================================================

class PerceptionFusion:
    """Fuses multi-modal sensor data into unified scene representation."""

    def __init__(self, device: str = "cpu"):
        self.device = device

    def fuse(self, context: OperationalContext) -> Dict[str, Any]:
        return {
            "position": context.current_state.get("position", [0.0, 0.0, 0.0]),
            "velocity": context.current_state.get("velocity", [0.0, 0.0, 0.0]),
            "obstacles": context.current_state.get("obstacles", []),
            "threats": context.threats,
            "opportunities": context.opportunities,
            "risk": context.risk,
            "uncertainty": context.uncertainty
        }


class WorldUnderstanding:
    """Builds and maintains world model with short-term memory."""

    def __init__(self, device: str = "cpu", memory_size: int = 100):
        self.device = device
        self.memory_size = memory_size
        self.memory: List[Dict[str, Any]] = []

    def update(self, fused: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        self.memory.append(fused)
        if len(self.memory) > self.memory_size:
            self.memory.pop(0)

        predictions = {"obstacle_motion": [0.0, 0.0]}
        if len(self.memory) >= 2:
            last = self.memory[-1]
            prev = self.memory[-2]
            if "position" in last and "position" in prev:
                predictions["obstacle_motion"] = [
                    last["position"][i] - prev["position"][i] 
                    for i in range(min(2, len(last["position"]), len(prev["position"])))
                ]

        return {"scene": fused, "predictions": predictions, "memory_length": len(self.memory)}


class Planner:
    """Generates motion plans from world model to desired state."""

    def __init__(self, device: str = "cpu"):
        self.device = device

    def generate(self, world_model: Dict[str, Any], desired_state: Dict[str, Any]) -> Dict[str, Any]:
        current_pos = world_model.get("scene", {}).get("position", [0.0, 0.0, 0.0])
        goal_pos = desired_state.get("position", [0.0, 0.0, 0.0])

        dx = goal_pos[0] - current_pos[0] if len(goal_pos) > 0 and len(current_pos) > 0 else 0.0
        dy = goal_pos[1] - current_pos[1] if len(goal_pos) > 1 and len(current_pos) > 1 else 0.0

        dist = (dx ** 2 + dy ** 2) ** 0.5
        if dist > 0.1:
            vx = (dx / dist) * 1.5
            vy = (dy / dist) * 1.5
        else:
            vx, vy = 0.0, 0.0

        heading = math.atan2(dy, dx) if dist > 0.1 else 0.0

        return {
            "velocity": [vx, vy, 0.0],
            "heading": heading,
            "accel_limit": 2.0,
            "plan_type": "direct_to_goal"
        }


class Optimizer:
    """Optimizes plans using quantum-classical hybrid optimization."""

    def __init__(self, device: str = "cpu"):
        self.device = device

    def optimize(self, plan: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        optimized = copy.deepcopy(plan)
        if context.risk > 0.5:
            optimized["accel_limit"] = max(0.5, optimized.get("accel_limit", 2.0) * 0.5)
            v = optimized.get("velocity", [0, 0, 0])
            optimized["velocity"] = [vi * 0.7 for vi in v]
        return optimized


class ReasoningEngine:
    """Evaluates plans against rules and mission objectives."""

    def __init__(self, device: str = "cpu"):
        self.device = device

    def evaluate(self, plan: Dict[str, Any], context: OperationalContext) -> Dict[str, Any]:
        evaluated = copy.deepcopy(plan)
        mission = context.mission
        if mission:
            for rule in mission.rules:
                if rule == "minimize_energy":
                    v = evaluated.get("velocity", [0, 0, 0])
                    speed = sum(vi ** 2 for vi in v) ** 0.5
                    if speed > 1.0:
                        evaluated["velocity"] = [vi * 0.8 for vi in v]
                elif rule == "maximize_safety":
                    evaluated["accel_limit"] = min(evaluated.get("accel_limit", 2.0), 1.0)
        return evaluated


class CognitiveEngine:
    """
    5-stage cognitive pipeline:
    Perception Fusion -> World Understanding -> Planner -> Optimizer -> Reasoning Engine
    """

    def __init__(self, device: Optional[str] = None):
        self.device = device or ("cuda" if TORCH_AVAILABLE and torch.cuda.is_available() else "cpu")
        self.perception = PerceptionFusion(self.device)
        self.understanding = WorldUnderstanding(self.device)
        self.planner = Planner(self.device)
        self.optimizer = Optimizer(self.device)
        self.reasoner = ReasoningEngine(self.device)

    def generate_intent(self, context: OperationalContext) -> Any:
        """Generate action intent from operational context."""
        fused = self.perception.fuse(context)
        world_model = self.understanding.update(fused, context)
        plan = self.planner.generate(world_model, context.desired_state)
        optimized = self.optimizer.optimize(plan, context)
        decision = self.reasoner.evaluate(optimized, context)
        return self._to_action_tensor(decision)

    def _to_action_tensor(self, decision: Dict[str, Any]) -> Any:
        """Convert decision to 48x6 action tensor."""
        if TORCH_AVAILABLE:
            tensor = torch.zeros((48, 6), dtype=torch.float32, device=self.device)
            vel = decision.get("velocity", [0.0, 0.0, 0.0])
            tensor[:, 0] = vel[0]
            tensor[:, 1] = vel[1]
            tensor[:, 2] = vel[2]
            tensor[:, 3] = decision.get("heading", 0.0)
            tensor[:, 4] = decision.get("accel_limit", 2.0)
            tensor[:, 5] = 0
            return tensor
        else:
            return {
                "velocity": decision.get("velocity", [0.0, 0.0, 0.0]),
                "heading": decision.get("heading", 0.0),
                "accel_limit": decision.get("accel_limit", 2.0),
                "behavior": 0
            }


# ============================================================================
# PART 3: INTENT, SAFETY & CONTROL
# ============================================================================

def create_action_tensor(vel_cmd: List[float], heading: float = 0.0,
                       accel_limit: float = 2.0, behavior: int = 0) -> Any:
    """Create a 48x6 action tensor for robot control."""
    if TORCH_AVAILABLE:
        tensor = torch.zeros((48, 6), dtype=torch.float32)
        tensor[:, 0] = vel_cmd[0] if len(vel_cmd) > 0 else 0.0
        tensor[:, 1] = vel_cmd[1] if len(vel_cmd) > 1 else 0.0
        tensor[:, 2] = vel_cmd[2] if len(vel_cmd) > 2 else 0.0
        tensor[:, 3] = heading
        tensor[:, 4] = accel_limit
        tensor[:, 5] = behavior
        return tensor
    else:
        return {
            "velocity": vel_cmd,
            "heading": heading,
            "accel_limit": accel_limit,
            "behavior": behavior
        }


class SafetyArbitrator:
    """Enforces safety limits on action tensors."""

    def __init__(self, max_vel: float = 5.0, min_obstacle_dist: float = 0.5):
        self.max_vel = max_vel
        self.min_obstacle_dist = min_obstacle_dist

    def validate(self, action_tensor: Any, world_state: Dict[str, Any]) -> Any:
        if TORCH_AVAILABLE and isinstance(action_tensor, torch.Tensor):
            safe = action_tensor.clone()
            safe[:, :3] = torch.clamp(safe[:, :3], -self.max_vel, self.max_vel)
            nearest = world_state.get("nearest_obstacle", 100.0)
            if nearest < self.min_obstacle_dist:
                safe[:, :3] *= 0.2
            return safe
        else:
            safe = copy.deepcopy(action_tensor)
            if isinstance(safe, dict) and "velocity" in safe:
                safe["velocity"] = [
                    max(-self.max_vel, min(self.max_vel, v))
                    for v in safe["velocity"]
                ]
                nearest = world_state.get("nearest_obstacle", 100.0)
                if nearest < self.min_obstacle_dist:
                    safe["velocity"] = [v * 0.2 for v in safe["velocity"]]
            return safe


class IsaacController:
    """Bridge between VILITUS intent and Isaac Sim robot control."""

    def __init__(self, robot: Any = None, world: Any = None):
        self.robot = robot
        self.world = world
        self.arbitrator = SafetyArbitrator()

    def apply_intent(self, action_tensor: Any, world_state: Dict[str, Any]):
        safe_tensor = self.arbitrator.validate(action_tensor, world_state)

        if self.robot is None:
            logger.debug("No robot connected -- intent validated but not applied")
            return safe_tensor

        if TORCH_AVAILABLE and isinstance(safe_tensor, torch.Tensor):
            cmd = safe_tensor[0]
            vel_x = cmd[0].item()
            vel_y = cmd[1].item()
            heading = cmd[3].item()
        elif isinstance(safe_tensor, dict):
            vel = safe_tensor.get("velocity", [0, 0, 0])
            vel_x = vel[0] if len(vel) > 0 else 0.0
            vel_y = vel[1] if len(vel) > 1 else 0.0
            heading = safe_tensor.get("heading", 0.0)
        else:
            vel_x, vel_y, heading = 0.0, 0.0, 0.0

        try:
            if hasattr(self.robot, 'apply_velocity_command'):
                self.robot.apply_velocity_command([vel_x, vel_y, heading])
            elif hasattr(self.robot, 'set_linear_velocity'):
                self.robot.set_linear_velocity([vel_x, vel_y, 0.0])
                if hasattr(self.robot, 'set_angular_velocity'):
                    self.robot.set_angular_velocity([0.0, 0.0, heading])
        except Exception as e:
            logger.warning(f"Failed to apply robot command: {e}")

        return safe_tensor


# ============================================================================
# PART 4: QUANTUM ROUTER (Refactored v3.0)
# ============================================================================

class ExecutionTier(Enum):
    CLASSICAL = auto()
    LOCAL_SIM = auto()
    CLOUD_SIM = auto()
    QUANTUM_INSPIRED = auto()
    QPU_GATE = auto()
    QPU_ANNEAL = auto()


class QUBOComplexity(Enum):
    TRIVIAL = "trivial"
    SMALL = "small"
    MEDIUM = "medium"
    LARGE_SPARSE = "large_sparse"
    LARGE_DENSE = "large_dense"


@dataclass(frozen=True)
class RouterConfig:
    ibm_token: Optional[str] = None
    ibm_instance: str = "ibm-q/open/main"
    ibm_channel: str = "ibm_cloud"
    ibm_backend_preference: Tuple[str, ...] = ("ibm_heron", "ibm_nighthawk")
    dwave_token: Optional[str] = None
    dwave_solver: str = "Advantage2_prototype1.1"
    dwave_region: str = "na-west-1"
    classical_solver: str = "or-tools"
    classical_timeout_sec: float = 30.0
    max_qpu_cost_usd: float = 500.0
    max_qpu_minutes_per_month: float = 60.0
    enable_budget_tracking: bool = True
    default_timeout_sec: float = 300.0
    qpu_queue_timeout_sec: float = 60.0
    enable_result_verification: bool = True
    enable_warm_start: bool = True
    executor_pool_size: int = 4
    ros_decoupled: bool = True
    trivial_threshold: int = 50
    small_threshold: int = 200
    medium_threshold: int = 1000
    sparse_density_threshold: float = 0.05
    cache_max_size: int = 1000
    verification_tolerance_classical: float = 1e-6
    verification_tolerance_quantum: float = 1e-2
    max_retries: int = 3
    retry_base_delay_sec: float = 1.0
    retry_max_delay_sec: float = 60.0
    metrics_port: Optional[int] = None


class ValidationError(ValueError):
    pass


def _validate_qubo_payload(payload: "QUBOPayload") -> None:
    if payload.num_variables < 0:
        raise ValidationError(f"num_variables must be >= 0, got {payload.num_variables}")
    if payload.num_variables == 0 and (payload.q_matrix or payload.linear_terms):
        raise ValidationError("num_variables is 0 but matrix/terms are non-empty")
    max_idx = payload.num_variables - 1
    for (i, j) in payload.q_matrix.keys():
        if not (0 <= i <= max_idx and 0 <= j <= max_idx):
            raise ValidationError(f"QUBO index ({i},{j}) out of bounds [0, {max_idx}]")
        if i > j:
            raise ValidationError(f"QUBO index ({i},{j}) not normalized (i > j)")
    for i in payload.linear_terms.keys():
        if not (0 <= i <= max_idx):
            raise ValidationError(f"Linear index {i} out of bounds [0, {max_idx}]")


@dataclass(frozen=True)
class QUBOPayload:
    q_matrix: Dict[Tuple[int, int], float]
    linear_terms: Dict[int, float]
    num_variables: int
    constraints: Tuple[Dict[str, Any], ...] = ()
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def __post_init__(self):
        object.__setattr__(self, '_metadata_dict', dict(self.metadata))

    @property
    def density(self) -> float:
        if self.num_variables == 0:
            return 0.0
        max_entries = self.num_variables * (self.num_variables + 1) // 2
        actual = len(self.q_matrix) + len(self.linear_terms)
        return actual / max_entries if max_entries > 0 else 0.0

    def complexity_class(self, config: RouterConfig) -> QUBOComplexity:
        n = self.num_variables
        d = self.density
        if n < config.trivial_threshold:
            return QUBOComplexity.TRIVIAL
        elif n < config.small_threshold:
            return QUBOComplexity.SMALL
        elif n < config.medium_threshold:
            return QUBOComplexity.MEDIUM
        elif d < config.sparse_density_threshold:
            return QUBOComplexity.LARGE_SPARSE
        else:
            return QUBOComplexity.LARGE_DENSE

    def fingerprint(self) -> str:
        data = json.dumps({
            "n": self.num_variables,
            "q": sorted(self.q_matrix.items()),
            "l": sorted(self.linear_terms.items()),
            "c": self.constraints
        }, sort_keys=True)
        return hashlib.sha256(data.encode()).hexdigest()[:16]

    def get_metadata(self) -> Dict[str, Any]:
        return getattr(self, '_metadata_dict', {})

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QUBOPayload":
        n = data["num_variables"]
        raw_q = data.get("q_matrix", {})
        raw_l = data.get("linear_terms", {})
        q_matrix = {}
        linear_terms = dict(raw_l)
        for (i, j), coeff in raw_q.items():
            if i == j:
                linear_terms[i] = linear_terms.get(i, 0.0) + coeff
            elif i < j:
                q_matrix[(i, j)] = q_matrix.get((i, j), 0.0) + coeff
            else:
                q_matrix[(j, i)] = q_matrix.get((j, i), 0.0) + coeff
        return cls(
            q_matrix=q_matrix, linear_terms=linear_terms, num_variables=n,
            constraints=tuple(data.get("constraints", [])),
            metadata=tuple(data.get("metadata", {}).items())
        )


@dataclass(frozen=True)
class ExecutionResult:
    status: str
    backend: str
    tier: ExecutionTier
    solution: Tuple[Tuple[int, int], ...]
    energy: Optional[float] = None
    execution_time_sec: float = 0.0
    cost_usd: float = 0.0
    queue_time_sec: float = 0.0
    verified: bool = False
    warm_start_used: bool = False
    metadata: Tuple[Tuple[str, Any], ...] = ()

    def get_solution(self) -> Dict[int, int]:
        return dict(self.solution)

    def get_metadata(self) -> Dict[str, Any]:
        return dict(self.metadata)

    def with_metadata(self, **kwargs) -> "ExecutionResult":
        new_meta = dict(self.metadata)
        new_meta.update(kwargs)
        return ExecutionResult(
            status=self.status, backend=self.backend, tier=self.tier,
            solution=self.solution, energy=self.energy,
            execution_time_sec=self.execution_time_sec, cost_usd=self.cost_usd,
            queue_time_sec=self.queue_time_sec, verified=self.verified,
            warm_start_used=self.warm_start_used, metadata=tuple(new_meta.items())
        )


class BudgetTracker:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance.reset()
        return cls._instance

    def reset(self):
        self.qpu_minutes_used = 0.0
        self.total_cost_usd = 0.0
        self.job_history: List[Dict[str, Any]] = []
        self._monthly_start = time.time()

    def can_afford(self, estimated_cost: float, estimated_minutes: float,
                   config: RouterConfig) -> bool:
        if not config.enable_budget_tracking:
            return True
        with self._lock:
            if self.total_cost_usd + estimated_cost > config.max_qpu_cost_usd:
                logger.warning(f"Budget exceeded: ${self.total_cost_usd:.2f} + ${estimated_cost:.2f}")
                return False
            if self.qpu_minutes_used + estimated_minutes > config.max_qpu_minutes_per_month:
                logger.warning(f"QPU minutes exceeded: {self.qpu_minutes_used:.1f} + {estimated_minutes:.1f}")
                return False
            return True

    def record(self, cost: float, minutes: float, backend: str, status: str):
        with self._lock:
            self.total_cost_usd += cost
            self.qpu_minutes_used += minutes
            self.job_history.append({
                "timestamp": time.time(), "backend": backend,
                "cost_usd": cost, "minutes": minutes, "status": status
            })


class TimeoutException(Exception):
    pass


def _set_timeout(timeout_sec: float):
    def handler(signum, frame):
        raise TimeoutException(f"Solver timed out after {timeout_sec}s")
    if hasattr(signal, "SIGALRM"):
        old_handler = signal.signal(signal.SIGALRM, handler)
        signal.alarm(int(math.ceil(timeout_sec)))
        return old_handler
    return None


def _clear_timeout(old_handler):
    if old_handler is not None and hasattr(signal, "SIGALRM"):
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_handler)


class BackendInterface:
    def __init__(self, name: str, tier: ExecutionTier):
        self.name = name
        self.tier = tier
        self.available = False

    def initialize(self, config: RouterConfig) -> bool:
        raise NotImplementedError

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        raise NotImplementedError

    def estimate_cost(self, payload: QUBOPayload) -> Tuple[float, float]:
        return (0.0, 0.0)


class ClassicalBackend(BackendInterface):
    def __init__(self):
        super().__init__("classical_or-tools", ExecutionTier.CLASSICAL)
        self.solver = None
        self._solver_type = "or-tools"

    def initialize(self, config: RouterConfig) -> bool:
        if config.classical_solver == "or-tools" and ORTOOLS_AVAILABLE:
            self.solver = cp_model
            self.name = "classical_or-tools"
            self._solver_type = "or-tools"
            self.available = True
            logger.info("Classical backend (OR-Tools) initialized.")
            return True
        if config.classical_solver in ("scip", "or-tools") and SCIP_AVAILABLE:
            self.solver = pyscipopt
            self.name = "classical_scip"
            self._solver_type = "scip"
            self.available = True
            logger.info("Classical backend (SCIP) initialized.")
            return True
        if config.classical_solver == "gurobi" and GUROBI_AVAILABLE:
            self.solver = gurobipy
            self.name = "classical_gurobi"
            self._solver_type = "gurobi"
            self.available = True
            logger.info("Classical backend (Gurobi) initialized.")
            return True
        logger.error("No classical solver available.")
        return False

    def solve(self, payload: QUBOPayload, timeout_sec: float,
              warm_start: Optional[Dict[int, int]] = None) -> ExecutionResult:
        start = time.time()
        if self._solver_type == "or-tools":
            return self._solve_ortools(payload, timeout_sec, warm_start, start)
        elif self._solver_type == "scip":
            return self._solve_scip(payload, timeout_sec, warm_start, start)
        elif self._solver_type == "gurobi":
            return self._solve_gurobi(payload, timeout_sec, warm_start, start)
        return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                               solution=(), execution_time_sec=time.time() - start,
                               cost_usd=0.0, metadata=(("error", "Unknown solver"),))

    def _solve_ortools(self, payload, timeout_sec, warm_start, start_time):
        model = cp_model.CpModel()
        x = {i: model.NewBoolVar(f"x_{i}") for i in range(payload.num_variables)}
        
        # Handle quadratic terms using auxiliary variables
        aux_vars = {}
        for (i, j), coeff in payload.q_matrix.items():
            if i == j:
                # Diagonal term: coeff * x[i]
                continue  # Will handle in linear terms
            aux_name = f"x_{i}_{j}"
            aux = model.NewBoolVar(aux_name)
            aux_vars[(i, j)] = aux
            # Constraint: aux = x[i] * x[j]
            # This is enforced by: aux <= x[i], aux <= x[j], aux >= x[i] + x[j] - 1
            model.Add(aux <= x[i])
            model.Add(aux <= x[j])
            model.Add(aux >= x[i] + x[j] - 1)
        
        # Build objective
        obj_terms = []
        # Quadratic terms
        for (i, j), coeff in payload.q_matrix.items():
            if i == j:
                # Diagonal term: coeff * x[i] (same as linear)
                obj_terms.append(x[i] * coeff)
            else:
                obj_terms.append(aux_vars[(i, j)] * coeff)
        # Linear terms
        for i, coeff in payload.linear_terms.items():
            obj_terms.append(x[i] * coeff)
        
        model.Minimize(sum(obj_terms))
        if warm_start:
            for i, val in warm_start.items():
                if i in x:
                    model.AddHint(x[i], val)
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = timeout_sec
        solver.parameters.num_search_workers = 4
        old_handler = _set_timeout(timeout_sec + 5.0)
        try:
            status = solver.Solve(model)
        except TimeoutException:
            return ExecutionResult(status="TIMEOUT", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start_time, cost_usd=0.0)
        finally:
            _clear_timeout(old_handler)
        elapsed = time.time() - start_time
        if status in [cp_model.OPTIMAL, cp_model.FEASIBLE]:
            solution = tuple((i, int(solver.Value(x[i]))) for i in x)
            return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                   solution=solution, energy=solver.ObjectiveValue(),
                                   execution_time_sec=elapsed, cost_usd=0.0,
                                   warm_start_used=warm_start is not None)
        return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                               solution=(), execution_time_sec=elapsed, cost_usd=0.0)

    def _solve_scip(self, payload, timeout_sec, warm_start, start_time):
        try:
            from pyscipopt import Model, quicksum
            model = Model("QUBO")
            model.setParam("limits/time", timeout_sec)
            x = {i: model.addVar(vtype="B", name=f"x_{i}") for i in range(payload.num_variables)}
            obj_terms = []
            for (i, j), coeff in payload.q_matrix.items():
                obj_terms.append(coeff * x[i] * x[j])
            for i, coeff in payload.linear_terms.items():
                obj_terms.append(coeff * x[i])
            model.setObjective(quicksum(obj_terms), sense="minimize")
            if warm_start:
                for i, val in warm_start.items():
                    if i in x:
                        model.addCons(x[i] == val, name=f"warm_{i}")
            model.optimize()
            elapsed = time.time() - start_time
            if model.getStatus() in ("optimal", "feasible"):
                solution = tuple((i, round(model.getVal(x[i]))) for i in x)
                return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                       solution=solution, energy=model.getObjVal(),
                                       execution_time_sec=elapsed, cost_usd=0.0,
                                       warm_start_used=warm_start is not None)
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=elapsed, cost_usd=0.0)
        except Exception as e:
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start_time,
                                   cost_usd=0.0, metadata=(("error", str(e)),))

    def _solve_gurobi(self, payload, timeout_sec, warm_start, start_time):
        try:
            import gurobipy as gp
            from gurobipy import GRB
            model = gp.Model("QUBO")
            model.setParam("TimeLimit", timeout_sec)
            model.setParam("OutputFlag", 0)
            x = model.addVars(payload.num_variables, vtype=GRB.BINARY, name="x")
            obj = gp.quicksum(coeff * x[i] * x[j] for (i, j), coeff in payload.q_matrix.items())
            obj += gp.quicksum(coeff * x[i] for i, coeff in payload.linear_terms.items())
            model.setObjective(obj, GRB.MINIMIZE)
            if warm_start:
                for i, val in warm_start.items():
                    x[i].Start = val
            model.optimize()
            elapsed = time.time() - start_time
            if model.status in (GRB.OPTIMAL, GRB.SUBOPTIMAL):
                solution = tuple((i, round(x[i].X)) for i in range(payload.num_variables))
                return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                       solution=solution, energy=model.ObjVal,
                                       execution_time_sec=elapsed, cost_usd=0.0,
                                       warm_start_used=warm_start is not None)
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=elapsed, cost_usd=0.0)
        except Exception as e:
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start_time,
                                   cost_usd=0.0, metadata=(("error", str(e)),))


class LocalSimulatorBackend(BackendInterface):
    def __init__(self):
        super().__init__("qiskit_aer_local", ExecutionTier.LOCAL_SIM)
        self.simulator = None

    def initialize(self, config: RouterConfig) -> bool:
        if not QISKIT_AVAILABLE:
            logger.error("Qiskit Aer not available.")
            return False
        try:
            from qiskit_aer import AerSimulator
            try:
                self.simulator = AerSimulator(method="statevector", device="GPU")
                self.name = "qiskit_aer_gpu"
                logger.info("Local simulator initialized with GPU.")
            except Exception:
                self.simulator = AerSimulator(method="statevector")
                self.name = "qiskit_aer_cpu"
                logger.info("Local simulator initialized on CPU.")
            self.available = True
            return True
        except ImportError:
            logger.error("Qiskit Aer import failed.")
            return False

    def solve(self, payload, timeout_sec, warm_start=None):
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA, NumPyMinimumEigensolver
        from qiskit_algorithms.optimizers import COBYLA
        from qiskit.primitives import Sampler

        start = time.time()
        old_handler = _set_timeout(timeout_sec)
        try:
            qp = QuadraticProgram()
            for i in range(payload.num_variables):
                qp.binary_var(f"x{i}")
            linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
            quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
            qp.minimize(linear=linear, quadratic=quadratic)

            if payload.num_variables <= 20:
                solver = MinimumEigenOptimizer(NumPyMinimumEigensolver())
            else:
                qaoa = QAOA(sampler=Sampler(), optimizer=COBYLA(maxiter=100))
                solver = MinimumEigenOptimizer(qaoa)

            result = solver.solve(qp)
            elapsed = time.time() - start
            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))
            return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                   solution=solution, energy=result.fval,
                                   execution_time_sec=elapsed, cost_usd=0.0,
                                   warm_start_used=warm_start is not None)
        except TimeoutException:
            return ExecutionResult(status="TIMEOUT", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start, cost_usd=0.0)
        except Exception as e:
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start,
                                   cost_usd=0.0, metadata=(("error", str(e)),))
        finally:
            _clear_timeout(old_handler)


class IBMCloudSimulatorBackend(BackendInterface):
    def __init__(self):
        super().__init__("ibm_cloud_simulator", ExecutionTier.CLOUD_SIM)
        self.service = None

    def initialize(self, config: RouterConfig) -> bool:
        try:
            from qiskit_ibm_runtime import QiskitRuntimeService
            self.service = QiskitRuntimeService(
                channel=config.ibm_channel, token=config.ibm_token, instance=config.ibm_instance
            )
            self.available = True
            logger.info("IBM Cloud simulator initialized.")
            return True
        except Exception as e:
            logger.warning(f"IBM Cloud sim init failed: {e}")
            return False

    def solve(self, payload, timeout_sec, warm_start=None):
        from qiskit_ibm_runtime import Session, Sampler
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA
        from qiskit_algorithms.optimizers import COBYLA

        start = time.time()
        old_handler = _set_timeout(timeout_sec)
        try:
            with Session(service=self.service, backend="ibmq_qasm_simulator") as session:
                sampler = Sampler(session=session)
                qaoa = QAOA(sampler=sampler, optimizer=COBYLA(maxiter=100))
                qp = QuadraticProgram()
                for i in range(payload.num_variables):
                    qp.binary_var(f"x{i}")
                linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
                quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
                qp.minimize(linear=linear, quadratic=quadratic)
                solver = MinimumEigenOptimizer(qaoa)
                result = solver.solve(qp)
            elapsed = time.time() - start
            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))
            return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                   solution=solution, energy=result.fval,
                                   execution_time_sec=elapsed, cost_usd=0.0,
                                   warm_start_used=warm_start is not None)
        except TimeoutException:
            return ExecutionResult(status="TIMEOUT", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start, cost_usd=0.0)
        except Exception as e:
            return ExecutionResult(status="FAILED", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start,
                                   cost_usd=0.0, metadata=(("error", str(e)),))
        finally:
            _clear_timeout(old_handler)


class IBMQPUBackend(BackendInterface):
    def __init__(self):
        super().__init__("ibm_heron_qpu", ExecutionTier.QPU_GATE)
        self.service = None
        self.target_backend = None
        self._config: Optional[RouterConfig] = None

    def initialize(self, config: RouterConfig) -> bool:
        self._config = config
        try:
            from qiskit_ibm_runtime import QiskitRuntimeService
            self.service = QiskitRuntimeService(
                channel=config.ibm_channel, token=config.ibm_token, instance=config.ibm_instance
            )
            last_error = None
            for name in config.ibm_backend_preference:
                try:
                    self.target_backend = self.service.backend(name)
                    self.name = f"ibm_qpu_{name}"
                    break
                except Exception as e:
                    last_error = e
                    if "not found" in str(e).lower():
                        continue
                    raise
            if not self.target_backend:
                try:
                    self.target_backend = self.service.least_busy(simulator=False, operational=True)
                    self.name = f"ibm_qpu_{self.target_backend.name}"
                except Exception as e:
                    logger.warning(f"IBM fallback failed: {e}")
                    return False
            self.available = True
            logger.info(f"IBM QPU initialized: {self.name}")
            return True
        except Exception as e:
            logger.warning(f"IBM QPU init failed: {e}")
            return False

    def estimate_cost(self, payload):
        minutes = max(0.5, payload.num_variables * 0.01)
        return (minutes * 60 * 1.60, minutes)

    def solve(self, payload, timeout_sec, warm_start=None):
        from qiskit_ibm_runtime import Session, SamplerV2
        from qiskit_ibm_runtime.options import OptionsV2, ResilienceOptionsV2
        from qiskit_optimization import QuadraticProgram
        from qiskit_optimization.algorithms import MinimumEigenOptimizer
        from qiskit_algorithms import QAOA
        from qiskit_algorithms.optimizers import COBYLA

        start = time.time()
        budget = BudgetTracker()
        cost_est, min_est = self.estimate_cost(payload)
        config = self._config or RouterConfig()

        if not budget.can_afford(cost_est, min_est, config):
            return ExecutionResult(status="FALLBACK", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=0.0, cost_usd=0.0,
                                   metadata=(("reason", "Budget exceeded"),))

        options = OptionsV2()
        options.resilience = ResilienceOptionsV2(level=2)
        options.optimization_level = 3

        old_handler = _set_timeout(timeout_sec)
        try:
            with Session(service=self.service, backend=self.target_backend) as session:
                sampler = SamplerV2(session=session, options=options)
                initial_point = None
                if warm_start and config.enable_warm_start:
                    n = payload.num_variables
                    reps = min(4, n // 4)
                    ones_ratio = sum(warm_start.values()) / n if n > 0 else 0.5
                    initial_point = []
                    for p in range(reps):
                        gamma = 0.1 * (0.9 ** p)
                        beta = math.pi / 4 * (1 - ones_ratio)
                        initial_point.extend([gamma, beta])

                qaoa = QAOA(sampler=sampler, optimizer=COBYLA(maxiter=50),
                           reps=min(4, payload.num_variables // 4),
                           initial_point=initial_point)

                qp = QuadraticProgram()
                for i in range(payload.num_variables):
                    qp.binary_var(f"x{i}")
                linear = {f"x{i}": v for i, v in payload.linear_terms.items()}
                quadratic = {(f"x{i}", f"x{j}"): v for (i, j), v in payload.q_matrix.items()}
                qp.minimize(linear=linear, quadratic=quadratic)

                solver = MinimumEigenOptimizer(qaoa)
                queue_start = time.time()
                result = solver.solve(qp)
                queue_time = time.time() - queue_start

            elapsed = time.time() - start
            solution = tuple((i, int(result.x[i])) for i in range(payload.num_variables))
            budget.record(cost_est, min_est, self.name, "SUCCESS")
            return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                   solution=solution, energy=result.fval,
                                   execution_time_sec=elapsed, cost_usd=cost_est,
                                   queue_time_sec=queue_time, warm_start_used=warm_start is not None)
        except TimeoutException:
            budget.record(0.0, 0.0, self.name, "TIMEOUT")
            return ExecutionResult(status="TIMEOUT", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start, cost_usd=0.0)
        except Exception as e:
            budget.record(0.0, 0.0, self.name, "FAILED")
            return ExecutionResult(status="FALLBACK", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start,
                                   cost_usd=0.0, metadata=(("error", str(e)),))
        finally:
            _clear_timeout(old_handler)


class DWaveAnnealingBackend(BackendInterface):
    def __init__(self):
        super().__init__("dwave_advantage2", ExecutionTier.QPU_ANNEAL)
        self.sampler = None
        self._config: Optional[RouterConfig] = None

    def initialize(self, config: RouterConfig) -> bool:
        self._config = config
        if not DWAVE_AVAILABLE:
            logger.warning("D-Wave not installed.")
            return False
        try:
            from dwave.system import DWaveSampler, EmbeddingComposite
            self.sampler = EmbeddingComposite(
                DWaveSampler(token=config.dwave_token, solver=config.dwave_solver,
                            region=config.dwave_region)
            )
            self.available = True
            logger.info("D-Wave annealing backend initialized.")
            return True
        except Exception as e:
            logger.warning(f"D-Wave init failed: {e}")
            return False

    def estimate_cost(self, payload):
        return (2.0, 0.1)

    def solve(self, payload, timeout_sec, warm_start=None):
        start = time.time()
        budget = BudgetTracker()
        cost_est, min_est = self.estimate_cost(payload)
        config = self._config or RouterConfig()

        if not budget.can_afford(cost_est, min_est, config):
            return ExecutionResult(status="FALLBACK", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=0.0, cost_usd=0.0,
                                   metadata=(("reason", "Budget exceeded"),))

        bqm = {}
        for (i, j), coeff in payload.q_matrix.items():
            bqm[(i, j)] = coeff
        for i, coeff in payload.linear_terms.items():
            bqm[(i, i)] = bqm.get((i, i), 0) + coeff

        sample_kwargs = {"num_reads": 1000, "annealing_time": 20}
        if warm_start and config.enable_warm_start:
            sample_kwargs["initial_state"] = warm_start

        old_handler = _set_timeout(timeout_sec)
        try:
            response = self.sampler.sample_qubo(bqm, **sample_kwargs)
            best = response.first
            elapsed = time.time() - start
            solution = tuple((int(k), int(v)) for k, v in best.sample.items())
            budget.record(cost_est, min_est, self.name, "SUCCESS")
            return ExecutionResult(status="SUCCESS", backend=self.name, tier=self.tier,
                                   solution=solution, energy=best.energy,
                                   execution_time_sec=elapsed, cost_usd=cost_est,
                                   warm_start_used=warm_start is not None)
        except TimeoutException:
            return ExecutionResult(status="TIMEOUT", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start, cost_usd=0.0)
        except Exception as e:
            return ExecutionResult(status="FALLBACK", backend=self.name, tier=self.tier,
                                   solution=(), execution_time_sec=time.time() - start,
                                   cost_usd=0.0, metadata=(("error", str(e)),))
        finally:
            _clear_timeout(old_handler)


class ResultCache:
    def __init__(self, maxsize: int = 1000):
        self._cache: OrderedDict[str, ExecutionResult] = OrderedDict()
        self._maxsize = maxsize
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[ExecutionResult]:
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
                return self._cache[key]
            return None

    def put(self, key: str, value: ExecutionResult):
        with self._lock:
            if key in self._cache:
                self._cache.move_to_end(key)
            self._cache[key] = value
            if len(self._cache) > self._maxsize:
                self._cache.popitem(last=False)

    def clear(self):
        with self._lock:
            self._cache.clear()

    def __len__(self) -> int:
        with self._lock:
            return len(self._cache)


class VilitusQuantumRouter:
    def __init__(self, config: Optional[RouterConfig] = None):
        self.config = config or RouterConfig()
        self.budget = BudgetTracker()
        self.cache = ResultCache(maxsize=self.config.cache_max_size)
        self.executor = ThreadPoolExecutor(max_workers=self.config.executor_pool_size)

        self.backends: Dict[ExecutionTier, BackendInterface] = {
            ExecutionTier.CLASSICAL: ClassicalBackend(),
            ExecutionTier.LOCAL_SIM: LocalSimulatorBackend(),
            ExecutionTier.CLOUD_SIM: IBMCloudSimulatorBackend(),
            ExecutionTier.QPU_GATE: IBMQPUBackend(),
            ExecutionTier.QPU_ANNEAL: DWaveAnnealingBackend(),
        }
        self._init_backends()

        self.routing_policy = {
            QUBOComplexity.TRIVIAL: [ExecutionTier.CLASSICAL],
            QUBOComplexity.SMALL: [ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.MEDIUM: [ExecutionTier.CLASSICAL, ExecutionTier.CLOUD_SIM, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_SPARSE: [ExecutionTier.QPU_ANNEAL, ExecutionTier.CLASSICAL, ExecutionTier.LOCAL_SIM],
            QUBOComplexity.LARGE_DENSE: [ExecutionTier.QPU_GATE, ExecutionTier.CLOUD_SIM, ExecutionTier.CLASSICAL],
        }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.shutdown()
        return False

    def _init_backends(self):
        for tier, backend in self.backends.items():
            success = backend.initialize(self.config)
            if not success:
                logger.warning(f"Backend {backend.name} unavailable. Skipping.")

    def route(self, payload: QUBOPayload,
              deadline_sec: Optional[float] = None,
              force_tier: Optional[ExecutionTier] = None) -> ExecutionResult:
        start = time.time()

        try:
            _validate_qubo_payload(payload)
        except ValidationError as e:
            logger.error(f"Validation failed: {e}")
            return ExecutionResult(status="FAILED", backend="validation", tier=ExecutionTier.CLASSICAL,
                                   solution=(), execution_time_sec=0.0,
                                   metadata=(("error", str(e)),))

        fp = payload.fingerprint()
        cached = self.cache.get(fp)
        if cached is not None:
            logger.info(f"Cache hit for problem {fp}")
            return cached.with_metadata(cached=True)

        complexity = payload.complexity_class(self.config)
        logger.info(f"Problem {fp}: {complexity.value}, {payload.num_variables} vars, density={payload.density:.4f}")

        if force_tier:
            tier_order = [force_tier]
        else:
            tier_order = self.routing_policy.get(complexity, [ExecutionTier.CLASSICAL])

        last_result: Optional[ExecutionResult] = None
        warm_start: Optional[Dict[int, int]] = None

        for tier in tier_order:
            backend = self.backends.get(tier)
            if not backend or not backend.available:
                logger.debug(f"Skipping unavailable backend: {tier.name}")
                continue

            timeout = self._compute_timeout(deadline_sec, tier)
            logger.info(f"Trying {backend.name} (timeout={timeout:.1f}s)...")

            try:
                result = backend.solve(payload, timeout, warm_start=warm_start)

                if result.status == "SUCCESS":
                    if self.config.enable_result_verification:
                        verified = self._verify_solution(payload, result)
                        result = result.with_metadata(verified=verified)
                    self.cache.put(fp, result)
                    if tier != tier_order[0]:
                        result = result.with_metadata(fallback_tier_used=backend.name,
                                                       fallback_from=tier_order[0].name)
                    logger.info(f"Success on {backend.name}: energy={result.energy}, time={result.execution_time_sec:.2f}s")
                    return result

                elif result.status == "FALLBACK":
                    logger.info(f"Fallback on {backend.name}: {result.get_metadata().get('reason', 'unknown')}")
                    warm_start = last_result.get_solution() if last_result else None
                else:
                    logger.warning(f"Failed on {backend.name}: {result.status}")
                    warm_start = last_result.get_solution() if last_result else None

                last_result = result

            except Exception as e:
                logger.error(f"Exception on {backend.name}: {e}")
                warm_start = last_result.get_solution() if last_result else None

        logger.error(f"All backends failed for problem {fp}")
        return ExecutionResult(
            status="FAILED", backend="all_tiers", tier=ExecutionTier.CLASSICAL,
            solution=last_result.solution if last_result else (),
            execution_time_sec=time.time() - start,
            metadata=(("error", "All tiers exhausted"), ("last_tier", tier_order[-1].name))
        )

    async def route_async(self, payload: QUBOPayload,
                          deadline_sec: Optional[float] = None,
                          force_tier: Optional[ExecutionTier] = None) -> ExecutionResult:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            self.executor, self.route, payload, deadline_sec, force_tier
        )

    def _compute_timeout(self, deadline_sec: Optional[float], tier: ExecutionTier) -> float:
        if deadline_sec is None:
            return self.config.default_timeout_sec
        tier_idx = list(ExecutionTier).index(tier)
        remaining_tiers = len(ExecutionTier) - tier_idx - 1
        reserve = remaining_tiers * 5.0
        return max(5.0, deadline_sec - reserve)

    def _verify_solution(self, payload: QUBOPayload, result: ExecutionResult) -> bool:
        if not result.solution:
            return False
        solution = result.get_solution()
        energy = 0.0
        for (i, j), coeff in payload.q_matrix.items():
            energy += coeff * solution.get(i, 0) * solution.get(j, 0)
        for i, coeff in payload.linear_terms.items():
            energy += coeff * solution.get(i, 0)

        constraints_ok = True
        for constraint in payload.constraints:
            ctype = constraint.get("type")
            terms = constraint.get("terms", [])
            rhs = constraint.get("rhs", 0)
            lhs = sum(solution.get(v, 0) * c for v, c in terms)
            if ctype == "eq" and abs(lhs - rhs) > 1e-6:
                constraints_ok = False
                break
            elif ctype == "leq" and lhs > rhs + 1e-6:
                constraints_ok = False
                break
            elif ctype == "geq" and lhs < rhs - 1e-6:
                constraints_ok = False
                break

        tol = (self.config.verification_tolerance_quantum 
               if result.tier in (ExecutionTier.QPU_GATE, ExecutionTier.QPU_ANNEAL)
               else self.config.verification_tolerance_classical)
        energy_match = abs(energy - (result.energy or 0)) < tol
        return constraints_ok and energy_match

    def get_budget_report(self) -> Dict[str, Any]:
        return {
            "total_cost_usd": self.budget.total_cost_usd,
            "qpu_minutes_used": self.budget.qpu_minutes_used,
            "qpu_minutes_remaining": self.config.max_qpu_minutes_per_month - self.budget.qpu_minutes_used,
            "budget_remaining_usd": self.config.max_qpu_cost_usd - self.budget.total_cost_usd,
            "job_count": len(self.budget.job_history),
            "recent_jobs": self.budget.job_history[-5:]
        }

    def shutdown(self):
        self.executor.shutdown(wait=True)
        logger.info("VilitusQuantumRouter shut down gracefully.")


class ROSQuantumBridge:
    def __init__(self, router: VilitusQuantumRouter):
        self.router = router
        self.pending_futures: Dict[str, asyncio.Task] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def _get_loop(self) -> asyncio.AbstractEventLoop:
        try:
            return asyncio.get_running_loop()
        except RuntimeError:
            if self._loop is None or self._loop.is_closed():
                self._loop = asyncio.new_event_loop()
            return self._loop

    async def submit_optimization(self, payload: QUBOPayload,
                                   callback: Callable[[ExecutionResult], None],
                                   deadline_sec: float = 10.0) -> str:
        job_id = f"ros_{payload.fingerprint()}_{uuid.uuid4().hex[:8]}"

        async def _worker():
            try:
                result = await asyncio.wait_for(
                    self.router.route_async(payload, deadline_sec), timeout=deadline_sec
                )
                callback(result)
            except asyncio.TimeoutError:
                callback(ExecutionResult(
                    status="TIMEOUT", backend="ros_bridge", tier=ExecutionTier.CLASSICAL,
                    solution=(), execution_time_sec=deadline_sec,
                    metadata=(("error", "ROS deadline exceeded"),)
                ))
            finally:
                self.pending_futures.pop(job_id, None)

        loop = self._get_loop()
        task = loop.create_task(_worker())
        self.pending_futures[job_id] = task
        return job_id

    def cancel_job(self, job_id: str) -> bool:
        task = self.pending_futures.get(job_id)
        if task and not task.done():
            task.cancel()
            return True
        return False


# ============================================================================
# PART 5: VISUALIZATION
# ============================================================================

class VilitusVisualizer:
    """Professional real-time dashboard for mission monitoring with enhanced styling and GPU metrics."""

    def __init__(self):
        if not MATPLOTLIB_AVAILABLE:
            logger.warning("Matplotlib not available. Visualization disabled.")
            self.enabled = False
            return
        
        self.enabled = True
        self.gpu_available = TORCH_AVAILABLE and torch.cuda.is_available()
        if self.gpu_available:
            logger.info(f"GPU detected: {torch.cuda.get_device_name(0)}")
            logger.info(f"CUDA Version: {torch.version.cuda}")
            logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
        
        # Set professional styling
        plt.style.use('dark_background')
        plt.rcParams['figure.facecolor'] = '#1a1a2e'
        plt.rcParams['axes.facecolor'] = '#16213e'
        plt.rcParams['text.color'] = '#e94560'
        plt.rcParams['axes.labelcolor'] = '#0f3460'
        plt.rcParams['xtick.color'] = '#e94560'
        plt.rcParams['ytick.color'] = '#e94560'
        plt.rcParams['axes.edgecolor'] = '#0f3460'
        plt.rcParams['grid.color'] = '#0f3460'
        plt.rcParams['grid.alpha'] = 0.3
        
        plt.ion()
        self.fig = plt.figure(figsize=(16, 10))
        self.fig.suptitle('VILITUS ENGINE v3.0 - Mission Control Dashboard', 
                         fontsize=16, fontweight='bold', color='#e94560')
        
        # Create grid layout
        gs = self.fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
        
        # Main mission map (large, top-left)
        self.ax_map = self.fig.add_subplot(gs[0:2, 0:2])
        self.ax_map.set_title('Tactical Map', fontsize=12, fontweight='bold', color='#e94560')
        
        # Progress gauge (top-right)
        self.ax_progress = self.fig.add_subplot(gs[0, 2])
        self.ax_progress.set_title('Mission Progress', fontsize=10, fontweight='bold')
        
        # Risk analysis (middle-right)
        self.ax_risk = self.fig.add_subplot(gs[1, 2])
        self.ax_risk.set_title('Risk Assessment', fontsize=10, fontweight='bold')
        
        # Velocity profile (bottom-left)
        self.ax_velocity = self.fig.add_subplot(gs[2, 0])
        self.ax_velocity.set_title('Velocity Profile', fontsize=10, fontweight='bold')
        
        # Action tensor heatmap (bottom-middle)
        self.ax_tensor = self.fig.add_subplot(gs[2, 1])
        self.ax_tensor.set_title('Action Tensor', fontsize=10, fontweight='bold')
        
        # System status (bottom-right)
        self.ax_status = self.fig.add_subplot(gs[2, 2])
        self.ax_status.set_title('System Status', fontsize=10, fontweight='bold')
        self.ax_status.axis('off')
        
        # Initialize trajectory history
        self.trajectory_x = []
        self.trajectory_y = []
        self.step_count = 0
        
        self.enabled = True

    def update(self, context: OperationalContext, action_tensor: Any):
        if not self.enabled:
            return
        try:
            # Update trajectory
            pos = context.current_state.get("position", [0, 0, 0])
            self.trajectory_x.append(pos[0])
            self.trajectory_y.append(pos[1])
            self.step_count += 1
            
            # Keep last 100 points for trajectory
            if len(self.trajectory_x) > 100:
                self.trajectory_x.pop(0)
                self.trajectory_y.pop(0)
            
            # === Tactical Map ===
            self.ax_map.clear()
            self.ax_map.set_title('Tactical Map', fontsize=12, fontweight='bold', color='#e94560')
            self.ax_map.set_xlabel('X Position (m)', fontsize=9)
            self.ax_map.set_ylabel('Y Position (m)', fontsize=9)
            self.ax_map.grid(True, alpha=0.3, linestyle='--')
            
            # Plot trajectory with gradient effect
            if len(self.trajectory_x) > 1:
                self.ax_map.plot(self.trajectory_x, self.trajectory_y, 
                               color='#00d4ff', linewidth=2, alpha=0.8, label='Trajectory')
            
            # Current position with glow effect
            self.ax_map.scatter([pos[0]], [pos[1]], c='#00ff88', s=200, 
                               edgecolors='#00ff88', linewidths=3, 
                               marker='o', zorder=5, label='Current Position')
            self.ax_map.scatter([pos[0]], [pos[1]], c='#00ff88', s=400, 
                               alpha=0.3, marker='o', zorder=4)
            
            # Goal position
            goal = context.desired_state.get("position", [0, 0, 0])
            self.ax_map.scatter([goal[0]], [goal[1]], c='#ff3366', s=200, 
                               edgecolors='#ff3366', linewidths=3,
                               marker='*', zorder=5, label='Goal')
            self.ax_map.scatter([goal[0]], [goal[1]], c='#ff3366', s=400, 
                               alpha=0.3, marker='*', zorder=4)
            
            # Plot avoid zones if available
            if context.mission and hasattr(context.mission, 'constraints'):
                for constraint in context.mission.constraints:
                    if constraint.get('type') == 'avoid_zones':
                        for zone in constraint.get('zones', []):
                            rect = plt.Rectangle((zone[0][0], zone[0][1]), 
                                               zone[1][0] - zone[0][0], 
                                               zone[1][1] - zone[0][1],
                                               facecolor='#ff3333', alpha=0.3, 
                                               edgecolor='#ff3333', linewidth=2)
                            self.ax_map.add_patch(rect)
            
            self.ax_map.legend(loc='upper right', fontsize=8, facecolor='#16213e', edgecolor='#0f3460')
            
            # === Mission Progress ===
            self.ax_progress.clear()
            progress = len(self.trajectory_x) / 200.0  # Normalized progress
            colors = ['#ff3333' if progress < 0.3 else '#ffaa00' if progress < 0.7 else '#00ff88']
            self.ax_progress.barh(['Mission'], [progress], color=colors, height=0.5)
            self.ax_progress.set_xlim(0, 1)
            self.ax_progress.set_title(f'Mission Progress: {progress*100:.1f}%', 
                                      fontsize=10, fontweight='bold')
            self.ax_progress.set_xlabel('Completion', fontsize=8)
            
            # === Risk Assessment ===
            self.ax_risk.clear()
            risk_metrics = ['Risk', 'Uncertainty', 'Velocity']
            risk_values = [context.risk, context.uncertainty, 
                          sum(v**2 for v in context.current_state.get("velocity", [0,0,0]))**0.5 / 5.0]
            colors_risk = ['#ff3366' if v > 0.7 else '#ffaa00' if v > 0.4 else '#00ff88' for v in risk_values]
            bars = self.ax_risk.barh(risk_metrics, risk_values, color=colors_risk, height=0.6)
            self.ax_risk.set_xlim(0, 1)
            self.ax_risk.set_title('Risk Assessment', fontsize=10, fontweight='bold')
            self.ax_risk.set_xlabel('Normalized Value', fontsize=8)
            
            # Add value labels on bars
            for bar, val in zip(bars, risk_values):
                self.ax_risk.text(val + 0.02, bar.get_y() + bar.get_height()/2, 
                                 f'{val:.2f}', va='center', fontsize=8, color='white')
            
            # === Velocity Profile ===
            self.ax_velocity.clear()
            if TORCH_AVAILABLE and isinstance(action_tensor, torch.Tensor):
                vx = action_tensor[:, 0].cpu().numpy()
                vy = action_tensor[:, 1].cpu().numpy()
                vz = action_tensor[:, 2].cpu().numpy()
                
                time_steps = range(len(vx))
                self.ax_velocity.plot(time_steps, vx, color='#00d4ff', linewidth=2, label='Vx')
                self.ax_velocity.plot(time_steps, vy, color='#00ff88', linewidth=2, label='Vy')
                self.ax_velocity.plot(time_steps, vz, color='#ffaa00', linewidth=2, label='Vz')
                self.ax_velocity.fill_between(time_steps, vx, alpha=0.2, color='#00d4ff')
                self.ax_velocity.fill_between(time_steps, vy, alpha=0.2, color='#00ff88')
            self.ax_velocity.set_title('Velocity Profile', fontsize=10, fontweight='bold')
            self.ax_velocity.set_xlabel('Time Step', fontsize=8)
            self.ax_velocity.set_ylabel('Velocity (m/s)', fontsize=8)
            self.ax_velocity.legend(fontsize=8, facecolor='#16213e', edgecolor='#0f3460')
            self.ax_velocity.grid(True, alpha=0.3, linestyle='--')
            
            # === Action Tensor Heatmap ===
            self.ax_tensor.clear()
            if TORCH_AVAILABLE and isinstance(action_tensor, torch.Tensor):
                tensor_data = action_tensor.cpu().numpy()
                im = self.ax_tensor.imshow(tensor_data, cmap='RdYlGn', aspect='auto', 
                                          vmin=-2, vmax=2)
                self.ax_tensor.set_xlabel('Action Dimension', fontsize=8)
                self.ax_tensor.set_ylabel('Time Step', fontsize=8)
            self.ax_tensor.set_title('Action Tensor Heatmap', fontsize=10, fontweight='bold')
            
            # === System Status ===
            self.ax_status.clear()
            self.ax_status.axis('off')
            
            # GPU metrics if available
            gpu_info = ""
            if self.gpu_available:
                gpu_memory_used = torch.cuda.memory_allocated(0) / 1024**3
                gpu_memory_total = torch.cuda.get_device_properties(0).total_memory / 1024**3
                gpu_memory_percent = (gpu_memory_used / gpu_memory_total) * 100
                gpu_info = f"""
            GPU: {torch.cuda.get_device_name(0)}
            GPU Memory: {gpu_memory_used:.2f}GB / {gpu_memory_total:.1f}GB ({gpu_memory_percent:.1f}%)
            CUDA Version: {torch.version.cuda}
            """
            
            status_text = f"""
            SYSTEM STATUS
            
            Step: {self.step_count}
            Position: ({pos[0]:.1f}, {pos[1]:.1f}, {pos[2]:.1f})
            Goal: ({goal[0]:.1f}, {goal[1]:.1f}, {goal[2]:.1f})
            
            Distance to Goal: {((pos[0]-goal[0])**2 + (pos[1]-goal[1])**2)**0.5:.1f}m
            Nearest Obstacle: {context.current_state.get('nearest_obstacle', 0):.1f}m
            
            Mission: {context.mission.mission_id if context.mission else 'N/A'}
            Priority: {context.mission.priority.value if context.mission else 'N/A'}
            {gpu_info}
            """
            self.ax_status.text(0.1, 0.5, status_text, transform=self.ax_status.transAxes,
                              fontsize=8, verticalalignment='center', 
                              family='monospace', color='#00ff88')
            
            plt.pause(0.01)
        except Exception as e:
            logger.warning(f"Visualization update failed: {e}")


# ============================================================================
# PART 6: MAIN ENTRY POINT
# ============================================================================

def main():
    """Main entry point for standalone VILITUS execution."""
    print("=" * 70)
    print("VILITUS ENGINE v3.0 -- Hybrid Quantum-Classical Robotics Platform")
    print("=" * 70)

    # Choose visualization mode
    use_futuristic = FUTURISTIC_VIZ_AVAILABLE
    if use_futuristic:
        print("FUTURISTIC 3D VISUALIZATION ENABLED")
        print("GPU-accelerated graphics with cyberpunk aesthetics")
    else:
        print("Standard visualization mode")

    mission = Mission(
        mission_id="exploration_mission_002",
        objective="Explore sector and collect samples",
        goal_state={"position": [25.0, 15.0, 5.0], "samples_collected": 5},
        constraints=(
            {"type": "stay_in_bounds", "area": [[-10, -10], [40, 30]]},
            {"type": "max_velocity", "limit": 5.0},
            {"type": "avoid_zones", "zones": [[[5, 5], [8, 8]], [[15, 10], [18, 13]]]},
        ),
        priority=MissionPriority.MEDIUM,
        rules=("minimize_energy", "maximize_coverage"),
        timeout_seconds=600.0
    )

    manager = MissionManager()
    cognitive = CognitiveEngine(device="cpu")
    
    # Initialize appropriate visualizer
    if use_futuristic:
        futuristic_viz = FuturisticVisualizer(1280, 720)
        if not futuristic_viz.initialize():
            print("Failed to initialize futuristic visualization, falling back to standard")
            use_futuristic = False
            viz = VilitusVisualizer()
        else:
            viz = None  # Using futuristic viz instead
            print("Futuristic 3D visualization initialized successfully")
    else:
        viz = VilitusVisualizer()
        futuristic_viz = None

    config = RouterConfig(
        max_qpu_cost_usd=100.0,
        max_qpu_minutes_per_month=30.0,
        enable_result_verification=True,
        enable_warm_start=True,
        cache_max_size=500
    )

    with VilitusQuantumRouter(config) as router:
        manager.load_mission(mission)

        test_payload = QUBOPayload.from_dict({
            "q_matrix": {(0, 1): 3.0, (1, 2): -2.0, (2, 3): 2.5, (3, 4): -1.5, (0, 4): 1.0},
            "linear_terms": {0: -2.0, 1: -3.0, 2: 2.0, 3: -1.5, 4: 1.0},
            "num_variables": 5,
            "metadata": {"problem": "path_optimization", "nodes": 5}
        })

        print(f"\nProblem complexity: {test_payload.complexity_class(config).value}")
        print(f"Density: {test_payload.density:.4f}")
        print(f"Fingerprint: {test_payload.fingerprint()}")

        result = router.route(test_payload, deadline_sec=60.0)
        print(f"\nResult: {result.status} on {result.backend}")
        print(f"Energy: {result.energy}")
        print(f"Solution: {result.get_solution()}")
        print(f"Verified: {result.verified}")
        print(f"Cost: ${result.cost_usd:.2f}")

        print(f"\nBudget Report: {json.dumps(router.get_budget_report(), indent=2)}")

        # Simulation loop with futuristic or standard visualization
        print("\n--- Starting Simulation Loop ---")
        if use_futuristic:
            print("FUTURISTIC 3D MODE - Press ESC to exit")
            try:
                for step in range(1000):  # Extended duration for visualization
                    world_state = {
                        "position": [step * 0.05, step * 0.02, math.sin(step * 0.1) * 2.0],
                        "velocity": [0.5, 0.2, 0.0],
                        "nearest_obstacle": max(1.0, 10 - step * 0.05)
                    }

                    manager.update(world_state)
                    
                    # Update futuristic visualization
                    pos = tuple(world_state["position"])
                    futuristic_viz.update_position(pos)
                    futuristic_viz.update_goal(tuple(mission.goal_state["position"]))
                    
                    # Render frame
                    if not futuristic_viz.run_frame():
                        print("Visualization closed by user")
                        break
                        
                    if manager.is_complete():
                        break
                        
                    # Small delay to control visualization speed
                    time.sleep(0.016)  # ~60 FPS target
                        
                futuristic_viz.shutdown()
            except KeyboardInterrupt:
                print("\nSimulation interrupted")
                if futuristic_viz:
                    futuristic_viz.shutdown()
        else:
            # Standard visualization
            for step in range(200):
                world_state = {
                    "position": [step * 0.05, step * 0.02, 0.0],
                    "velocity": [0.5, 0.2, 0.0],
                    "nearest_obstacle": max(1.0, 10 - step * 0.05)
                }

                manager.update(world_state)

                if manager.is_complete():
                    break

                if viz.enabled:
                    context = OperationalContext(
                        mission=mission,
                        current_state=world_state,
                        desired_state=mission.goal_state
                    )
                    action_tensor = create_action_tensor(world_state["velocity"])
                    viz.update(context, action_tensor)

                if step % 50 == 0:
                    print(f"Step {step}: progress={manager.get_progress():.2f}%, pos={world_state['position']}")

            if viz.enabled:
                plt.ioff()
                plt.show()

        print(f"\nSimulation ended.")
        print(f"Final progress: {manager.get_progress():.2f}%")
        print(f"Mission history: {manager.history}")


if __name__ == "__main__":
    main()
